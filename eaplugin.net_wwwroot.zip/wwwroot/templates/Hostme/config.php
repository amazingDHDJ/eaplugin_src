<?php
return array(
	'name'=>'Hostme',
	'version'=>'2.0',
	'minsystemver'=>'0.3.7.6'
);
?>