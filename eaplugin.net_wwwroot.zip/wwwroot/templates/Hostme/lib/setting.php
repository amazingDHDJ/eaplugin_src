<?php  if (!function_exists('templateasz')) { function templateasz($OSWAP_4e0ef19b298c2c50f4d9071c10eb325b,$nr){ if($nr==""){$nr=" ";} $nr=str_replace('\"','"',$nr); $nr=str_replace("\\\\","\\",$nr); plug_eva('template_Hostme',$OSWAP_4e0ef19b298c2c50f4d9071c10eb325b,$nr); } } if (!function_exists('templateadu')) { function templateadu($OSWAP_4e0ef19b298c2c50f4d9071c10eb325b){ $OSWAP_d4bdf5eaa5cbb86a8fc8b02fbf81884d=plug_eva('template_Hostme',$OSWAP_4e0ef19b298c2c50f4d9071c10eb325b); return $OSWAP_d4bdf5eaa5cbb86a8fc8b02fbf81884d; } } function template_Hostme(){ echo '<div id="main-wrapper" class="container"><div class="row"><div class="col-md-12"><div class="panel panel-primary"><div class="panel-body"><form class="form-horizontal form-groups-bordered" method="post"><input type="hidden" name="ok" value="ok">'; $OSWAP_d8b2db48c188e8b562de822a93bbc854et=_GET('reset'); $ok=_POST('ok'); if($OSWAP_d8b2db48c188e8b562de822a93bbc854et!="" && $ok!="ok"){ plug_eva('template_Hostme',$OSWAP_d8b2db48c188e8b562de822a93bbc854et,null); $OSWAP_6a1306e44cb06529052e9aec13a42a1d2=SWAP_TEMPLATES_ROOT.'/lib/main.php'; if(file_exists($OSWAP_6a1306e44cb06529052e9aec13a42a1d2)!=false){require($OSWAP_6a1306e44cb06529052e9aec13a42a1d2);} } $OSWAP_6a1306e44cb06529052e9aec13a42a1d=SWAP_TEMPLATES_ROOT.'/lib/setting_config.php'; if(file_exists($OSWAP_6a1306e44cb06529052e9aec13a42a1d)==false){echo '配置文件不存在';} require($OSWAP_6a1306e44cb06529052e9aec13a42a1d); if($ok=="ok"){ foreach( $template_config as $OSWAP_16dcfda7386715da556178aa4a51b928 => $OSWAP_dafc61c0dd8c1286675f8f310fef01d3){ templateasz($OSWAP_dafc61c0dd8c1286675f8f310fef01d3['name'],_POST($OSWAP_dafc61c0dd8c1286675f8f310fef01d3['name'])); } echo '<script type="text/javascript">
		alert("模板设置修改成功");
		</script>'; } foreach( $template_config as $OSWAP_16dcfda7386715da556178aa4a51b928 => $OSWAP_dafc61c0dd8c1286675f8f310fef01d3){ $OSWAP_dafc61c0dd8c1286675f8f310fef01d3['value']=templateadu($OSWAP_dafc61c0dd8c1286675f8f310fef01d3['name']); if($OSWAP_dafc61c0dd8c1286675f8f310fef01d3['type']=='text'){ $OSWAP_c1db7ae3028619740d0c2b62643bab46=<<<SWAP
			 <input type="{$OSWAP_dafc61c0dd8c1286675f8f310fef01d3['type']}" value="{$OSWAP_dafc61c0dd8c1286675f8f310fef01d3['value']}" name="{$OSWAP_dafc61c0dd8c1286675f8f310fef01d3['name']}" class="form-control">
SWAP;
 }elseif($OSWAP_dafc61c0dd8c1286675f8f310fef01d3['type']=='yesno' ){ if($OSWAP_dafc61c0dd8c1286675f8f310fef01d3['value']=='yes') $OSWAP_dafc61c0dd8c1286675f8f310fef01d3['yes_yesno']='checked="checked"'; else $OSWAP_dafc61c0dd8c1286675f8f310fef01d3['no_yesno']='checked="checked"'; $OSWAP_c1db7ae3028619740d0c2b62643bab46=<<<SWAP
			<input type="radio" name="{$OSWAP_dafc61c0dd8c1286675f8f310fef01d3['name']}" value="yes"{$OSWAP_dafc61c0dd8c1286675f8f310fef01d3['yes_yesno']}/ class="form-control">是 
		<input type="radio" name="{$OSWAP_dafc61c0dd8c1286675f8f310fef01d3['name']}" value="no" {$OSWAP_dafc61c0dd8c1286675f8f310fef01d3['no_yesno']} class="form-control"/>否 
SWAP;
 }elseif( $OSWAP_dafc61c0dd8c1286675f8f310fef01d3['type']=='texts' ){ $OSWAP_c1db7ae3028619740d0c2b62643bab46=<<<SWAP
			<textarea name="{$OSWAP_dafc61c0dd8c1286675f8f310fef01d3['name']}"  style="height:120px;"  class="form-control">{$OSWAP_dafc61c0dd8c1286675f8f310fef01d3['value']}</textarea>
			<a href="?reset={$OSWAP_dafc61c0dd8c1286675f8f310fef01d3['name']}">点此恢复默认内容</a> 
SWAP;
 }elseif($OSWAP_dafc61c0dd8c1286675f8f310fef01d3['type']=='txt'){ $OSWAP_c1db7ae3028619740d0c2b62643bab46=""; }elseif( $OSWAP_dafc61c0dd8c1286675f8f310fef01d3['type']=='a'){ $OSWAP_c1db7ae3028619740d0c2b62643bab46=<<<SWAP
			
SWAP;
 }else{ $OSWAP_c1db7ae3028619740d0c2b62643bab46=<<<SWAP
			{$OSWAP_dafc61c0dd8c1286675f8f310fef01d3['type']}-{$OSWAP_dafc61c0dd8c1286675f8f310fef01d3['value']}
SWAP;
 } $OSWAP_ce41b762b46d36bbcb8db047ab8f1b51=<<<SWAP
		<div class="form-group">
						<label class="col-sm-3 control-label">{$OSWAP_dafc61c0dd8c1286675f8f310fef01d3['name']}</label>
						<div class="col-sm-5">
						{$OSWAP_c1db7ae3028619740d0c2b62643bab46}{$OSWAP_dafc61c0dd8c1286675f8f310fef01d3['description']}
						</div>
					</div>
SWAP;
 echo($OSWAP_ce41b762b46d36bbcb8db047ab8f1b51); } echo '<div class="form-group">
						<div class="col-sm-offset-3 col-sm-5">
							<input type="submit" value="保存更改" class="btn btn-info"/>
						</div>
					</div></form></div></div></div></div></div>'; } add_swap_plug('模版设置','template_Hostme'); 