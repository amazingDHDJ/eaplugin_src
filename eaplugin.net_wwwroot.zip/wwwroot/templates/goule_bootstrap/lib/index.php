<?php
$num=6;
TEMPLATE::functions('news',$num);