<?php
$num=4;
TEMPLATE::functions('news',$num);