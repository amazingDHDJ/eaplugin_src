<?php
/* Smarty version 3.1.30, created on 2017-06-15 19:03:40
  from "/home/ftp/s/s7234915/wwwroot/templates/goule_bootstrap/index.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_5942698cc75ee1_13353566',
  'has_nocache_code' => true,
  'file_dependency' => 
  array (
    '7fa820d19c75d5c6ad19859245b016995cdd9c80' => 
    array (
      0 => '/home/ftp/s/s7234915/wwwroot/templates/goule_bootstrap/index.tpl',
      1 => 1497257520,
      2 => 'file',
    ),
    '0123bf82fee6becdff2e52e3b9724a66be4ce279' => 
    array (
      0 => '/home/ftp/s/s7234915/wwwroot/templates/goule_bootstrap/top.tpl',
      1 => 1497237650,
      2 => 'file',
    ),
    'a4bcfb6e53c87d5e1eb1d5fde80a19fd899e735d' => 
    array (
      0 => '/home/ftp/s/s7234915/wwwroot/templates/goule_bootstrap/left.tpl',
      1 => 1497237650,
      2 => 'file',
    ),
    'c04d0f36cfc61d4b72d0dad5dbe53cfdcb55e4f0' => 
    array (
      0 => '/home/ftp/s/s7234915/wwwroot/templates/goule_bootstrap/copyright.tpl',
      1 => 1497237650,
      2 => 'file',
    ),
    'c87b3a109afa55c1ebfa903b35e48e86d51bcf8b' => 
    array (
      0 => '/home/ftp/s/s7234915/wwwroot/templates/goule_bootstrap/alert.tpl',
      1 => 1497237650,
      2 => 'file',
    ),
    'a60af8d0e373165ed3304b4ae98751d8f14c4569' => 
    array (
      0 => '/home/ftp/s/s7234915/wwwroot/templates/goule_bootstrap/copyright2.tpl',
      1 => 1497237650,
      2 => 'file',
    ),
  ),
  'cache_lifetime' => 120,
),true)) {
function content_5942698cc75ee1_13353566 (Smarty_Internal_Template $_smarty_tpl) {
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?php echo $_smarty_tpl->tpl_vars['c']->value['网站名称'];?>
 - <?php echo $_smarty_tpl->tpl_vars['lang']->value['客户中心'];?>
</title>
<link href="<?php echo $_smarty_tpl->tpl_vars['templatedir']->value;?>
/css/bootstrap.min.css" rel="stylesheet">
<link href="<?php echo $_smarty_tpl->tpl_vars['templatedir']->value;?>
/css/datepicker3.css" rel="stylesheet">
<link href="<?php echo $_smarty_tpl->tpl_vars['templatedir']->value;?>
/css/styles.css" rel="stylesheet">

<!--[if lt IE 9]>
<script src="<?php echo $_smarty_tpl->tpl_vars['templatedir']->value;?>
/js/html5shiv.js"></script>
<script src="<?php echo $_smarty_tpl->tpl_vars['templatedir']->value;?>
/js/respond.min.js"></script>
<![endif]-->

</head>
<body>
  <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
    <div class="container-fluid">
      <div class="navbar-header">
        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#sidebar-collapse" aria-controls="bs-navbar" aria-expanded="false">
          <span class="sr-only">Toggle navigation</span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
        </button>
        <a class="navbar-brand" href="/"><span><?php echo $_smarty_tpl->tpl_vars['c']->value['头部LOGO'];?>
</span> <?php echo $_smarty_tpl->tpl_vars['lang']->value['客户中心'];?>
</a>
        <?php if ((isset($_smarty_tpl->tpl_vars['s']->value['是否已经登陆'])?$_smarty_tpl->tpl_vars['s']->value['是否已经登陆']:'') == '是') {?>
<ul class="user-menu">
          <li class="dropdown pull-right">
            <a href="<?php echo $_smarty_tpl->tpl_vars['ROOT']->value;?>
/user/" class="dropdown-toggle" data-toggle="dropdown"><span class="glyphicon glyphicon-user"></span>
             <?php echo $_smarty_tpl->tpl_vars['s']->value['登陆用户名'];?>

             <span class="caret"></span></a>
            <ul class="dropdown-menu" role="menu">
              <li><a href="<?php echo $_smarty_tpl->tpl_vars['ROOT']->value;?>
/user/"><span class="glyphicon glyphicon-user"></span> 账户信息</a></li>
              <li><a href="<?php echo $_smarty_tpl->tpl_vars['ROOT']->value;?>
/user/password/"><span class="glyphicon glyphicon-edit"></span> 密码修改</a></li>
              <li><a href="<?php echo $_smarty_tpl->tpl_vars['ROOT']->value;?>
/index/login/"><span class="glyphicon glyphicon-remove-sign"></span> 安全退出</a></li>
            </ul>
          </li>
        </ul>
             <?php } else { ?>
<ul class="user-menu">
          <li class="dropdown pull-right">
            <a href="<?php echo $_smarty_tpl->tpl_vars['ROOT']->value;?>
/index/login/" class="dropdown-toggle" data-toggle="dropdown"><span class="glyphicon glyphicon-user"></span>
             未登录
             <span class="caret"></span></a>
            <ul class="dropdown-menu" role="menu">
              <li><a href="<?php echo $_smarty_tpl->tpl_vars['ROOT']->value;?>
/index/login/"><span class="glyphicon glyphicon-user"></span> 登陆</a></li>
              <li><a href="<?php echo $_smarty_tpl->tpl_vars['ROOT']->value;?>
/index/register/"><span class="glyphicon glyphicon-cog"></span> 注册</a></li>
            </ul>
          </li>
        </ul>
             <?php }?>
      </div>
    </div><!-- /.container-fluid -->
  </nav>
    
  <div id="sidebar-collapse" class="col-sm-3 col-lg-2 sidebar">
    <form role="search">
      <div class="form-group">
        <input type="text" class="form-control" placeholder="搜索 (不可用)">
      </div>
    </form>
    <ul class="nav menu">
      <li class="active"><a href="<?php echo $_smarty_tpl->tpl_vars['ROOT']->value;?>
/index/"><span class="glyphicon glyphicon-dashboard"></span> <?php echo $_smarty_tpl->tpl_vars['mlang']->value['仪表盘'];?>
</a></li>
      <li class="parent">
        <a data-toggle="collapse" href="#sub-item-1">
          <span class="glyphicon glyphicon-hdd"></span> <?php echo $_smarty_tpl->tpl_vars['mlang']->value['客户中心'];?>
 <span class="icon pull-right"><em class="glyphicon glyphicon-s glyphicon-plus"></em></span> 
        </a>
        <ul class="children collapse" id="sub-item-1">
          <li>
            <a class="" href="<?php echo $_smarty_tpl->tpl_vars['ROOT']->value;?>
/buy/">
              <span class="glyphicon glyphicon-shopping-cart"></span> <?php echo $_smarty_tpl->tpl_vars['mlang']->value['订购产品'];?>

            </a>
          </li>
          <li>
            <a class="" href="<?php echo $_smarty_tpl->tpl_vars['ROOT']->value;?>
/control/">
              <span class="glyphicon glyphicon-tasks"></span> <?php echo $_smarty_tpl->tpl_vars['mlang']->value['控制面板'];?>
  
            </a>
          </li>
        </ul>
      </li>
      <li><a href="<?php echo $_smarty_tpl->tpl_vars['ROOT']->value;?>
/help/"><span class="glyphicon glyphicon-list-alt"></span> <?php echo $_smarty_tpl->tpl_vars['mlang']->value['帮助中心'];?>
</a></li>
	  <li><a href="<?php echo $_smarty_tpl->tpl_vars['ROOT']->value;?>
/user/pay/"><span class="glyphicon glyphicon-jpy"></span> <?php echo $_smarty_tpl->tpl_vars['mlang']->value['账户充值'];?>
</a></li>
      <li role="presentation" class="divider"></li>
      <?php if ((isset($_smarty_tpl->tpl_vars['s']->value['是否已经登陆'])?$_smarty_tpl->tpl_vars['s']->value['是否已经登陆']:'') == '是') {?>
      <li><a href="<?php echo $_smarty_tpl->tpl_vars['ROOT']->value;?>
/ticket/"><span class="glyphicon glyphicon-edit"></span> <?php echo $_smarty_tpl->tpl_vars['mlang']->value['服务单'];?>
</a></li>
      <?php echo $_smarty_tpl->tpl_vars['plug']->value['用户页面列表'];?>

      <?php } else { ?>
      <li><a href="<?php echo $_smarty_tpl->tpl_vars['ROOT']->value;?>
/index/login/"><span class="glyphicon glyphicon-user"></span> 登陆</a></li>
      <li><a href="<?php echo $_smarty_tpl->tpl_vars['ROOT']->value;?>
/index/register/"><span class="glyphicon glyphicon-user"></span> 注册</a></li>
      <?php }?>
    </ul>
    
  </div><!--/.sidebar-->

  <div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">     
    <div class="row">
      <ol class="breadcrumb">
        <li><span class="glyphicon glyphicon-home"></span></li>
        <li class="active"><?php echo $_smarty_tpl->tpl_vars['mlang']->value['用户引索'];?>
</li>
      </ol>
    </div><!--/.row-->
    <br/>
    <?php if ((isset($_smarty_tpl->tpl_vars['s']->value['是否已经登陆'])?$_smarty_tpl->tpl_vars['s']->value['是否已经登陆']:'') == '是') {?>
    <div class="row">
      <div class="col-xs-12 col-md-6 col-lg-3">
        <div class="panel panel-blue panel-widget ">
          <a href="<?php echo $_smarty_tpl->tpl_vars['ROOT']->value;?>
/control/">
          <div class="row no-padding">
            <div class="col-sm-3 col-lg-5 widget-left">
              <em class="glyphicon glyphicon-tasks glyphicon-l"></em>
            </div>
            <div class="col-sm-9 col-lg-7 widget-right">
              <div class="large"><?php echo $_smarty_tpl->tpl_vars['ActiveService']->value;?>
个</div>
              <div class="text-muted"><?php echo $_smarty_tpl->tpl_vars['mlang']->value['有效的服务'];?>
</div>
            </div>
          </div>
          </a>
        </div>
      </div>
      <div class="col-xs-12 col-md-6 col-lg-3">
        <div class="panel panel-orange panel-widget">
          <a href="<?php echo $_smarty_tpl->tpl_vars['ROOT']->value;?>
/ticket/">
          <div class="row no-padding">
            <div class="col-sm-3 col-lg-5 widget-left">
              <em class="glyphicon glyphicon-signal glyphicon-l"></em>
            </div>
            <div class="col-sm-9 col-lg-7 widget-right">
              <div class="large"><?php echo $_smarty_tpl->tpl_vars['OpenTicket']->value;?>
个</div>
              <div class="text-muted"><?php echo $_smarty_tpl->tpl_vars['mlang']->value['开启的工单'];?>
</div>
            </div>
          </div>
          </a>
        </div>
      </div>
      <div class="col-xs-12 col-md-6 col-lg-3">
        <div class="panel panel-teal panel-widget">
          <a href="<?php echo $_smarty_tpl->tpl_vars['ROOT']->value;?>
/user/pay/">
          <div class="row no-padding">
            <div class="col-sm-3 col-lg-5 widget-left">
              <em class="glyphicon glyphicon-credit-card glyphicon-l"></em>
            </div>
            <div class="col-sm-9 col-lg-7 widget-right">
              <div class="large"><?php echo $_smarty_tpl->tpl_vars['s']->value['登陆预存款'];
echo $_smarty_tpl->tpl_vars['c']->value['交易币名称'];?>
</div>
              <div class="text-muted"><?php echo $_smarty_tpl->tpl_vars['mlang']->value['预存款'];?>
</div>
            </div>
          </div>
          </a>
        </div>
      </div>
      <div class="col-xs-12 col-md-6 col-lg-3">
        <div class="panel panel-red panel-widget">
          <a href="<?php echo $_smarty_tpl->tpl_vars['ROOT']->value;?>
/control/">
          <div class="row no-padding">
            <div class="col-sm-3 col-lg-5 widget-left">
              <em class="glyphicon glyphicon-exclamation-sign glyphicon-l"></em>
            </div>
            <div class="col-sm-9 col-lg-7 widget-right">
              <div class="large"><?php echo $_smarty_tpl->tpl_vars['Date']->value;?>
个</div>
              <div class="text-muted"><?php echo $_smarty_tpl->tpl_vars['mlang']->value['15天内到期'];?>
</div>
            </div>
          </div>
        </a>
        </div>
      </div>
    </div><!--/.row-->
     <?php } else { ?>
    <br/><br/><br/>
      <center><font size="36"color="red"><?php echo $_smarty_tpl->tpl_vars['c']->value['网站名称'];?>
 登陆后享受更多服务!</font></center>
    <?php }?>
    <div class="row">
      <div class="col-lg-12">
        <?php if ((isset($_smarty_tpl->tpl_vars['alert']->value['warning'])?$_smarty_tpl->tpl_vars['alert']->value['warning']:'') != '') {?>
<div class="alert alert-warning alert-dismissible fade in" role="alert">
      <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
      <strong><?php echo $_smarty_tpl->tpl_vars['alert']->value['warning'];?>
</strong>
    </div>
<?php }
if ((isset($_smarty_tpl->tpl_vars['alert']->value['error'])?$_smarty_tpl->tpl_vars['alert']->value['error']:'') != '') {?>
<div class="alert alert-danger alert-dismissible fade in" role="alert">
      <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
      <strong><?php echo $_smarty_tpl->tpl_vars['alert']->value['error'];?>
</strong>
    </div>
<?php }
if ((isset($_smarty_tpl->tpl_vars['alert']->value['success'])?$_smarty_tpl->tpl_vars['alert']->value['success']:'') != '') {?>
<div class="alert alert-success alert-dismissible fade in" role="alert">
      <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
      <strong><?php echo $_smarty_tpl->tpl_vars['alert']->value['success'];?>
</strong>
    </div>
<?php }
if ((isset($_smarty_tpl->tpl_vars['alert']->value['info'])?$_smarty_tpl->tpl_vars['alert']->value['info']:'') != '') {?>
<div class="alert alert-info alert-dismissible fade in" role="alert">
      <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
      <strong><?php echo $_smarty_tpl->tpl_vars['alert']->value['info'];?>
</strong>
    </div>
<?php }?>
        <div class="panel panel-default">
          <div class="panel-body">
            <div class="canvas-wrapper">
              <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th class="span5">
                                        网站公告
                                    </th>
                                    <th class="span1">
                                        <span class="line"></span>发布时间
                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                                <!-- row -->
                                <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['news']->value, 'new');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['new']->value) {
?>
                                <tr class="first">
                                  <td>
                                        <a href="<?php echo $_smarty_tpl->tpl_vars['ROOT']->value;?>
/index/announcement/<?php echo $_smarty_tpl->tpl_vars['new']->value['公告ID'];?>
/"><?php echo $_smarty_tpl->tpl_vars['new']->value['公告标题'];?>
</a>
                                    </td>
                  <td class="description">
                                        <?php echo $_smarty_tpl->tpl_vars['new']->value['公告时间'];?>

                                    </td>
                                </tr>
                                <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>

                            </tbody>
                        </table>
            </div>
          </div>
        </div>
      </div>
    </div><!--/.row-->
    <br/><br/><div class="col-lg-12">
<footer class="app-footer" role="footer">
        <div class="wrapper b-t bg-light">
    	<?php echo $_smarty_tpl->tpl_vars['c']->value['底部版权'];?>
 <?php echo $_smarty_tpl->tpl_vars['c']->value['网站名称'];?>
    <div class="attribution">Powered by <a href="http://www.swapidc.com/">SWAPIDC</a></div>
    </div>
  </footer>
</div>
  </div>  <!--/.main-->

  <script src="<?php echo $_smarty_tpl->tpl_vars['templatedir']->value;?>
/js/jquery-1.11.1.min.js"></script>
  <script src="<?php echo $_smarty_tpl->tpl_vars['templatedir']->value;?>
/js/bootstrap.min.js"></script>
  <script src="<?php echo $_smarty_tpl->tpl_vars['templatedir']->value;?>
/js/chart.min.js"></script>
  <script src="<?php echo $_smarty_tpl->tpl_vars['templatedir']->value;?>
/js/chart-data.js"></script>
  <script src="<?php echo $_smarty_tpl->tpl_vars['templatedir']->value;?>
/js/easypiechart.js"></script>
  <script src="<?php echo $_smarty_tpl->tpl_vars['templatedir']->value;?>
/js/easypiechart-data.js"></script>
  <script src="<?php echo $_smarty_tpl->tpl_vars['templatedir']->value;?>
/js/bootstrap-datepicker.js"></script>
  <script>
    $('#calendar').datepicker({
    });

    !function ($) {
        $(document).on("click","ul.nav li.parent > a > span.icon", function(){          
            $(this).find('em:first').toggleClass("glyphicon-minus");      
        }); 
        $(".sidebar span.icon").find('em:first').addClass("glyphicon-plus");
    }(window.jQuery);

    $(window).on('resize', function () {
      if ($(window).width() > 768) $('#sidebar-collapse').collapse('show')
    })
    $(window).on('resize', function () {
      if ($(window).width() <= 767) $('#sidebar-collapse').collapse('hide')
    })
  </script> 
</body>

</html><?php }
}
