<?php
/* Smarty version 3.1.30, created on 2017-06-15 19:08:43
  from "/home/ftp/s/s7234915/wwwroot/templates/goule_bootstrap/register.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_59426abb6cf518_88403167',
  'has_nocache_code' => true,
  'file_dependency' => 
  array (
    'f39b860b429252708ef12c2bd07efb538355cbc4' => 
    array (
      0 => '/home/ftp/s/s7234915/wwwroot/templates/goule_bootstrap/register.tpl',
      1 => 1497237650,
      2 => 'file',
    ),
    'c87b3a109afa55c1ebfa903b35e48e86d51bcf8b' => 
    array (
      0 => '/home/ftp/s/s7234915/wwwroot/templates/goule_bootstrap/alert.tpl',
      1 => 1497237650,
      2 => 'file',
    ),
    '0126aaaeeb8ace36cc05299274d52cf53aec1add' => 
    array (
      0 => '/home/ftp/s/s7234915/wwwroot/templates/goule_bootstrap/footer.tpl',
      1 => 1497237650,
      2 => 'file',
    ),
  ),
  'cache_lifetime' => 120,
),true)) {
function content_59426abb6cf518_88403167 (Smarty_Internal_Template $_smarty_tpl) {
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $_smarty_tpl->tpl_vars['c']->value['网站名称'];?>
 - <?php echo $_smarty_tpl->tpl_vars['lang']->value['注册用户'];?>
</title>

    <link href="<?php echo $_smarty_tpl->tpl_vars['templatedir']->value;?>
/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo $_smarty_tpl->tpl_vars['templatedir']->value;?>
/css/font-awesome.min.css" rel="stylesheet">
    <link href="<?php echo $_smarty_tpl->tpl_vars['templatedir']->value;?>
/css/custom.css" rel="stylesheet">
    <link href="<?php echo $_smarty_tpl->tpl_vars['templatedir']->value;?>
/css/animate.min.css" rel="stylesheet">
    <link href="<?php echo $_smarty_tpl->tpl_vars['templatedir']->value;?>
/css/style.min.css" rel="stylesheet"><base target="_blank">

</head>

<body class="gray-bg">
    <div class="middle-box text-center loginscreen   animated fadeInDown">
        <div>
            <h3>欢迎注册 <?php echo $_smarty_tpl->tpl_vars['c']->value['网站名称'];?>
</h3>
            <p><?php if ((isset($_smarty_tpl->tpl_vars['alert']->value['warning'])?$_smarty_tpl->tpl_vars['alert']->value['warning']:'') != '') {?>
<div class="alert alert-warning alert-dismissible fade in" role="alert">
      <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
      <strong><?php echo $_smarty_tpl->tpl_vars['alert']->value['warning'];?>
</strong>
    </div>
<?php }
if ((isset($_smarty_tpl->tpl_vars['alert']->value['error'])?$_smarty_tpl->tpl_vars['alert']->value['error']:'') != '') {?>
<div class="alert alert-danger alert-dismissible fade in" role="alert">
      <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
      <strong><?php echo $_smarty_tpl->tpl_vars['alert']->value['error'];?>
</strong>
    </div>
<?php }
if ((isset($_smarty_tpl->tpl_vars['alert']->value['success'])?$_smarty_tpl->tpl_vars['alert']->value['success']:'') != '') {?>
<div class="alert alert-success alert-dismissible fade in" role="alert">
      <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
      <strong><?php echo $_smarty_tpl->tpl_vars['alert']->value['success'];?>
</strong>
    </div>
<?php }
if ((isset($_smarty_tpl->tpl_vars['alert']->value['info'])?$_smarty_tpl->tpl_vars['alert']->value['info']:'') != '') {?>
<div class="alert alert-info alert-dismissible fade in" role="alert">
      <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
      <strong><?php echo $_smarty_tpl->tpl_vars['alert']->value['info'];?>
</strong>
    </div>
<?php }?></p>
            <form class="m-t" role="form" method="post">
                <div class="form-group">
                    <input name="username" type="text" class="form-control" placeholder="请输入用户名">
                </div>
                <div class="form-group">
                    <input name="password" type="password" class="form-control" placeholder="请输入密码">
                </div>
                <div class="form-group">
                    <input name="repassword" type="password" class="form-control" placeholder="请再次输入密码">
                </div>
                <div class="form-group">
                    <input name="email" type="text" class="form-control" placeholder="请输入邮箱">
                </div>
                <div class="form-group" style="display:none">
                    <input name="name" type="text" class="form-control" placeholder="请输入姓名" value="张三">
                </div>
                <div class="form-group" style="display:none">
                    <input name="address" type="text" class="form-control" placeholder="请输入地址" value="北京">
                </div>
                <div class="form-group" style="display:none">
                    <input name="zip" type="text" class="form-control" placeholder="请输入邮编" value="10000">
                </div>
                <div class="form-group">
                    <input name="phone" type="text" class="form-control" placeholder="请输入手机号码">
                </div>
                <select hidden name="country" id="country">
                    <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['countrys']->value, 'country');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['country']->value) {
?><option value="<?php echo $_smarty_tpl->tpl_vars['country']->value;?>
"<?php if ((isset($_smarty_tpl->tpl_vars['c']->value['默认国家'])?$_smarty_tpl->tpl_vars['c']->value['默认国家']:'') == (isset($_smarty_tpl->tpl_vars['country']->value)?$_smarty_tpl->tpl_vars['country']->value:'')) {?> selected="selected"<?php }?>><?php echo $_smarty_tpl->tpl_vars['country']->value;?>
</option><?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>

                </select>
                <button class="btn btn-primary block full-width m-b"><?php echo $_smarty_tpl->tpl_vars['lang']->value['注册'];?>
</button>

                <h6><p class="text-muted text-center"><small>已经有账户了？</small><a href="<?php echo $_smarty_tpl->tpl_vars['ROOT']->value;?>
/index/login/">点此<?php echo $_smarty_tpl->tpl_vars['lang']->value['登陆'];?>
</a></h6>
                </p>

            </form>
        </div>
    </div>
    <script src="<?php echo $_smarty_tpl->tpl_vars['templatedir']->value;?>
/js/jquery.min.js"></script>
    <script src="<?php echo $_smarty_tpl->tpl_vars['templatedir']->value;?>
/js/bootstrap.min.js"></script>
    <script src="<?php echo $_smarty_tpl->tpl_vars['templatedir']->value;?>
/js/plugins/iCheck/icheck.min.js"></script>
<p class="pull-right" style="display:none">Powered by <a href="http://www.swapidc.com/">SWAPIDC</a></p>
<p><center><?php echo $_smarty_tpl->tpl_vars['c']->value['底部版权'];?>

</center></p>
</body>
</html><?php }
}
