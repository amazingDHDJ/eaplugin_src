<?php
return array(
	'plug' => 'xh_wx_qr',
	'name' => '微信',
	'version' => '0.2',
);
?>