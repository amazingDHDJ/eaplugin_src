<?php die();?>
		<div class="wepay">
		<div id="wepayimg" style="border-radius: 4px;overflow: hidden;margin-bottom: 15px;">
			<img class="img-responsive pad" src="{二维码链接}" style="margin-left: auto;margin-right: auto;">
		</div>
		<p id="wepayDiv" style="text-align: center;">请使用微信扫描二维码进行支付<br>
		请在 {最晚付款时间} 前完成支付</p>
	</div>

	

<script>
    setInterval(function(){load()}, 5000);
    function load(){
        var xmlhttp;
        if (window.XMLHttpRequest){
            xmlhttp=new XMLHttpRequest();
        }else{
            xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
        }
        xmlhttp.onreadystatechange=function(){
            if (xmlhttp.readyState==4 && xmlhttp.status==200){
                trade_state=xmlhttp.responseText;
                if(trade_state=="success"){
                    document.getElementById("wepayimg").style.display="none";
                    document.getElementById("wepayDiv").innerHTML="支付成功";
                    setTimeout(function(){tz()}, 5000);
                    function tz(){
                        window.location.href="/index.php/user/index/?success=支付成功";
                    }
                }
            }
        }
        xmlhttp.open("get","/index.php/pay/page/xh_wx_qr/invoice_status/?num={订单号}",true);
        xmlhttp.send();
    }
</script>
############################
<div class="wepay"><p id="wepayDiv" style="text-align: center;">出现错误:{错误信息}</p></div>