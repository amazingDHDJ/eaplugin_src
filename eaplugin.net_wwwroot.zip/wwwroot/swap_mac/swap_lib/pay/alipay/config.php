<?php
return array(
	'plug' => 'alipay',
	'name' => '支付宝',
	'version' => '1.0',
);
?>