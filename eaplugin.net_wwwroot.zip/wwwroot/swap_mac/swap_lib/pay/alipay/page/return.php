<?php  class alipay_notify { var $OSWAP_431f29cac8bffe0e012eeb14427bc49a; var $OSWAP_f3ebb453d13d36adfaa8089291c3ab3curity_code; var $OSWAP_a64c713b1e08083c3f630a87ade631e8ner; var $OSWAP_6ed450d6d3d53b1aa704ba0383f27444; var $OSWAP_225287386c0cdb5b14b37a8e3c32386e; var $OSWAP_ac2ff1e81fc6d3312ea6af7f10d2baa3; var $OSWAP_8aa56e2ff3d3d6a2c00f11ba0f29af83; function __construct($OSWAP_a64c713b1e08083c3f630a87ade631e8ner,$OSWAP_f3ebb453d13d36adfaa8089291c3ab3curity_code,$OSWAP_6ed450d6d3d53b1aa704ba0383f27444 = "MD5",$OSWAP_ac2ff1e81fc6d3312ea6af7f10d2baa3 = "GBK",$OSWAP_8aa56e2ff3d3d6a2c00f11ba0f29af83= "https") { $this->OSWAP_a64c713b1e08083c3f630a87ade631e8ner = $OSWAP_a64c713b1e08083c3f630a87ade631e8ner; $this->OSWAP_f3ebb453d13d36adfaa8089291c3ab3curity_code = $OSWAP_f3ebb453d13d36adfaa8089291c3ab3curity_code; $this->OSWAP_6ed450d6d3d53b1aa704ba0383f27444 = $OSWAP_6ed450d6d3d53b1aa704ba0383f27444; $this->OSWAP_225287386c0cdb5b14b37a8e3c32386e = ""; $this->OSWAP_ac2ff1e81fc6d3312ea6af7f10d2baa3 = $OSWAP_ac2ff1e81fc6d3312ea6af7f10d2baa3 ; $this->OSWAP_8aa56e2ff3d3d6a2c00f11ba0f29af83 = $OSWAP_8aa56e2ff3d3d6a2c00f11ba0f29af83; if($this->OSWAP_8aa56e2ff3d3d6a2c00f11ba0f29af83 == "https") { $this->OSWAP_431f29cac8bffe0e012eeb14427bc49a = "https://www.alipay.com/cooperate/gateway.do?"; }else $this->OSWAP_431f29cac8bffe0e012eeb14427bc49a = "http://notify.alipay.com/trade/notify_query.do?"; } function notify_verify() { if($this->OSWAP_8aa56e2ff3d3d6a2c00f11ba0f29af83 == "https") { $OSWAP_4d6902fba15d85483e1b989181b38045yfy_url = $this->OSWAP_431f29cac8bffe0e012eeb14427bc49a. "service=notify_verify" ."&partner=" .$this->OSWAP_a64c713b1e08083c3f630a87ade631e8ner. "&notify_id=".$_POST["notify_id"]; } else { $OSWAP_4d6902fba15d85483e1b989181b38045yfy_url = $this->OSWAP_431f29cac8bffe0e012eeb14427bc49a. "partner=".$this->OSWAP_a64c713b1e08083c3f630a87ade631e8ner."&notify_id=".$_POST["notify_id"]; } $OSWAP_4d6902fba15d85483e1b989181b38045yfy_result = $this->get_verify($OSWAP_4d6902fba15d85483e1b989181b38045yfy_url); $OSWAP_4280f94494d196d28603f74a9c493fdb = $this->para_filter($_POST); $OSWAP_32ec39fb445229b539378e4aa4681768 = $this->arg_sort($OSWAP_4280f94494d196d28603f74a9c493fdb); while (list ($OSWAP_97cfcd00b82e2107a72b97f617206180, $OSWAP_98f21589487af96ba370d9ceef4cb812) = each ($OSWAP_32ec39fb445229b539378e4aa4681768)) { $OSWAP_3df3c56be273b52303bbdf50430d9ed2.=$OSWAP_97cfcd00b82e2107a72b97f617206180."=".$OSWAP_98f21589487af96ba370d9ceef4cb812."&"; } $OSWAP_bc24e9446b640b47da689dc79f60cfdd = substr($OSWAP_3df3c56be273b52303bbdf50430d9ed2,0,count($OSWAP_3df3c56be273b52303bbdf50430d9ed2)-2); $this->OSWAP_225287386c0cdb5b14b37a8e3c32386e = $this->sign($OSWAP_bc24e9446b640b47da689dc79f60cfdd.$this->OSWAP_f3ebb453d13d36adfaa8089291c3ab3curity_code); if (preg_match("true$",$OSWAP_4d6902fba15d85483e1b989181b38045yfy_result) && $this->OSWAP_225287386c0cdb5b14b37a8e3c32386e == $_POST["sign"]) { return true; } else return false; } function return_verify() { $OSWAP_695d5789fd6f594e866dbaec6dcbac14= $this->arg_sort($_GET); while (list ($OSWAP_97cfcd00b82e2107a72b97f617206180, $OSWAP_98f21589487af96ba370d9ceef4cb812) = each ($OSWAP_695d5789fd6f594e866dbaec6dcbac14)) { if($OSWAP_97cfcd00b82e2107a72b97f617206180 != "sign" && $OSWAP_97cfcd00b82e2107a72b97f617206180 != "sign_type") $OSWAP_3df3c56be273b52303bbdf50430d9ed2.=$OSWAP_97cfcd00b82e2107a72b97f617206180."=".$OSWAP_98f21589487af96ba370d9ceef4cb812."&"; } $OSWAP_bc24e9446b640b47da689dc79f60cfdd = substr($OSWAP_3df3c56be273b52303bbdf50430d9ed2,0,count($OSWAP_3df3c56be273b52303bbdf50430d9ed2)-2); $this->OSWAP_225287386c0cdb5b14b37a8e3c32386e = $this->sign($OSWAP_bc24e9446b640b47da689dc79f60cfdd.$this->OSWAP_f3ebb453d13d36adfaa8089291c3ab3curity_code); if ($this->OSWAP_225287386c0cdb5b14b37a8e3c32386e == $_GET["sign"]) return true; else return false; } function get_verify($OSWAP_d7f69c033c1c5cf53c9b6a9d590a51ff,$OSWAP_3a74643c567c8fc28a98414ca92d6361_out = "60") { $OSWAP_d7f69c033c1c5cf53c9b6a9d590a51ffarr = parse_url($OSWAP_d7f69c033c1c5cf53c9b6a9d590a51ff); $OSWAP_36a1ef18ef8b83c8c4ef4328740e69ab = ""; $OSWAP_722ceb00277fe6d44fcaa63bb62cbf66 = ""; $OSWAP_8aa56e2ff3d3d6a2c00f11ba0f29af83s = ""; if($OSWAP_d7f69c033c1c5cf53c9b6a9d590a51ffarr["scheme"] == "https") { $OSWAP_8aa56e2ff3d3d6a2c00f11ba0f29af83s = "ssl://"; $OSWAP_d7f69c033c1c5cf53c9b6a9d590a51ffarr["port"] = "443"; } else { $OSWAP_8aa56e2ff3d3d6a2c00f11ba0f29af83s = "tcp://"; $OSWAP_d7f69c033c1c5cf53c9b6a9d590a51ffarr["port"] = "80"; } $fp=@fsockopen($OSWAP_8aa56e2ff3d3d6a2c00f11ba0f29af83s . $OSWAP_d7f69c033c1c5cf53c9b6a9d590a51ffarr['host'],$OSWAP_d7f69c033c1c5cf53c9b6a9d590a51ffarr['port'],$OSWAP_36a1ef18ef8b83c8c4ef4328740e69ab,$OSWAP_722ceb00277fe6d44fcaa63bb62cbf66,$OSWAP_3a74643c567c8fc28a98414ca92d6361_out); if(!$fp) { die("ERROR: $OSWAP_36a1ef18ef8b83c8c4ef4328740e69ab - $OSWAP_722ceb00277fe6d44fcaa63bb62cbf66<br />\n"); } else { fputs($fp, "POST ".$OSWAP_d7f69c033c1c5cf53c9b6a9d590a51ffarr["path"]." HTTP/1.1\r\n"); fputs($fp, "Host: ".$OSWAP_d7f69c033c1c5cf53c9b6a9d590a51ffarr["host"]."\r\n"); fputs($fp, "Content-type: application/x-www-form-urlencoded\r\n"); fputs($fp, "Content-length: ".strlen($OSWAP_d7f69c033c1c5cf53c9b6a9d590a51ffarr["query"])."\r\n"); fputs($fp, "Connection: close\r\n\r\n"); fputs($fp, $OSWAP_d7f69c033c1c5cf53c9b6a9d590a51ffarr["query"] . "\r\n\r\n"); while(!feof($fp)) { $OSWAP_74adb23fc25ca2e442d3e49f1f16660c[]=@fgets($fp, 1024); } fclose($fp); $OSWAP_74adb23fc25ca2e442d3e49f1f16660c = implode(",",$OSWAP_74adb23fc25ca2e442d3e49f1f16660c); while (list ($OSWAP_97cfcd00b82e2107a72b97f617206180, $OSWAP_98f21589487af96ba370d9ceef4cb812) = each ($_POST)) { $OSWAP_3df3c56be273b52303bbdf50430d9ed2.=$OSWAP_97cfcd00b82e2107a72b97f617206180."=".$OSWAP_98f21589487af96ba370d9ceef4cb812."&"; } return $OSWAP_74adb23fc25ca2e442d3e49f1f16660c; } } function arg_sort($OSWAP_622055c48c8765a7423a710e59131417) { ksort($OSWAP_622055c48c8765a7423a710e59131417); reset($OSWAP_622055c48c8765a7423a710e59131417); return $OSWAP_622055c48c8765a7423a710e59131417; } function sign($OSWAP_bc24e9446b640b47da689dc79f60cfdd) { $OSWAP_8d3c9b3f1b2da2c93e074dbf49ebed40=''; if($this->OSWAP_6ed450d6d3d53b1aa704ba0383f27444 == 'MD5') { $OSWAP_8d3c9b3f1b2da2c93e074dbf49ebed40 = md5($OSWAP_bc24e9446b640b47da689dc79f60cfdd); }elseif($this->OSWAP_6ed450d6d3d53b1aa704ba0383f27444 =='DSA') { die("DSA 签名方法待后续开发，请先使用MD5签名方式"); }else { die("支付宝暂不支持".$this->OSWAP_6ed450d6d3d53b1aa704ba0383f27444."类型的签名方式"); } return $OSWAP_8d3c9b3f1b2da2c93e074dbf49ebed40; } function para_filter($OSWAP_15bee76fed01e0c2203d9258aa757d87) { $OSWAP_cc7a0a08ef5d2b1699c6bb92ee41ba81 = array(); while (list ($OSWAP_97cfcd00b82e2107a72b97f617206180, $OSWAP_98f21589487af96ba370d9ceef4cb812) = each ($OSWAP_15bee76fed01e0c2203d9258aa757d87)) { if($OSWAP_97cfcd00b82e2107a72b97f617206180 == "sign" || $OSWAP_97cfcd00b82e2107a72b97f617206180 == "sign_type" || $OSWAP_98f21589487af96ba370d9ceef4cb812 == "")continue; else $OSWAP_cc7a0a08ef5d2b1699c6bb92ee41ba81[$OSWAP_97cfcd00b82e2107a72b97f617206180] = $OSWAP_15bee76fed01e0c2203d9258aa757d87[$OSWAP_97cfcd00b82e2107a72b97f617206180]; } return $OSWAP_cc7a0a08ef5d2b1699c6bb92ee41ba81; } function charset_encode($OSWAP_f27ef3a27aa58132329c3a712c9fb115,$OSWAP_937413fc6788b7ca222d6d85949a3371 ,$OSWAP_ac2ff1e81fc6d3312ea6af7f10d2baa3 ="utf-8" ) { $OSWAP_ddd61cfa17c240f4a4de3b3c7946a56e = ""; if(!isset($OSWAP_937413fc6788b7ca222d6d85949a3371) )$OSWAP_937413fc6788b7ca222d6d85949a3371 = $this->OSWAP_15bee76fed01e0c2203d9258aa757d87['_input_charset']; if($OSWAP_ac2ff1e81fc6d3312ea6af7f10d2baa3 == $OSWAP_937413fc6788b7ca222d6d85949a3371 || $OSWAP_f27ef3a27aa58132329c3a712c9fb115 ==null ) { $OSWAP_ddd61cfa17c240f4a4de3b3c7946a56e = $OSWAP_f27ef3a27aa58132329c3a712c9fb115; } elseif (function_exists("mb_convert_encoding")){ $OSWAP_ddd61cfa17c240f4a4de3b3c7946a56e = mb_convert_encoding($OSWAP_f27ef3a27aa58132329c3a712c9fb115,$OSWAP_937413fc6788b7ca222d6d85949a3371,$OSWAP_ac2ff1e81fc6d3312ea6af7f10d2baa3); } elseif(function_exists("iconv")) { $OSWAP_ddd61cfa17c240f4a4de3b3c7946a56e = iconv($OSWAP_ac2ff1e81fc6d3312ea6af7f10d2baa3,$OSWAP_937413fc6788b7ca222d6d85949a3371,$OSWAP_f27ef3a27aa58132329c3a712c9fb115); } else die("sorry, you have no libs support for charset change."); return $OSWAP_ddd61cfa17c240f4a4de3b3c7946a56e; } function charset_decode($OSWAP_f27ef3a27aa58132329c3a712c9fb115,$OSWAP_ac2ff1e81fc6d3312ea6af7f10d2baa3 ,$OSWAP_937413fc6788b7ca222d6d85949a3371="utf-8" ) { $OSWAP_ddd61cfa17c240f4a4de3b3c7946a56e = ""; if(!isset($OSWAP_ac2ff1e81fc6d3312ea6af7f10d2baa3) )$OSWAP_ac2ff1e81fc6d3312ea6af7f10d2baa3 = $this->OSWAP_ac2ff1e81fc6d3312ea6af7f10d2baa3 ; if($OSWAP_ac2ff1e81fc6d3312ea6af7f10d2baa3 == $OSWAP_937413fc6788b7ca222d6d85949a3371 || $OSWAP_f27ef3a27aa58132329c3a712c9fb115 ==null ) { $OSWAP_ddd61cfa17c240f4a4de3b3c7946a56e = $OSWAP_f27ef3a27aa58132329c3a712c9fb115; } elseif (function_exists("mb_convert_encoding")){ $OSWAP_ddd61cfa17c240f4a4de3b3c7946a56e = mb_convert_encoding($OSWAP_f27ef3a27aa58132329c3a712c9fb115,$OSWAP_937413fc6788b7ca222d6d85949a3371,$OSWAP_ac2ff1e81fc6d3312ea6af7f10d2baa3); } elseif(function_exists("iconv")) { $OSWAP_ddd61cfa17c240f4a4de3b3c7946a56e = iconv($OSWAP_ac2ff1e81fc6d3312ea6af7f10d2baa3,$OSWAP_937413fc6788b7ca222d6d85949a3371,$OSWAP_f27ef3a27aa58132329c3a712c9fb115); } else die("sorry, you have no libs support for charset changes."); return $OSWAP_ddd61cfa17c240f4a4de3b3c7946a56e; } } $OSWAP_431f29cac8bffe0e012eeb14427bc49amodule = "alipay"; $OSWAP_ac2ff1e81fc6d3312ea6af7f10d2baa3 = "utf-8"; $OSWAP_6ed450d6d3d53b1aa704ba0383f27444 = "MD5"; $OSWAP_8aa56e2ff3d3d6a2c00f11ba0f29af83 = plug_eva('alipay','transport'); $OSWAP_431f29cac8bffe0e012eeb14427bc49aPID = plug_eva('alipay','partnerID'); $OSWAP_431f29cac8bffe0e012eeb14427bc49aSELLER_EMAIL = plug_eva('alipay','seller_email'); $OSWAP_431f29cac8bffe0e012eeb14427bc49aSECURITY_CODE = plug_eva('alipay','security_code'); $OSWAP_5ec1cbc5a7641d96ed7d404680b6c487 = new alipay_notify($OSWAP_431f29cac8bffe0e012eeb14427bc49aPID,$OSWAP_431f29cac8bffe0e012eeb14427bc49aSECURITY_CODE,$OSWAP_6ed450d6d3d53b1aa704ba0383f27444,$OSWAP_ac2ff1e81fc6d3312ea6af7f10d2baa3,$OSWAP_8aa56e2ff3d3d6a2c00f11ba0f29af83); $OSWAP_4d6902fba15d85483e1b989181b38045ify_result = $OSWAP_5ec1cbc5a7641d96ed7d404680b6c487->return_verify(); if($OSWAP_4d6902fba15d85483e1b989181b38045ify_result) { $OSWAP_0c65ceb49cb8858f83d8fd876b2f8a29 = $_GET['trade_status']; $OSWAP_a663b95c68806f869fa5cb9b96b5ec76 = $_GET['out_trade_no']; $OSWAP_854f62c9d8cf90559581fdc0f5d25f45 = $_GET['trade_no']; $OSWAP_7f509ebacf2d428d54266a3df762a079 = $_GET['total_fee']; $OSWAP_9c5091935c2039f14e81264e2ebd889f = 0; if($OSWAP_0c65ceb49cb8858f83d8fd876b2f8a29 == 'TRADE_FINISHED' || $OSWAP_0c65ceb49cb8858f83d8fd876b2f8a29 == 'TRADE_SUCCESS') { Pay::order_success($OSWAP_a663b95c68806f869fa5cb9b96b5ec76); } } ?>
<!DOCTYPE html> 
<html> 
<head> 
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8"> 
	<title>支付宝支付页面</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link href="https://apps.bdimg.com/libs/bootstrap/3.3.4/css/bootstrap.min.css" rel="stylesheet" type="text/css">
<style>
body {
	padding-top: 60px;
	padding-bottom: 40px;
	font-family: 'HanHei SC', 'PingFang SC', 'Helvetica Neue', 'Helvetica', 'STHeitiSC-Light', 'Arial', sans-serif;
}
.well {
	padding: 0;
	box-shadow: none;
	border-color: #E4E4E4;
	background-color: #FFF;
}
.header {
	padding: 30px 50px;
}
.logo {
	font-size: 28px;
	margin: 0;
	line-height: 30px;
	font-weight: 300;
	font-family: Raleway, sans-serif;
}
.content {
	padding: 30px;
	border-top: 1px solid #E3E3E3;
	border-bottom: 1px solid #E3E3E3;
	background-color: #F8F9FB;
}
.content h2 {
	font-weight: 300;
}
.footer {
	padding: 30px 50px;
}
.footer p {
	color: #222;
	font-size: 16px;
	line-height: 26px;
	font-weight: 300;
}
.footer p span {
	color: #777;
}

.btn {
	color: #444;
	font-size: 16px;
	font-weight: 300;
	margin-top: 30px;
	border-radius: 3px;
	border-color: #E2E7EB;
	background-color: #E2E7EB;
}
.btn:hover {
	color: #777;
	border-color: #E2E7EB;
	background-color: #E2E7EB;
}

.sa-icon.sa-success {
    border-color: #A5DC86;
}
.sa-icon {
    width: 80px;
    height: 80px;
    border: 4px solid gray;
    -webkit-border-radius: 40px;
    border-radius: 40px;
    border-radius: 50%;
    margin: 20px auto;
    padding: 0;
    position: relative;
    box-sizing: content-box;
}
.sa-icon.sa-success .sa-line.sa-tip {
    -ms-transform: rotate(45deg) \9;
}
.sa-icon.sa-success .sa-line.sa-tip {
    width: 25px;
    left: 14px;
    top: 46px;
    -webkit-transform: rotate(45deg);
    transform: rotate(45deg);
}
.sa-icon.sa-success .sa-line.sa-long {
    width: 47px;
    right: 8px;
    top: 38px;
    -webkit-transform: rotate(-45deg);
    transform: rotate(-45deg);
}
.sa-icon.sa-success .sa-line {
    height: 5px;
    background-color: #A5DC86;
    display: block;
    border-radius: 2px;
    position: absolute;
    z-index: 2;
}
.animateSuccessTip {
    -webkit-animation: animateSuccessTip 0.75s;
    animation: animateSuccessTip 0.75s;
}
.animateSuccessLong {
    -webkit-animation: animateSuccessLong 0.75s;
    animation: animateSuccessLong 0.75s;
}
.sa-icon.sa-success .sa-placeholder {
    width: 80px;
    height: 80px;
    border: 4px solid rgba(165, 220, 134, 0.2);
    -webkit-border-radius: 40px;
    border-radius: 40px;
    border-radius: 50%;
    box-sizing: content-box;
    position: absolute;
    left: -4px;
    top: -4px;
    z-index: 2;
}
.sa-icon.sa-error {
    border-color: #F27474;
}
.sa-icon.sa-error .sa-x-mark {
    position: relative;
    display: block;
}
.sa-icon.sa-error .sa-line {
    position: absolute;
    height: 5px;
    width: 47px;
    background-color: #F27474;
    display: block;
    top: 37px;
    border-radius: 2px;
}
.sa-icon.sa-error .sa-line.sa-left {
    -webkit-transform: rotate(45deg);
    transform: rotate(45deg);
    left: 17px;
}
.sa-icon.sa-error .sa-line.sa-right {
    -webkit-transform: rotate(-45deg);
    transform: rotate(-45deg);
    right: 16px;
}
@-webkit-keyframes animateSuccessTip {
    0% {
        width: 0;
        left: 1px;
        top: 19px;
    }
    54% {
        width: 0;
        left: 1px;
        top: 19px;
    }
    70% {
        width: 50px;
        left: -8px;
        top: 37px;
    }
    84% {
        width: 17px;
        left: 21px;
        top: 48px;
    }
    100% {
        width: 25px;
        left: 14px;
        top: 45px;
    }
}
@keyframes animateSuccessTip {
    0% {
        width: 0;
        left: 1px;
        top: 19px;
    }
    54% {
        width: 0;
        left: 1px;
        top: 19px;
    }
    70% {
        width: 50px;
        left: -8px;
        top: 37px;
    }
    84% {
        width: 17px;
        left: 21px;
        top: 48px;
    }
    100% {
        width: 25px;
        left: 14px;
        top: 45px;
    }
}
@-webkit-keyframes animateSuccessLong {
    0% {
        width: 0;
        right: 46px;
        top: 54px;
    }
    65% {
        width: 0;
        right: 46px;
        top: 54px;
    }
    84% {
        width: 55px;
        right: 0px;
        top: 35px;
    }
    100% {
        width: 47px;
        right: 8px;
        top: 38px;
    }
}
@keyframes animateSuccessLong {
    0% {
        width: 0;
        right: 46px;
        top: 54px;
    }
    65% {
        width: 0;
        right: 46px;
        top: 54px;
    }
    84% {
        width: 55px;
        right: 0px;
        top: 35px;
    }
    100% {
        width: 47px;
        right: 8px;
        top: 38px;
    }
}
@-webkit-keyframes animateErrorIcon {
    0% {
        transform: rotateX(100deg);
        -webkit-transform: rotateX(100deg);
        opacity: 0;
    }
    100% {
        transform: rotateX(0deg);
        -webkit-transform: rotateX(0deg);
        opacity: 1;
    }
}
@keyframes animateErrorIcon {
    0% {
        transform: rotateX(100deg);
        -webkit-transform: rotateX(100deg);
        opacity: 0;
    }
    100% {
        transform: rotateX(0deg);
        -webkit-transform: rotateX(0deg);
        opacity: 1;
    }
}
.animateErrorIcon {
    -webkit-animation: animateErrorIcon 0.5s;
    animation: animateErrorIcon 0.5s;
}
@-webkit-keyframes animateXMark {
    0% {
        transform: scale(0.4);
        -webkit-transform: scale(0.4);
        margin-top: 26px;
        opacity: 0;
    }
    50% {
        transform: scale(0.4);
        -webkit-transform: scale(0.4);
        margin-top: 26px;
        opacity: 0;
    }
    80% {
        transform: scale(1.15);
        -webkit-transform: scale(1.15);
        margin-top: -6px;
    }
    100% {
        transform: scale(1);
        -webkit-transform: scale(1);
        margin-top: 0;
        opacity: 1;
    }
}
@keyframes animateXMark {
    0% {
        transform: scale(0.4);
        -webkit-transform: scale(0.4);
        margin-top: 26px;
        opacity: 0;
    }
    50% {
        transform: scale(0.4);
        -webkit-transform: scale(0.4);
        margin-top: 26px;
        opacity: 0;
    }
    80% {
        transform: scale(1.15);
        -webkit-transform: scale(1.15);
        margin-top: -6px;
    }
    100% {
        transform: scale(1);
        -webkit-transform: scale(1);
        margin-top: 0;
        opacity: 1;
    }
}
.animateXMark {
    -webkit-animation: animateXMark 0.5s;
    animation: animateXMark 0.5s;
}
</style>
</head> 
<body>
<div class="container">
	<div class="row">
		<div class="col-xs-10 col-xs-offset-1 col-sm-8 col-sm-offset-2 col-md-6 col-md-offset-3">
			<div class="well">
				<div class="header">
					<h1 class="logo"><?php echo _C('网站名称'); ?></h1>
				</div>
				<div class="content">
					<div class="row">
						<div class="col-sm-12">
	<?php if($OSWAP_0c65ceb49cb8858f83d8fd876b2f8a29 == 'TRADE_FINISHED' || $OSWAP_0c65ceb49cb8858f83d8fd876b2f8a29 == 'TRADE_SUCCESS') {?>
							<div class="sa-icon sa-success animate">
								<span class="sa-line sa-tip animateSuccessTip"></span>
								<span class="sa-line sa-long animateSuccessLong"></span>
								<div class="sa-placeholder"></div>
								<div class="sa-fix"></div>
						    </div>
	<?php } else {?>
							<div class="sa-icon sa-error animateErrorIcon">
								<span class="sa-x-mark animateXMark">
									<span class="sa-line sa-left"></span>
									<span class="sa-line sa-right"></span>
								</span>
							</div>
	<?php }?>
						</div>
						<div class="col-sm-12 text-center">
	<?php if($OSWAP_0c65ceb49cb8858f83d8fd876b2f8a29 == 'TRADE_FINISHED' || $OSWAP_0c65ceb49cb8858f83d8fd876b2f8a29 == 'TRADE_SUCCESS') {?>
							<h2>您已成功支付 <?php echo $OSWAP_7f509ebacf2d428d54266a3df762a079; ?> CNY </h2>
	<?php } else {?>
							<h2>奥...好像那里出错了</h2>
	<?php }?>
						</div>
					</div>
				</div>
				<div class="footer">
	<?php if($OSWAP_0c65ceb49cb8858f83d8fd876b2f8a29 == 'TRADE_FINISHED' || $OSWAP_0c65ceb49cb8858f83d8fd876b2f8a29 == 'TRADE_SUCCESS') {?>
					<p>交易编号：<span><?php echo $OSWAP_854f62c9d8cf90559581fdc0f5d25f45 ?></span></p>
					<p>请检查充值账单是否到账。</p>
	<?php } else {?>
					<p class="text-center">貌似是什么地方出了一些问题！</p>
	<?php }?>
					<a href="/index.php/user/pay/" class="btn btn-lg btn-success btn-block">返回用户中心</a>
				</div>
			</div>
		</div>
	</div>
</div>
</body> 
</html>