<?php
return array(
	'plug' => 'paypal',
	'name' => 'PayPal',
	'version' => '1.0',
);
?>