<?php  function paypal_show(){ $configarray = array( 'plug' => 'paypal', 'name' => 'PayPal', 'text' => '国际最大支付平台，安全保障、支付自如！', 'icon' => 'paypal-icon', ); return $configarray; } function paypal_config() { $configarray = array( "paypal帐户" => array("FriendlyName" => "PayPal帐户", "Type" => "text", "Size" => "32", ), "sandbox调试模式" => array("FriendlyName" => "SandBox调试模式", "Type" => "yesno", ), ); return $configarray; } function paypal_link($OSWAP_cae2c6011a45b0ae61b29cf10afc322b,$OSWAP_a663b95c68806f869fa5cb9b96b5ec76) { global $swap_mac; $OSWAP_fb8a1a8701e003acc22199aed091d3ae = $OSWAP_a663b95c68806f869fa5cb9b96b5ec76; $OSWAP_9e990043f45617a4ac37ab3a1a54cb8f=$swap_mac['c']['网站名称']; $OSWAP_6018f6a8839e14f8ebecce03a97f97a1 = plug_eva('paypal','paypal帐户'); $OSWAP_a48deb8bee9b95d07fe3cf4a2be31342 = plug_eva('paypal','sandbox调试模式'); $OSWAP_d2a5603df39a879873dbb93804d5f2ce=plug_eva('paypal','货币后缀'); if($OSWAP_a48deb8bee9b95d07fe3cf4a2be31342){ $OSWAP_d7f69c033c1c5cf53c9b6a9d590a51ff='https://www.sandbox.paypal.com/cgi-bin/webscr'; }else{ $OSWAP_d7f69c033c1c5cf53c9b6a9d590a51ff='https://www.paypal.com/cgi-bin/webscr'; } $OSWAP_d4bdf5eaa5cbb86a8fc8b02fbf81884d_url="http://".$_SERVER['SERVER_NAME']."/index.php/user/pay/"; $OSWAP_39ec1cfbd379e7ec852daec92926134b="http://".$_SERVER['SERVER_NAME']."/index.php/pay/page/paypal/notify/"; $OSWAP_8fcbbeaaa3240aa9074771fac4023339="http://".$_SERVER['SERVER_NAME']."/index.php/user/pay/"; $OSWAP_3873857b0d4fc18c764bd207febee031_text=<<<SWAP
<form action="{$OSWAP_d7f69c033c1c5cf53c9b6a9d590a51ff}" name="paypalform" method="post">
<input type="hidden" name="business" value="{$OSWAP_6018f6a8839e14f8ebecce03a97f97a1}">
<input type="hidden" name="item_name" value="{$OSWAP_9e990043f45617a4ac37ab3a1a54cb8f}充值账单">
<input type="hidden" name="amount" value="{$OSWAP_cae2c6011a45b0ae61b29cf10afc322b}">
<input type="hidden" name="no_note" value="1">
<input type="hidden" name="return"  value="{$OSWAP_d4bdf5eaa5cbb86a8fc8b02fbf81884d_url}">
<input type="hidden" name="cancel_return" value="{$OSWAP_8fcbbeaaa3240aa9074771fac4023339}">
<input type="hidden" name="custom" value="{$OSWAP_fb8a1a8701e003acc22199aed091d3ae}">
<input type="hidden" name="notify_url" value="{$OSWAP_39ec1cfbd379e7ec852daec92926134b}">
<input type="hidden" name="cmd" value="_xclick">
<input type="hidden" name="currency_code" value="{$OSWAP_d2a5603df39a879873dbb93804d5f2ce}">
<input type="hidden" name="charset" value="utf-8" />
<input type="hidden" name="rm" value="1" />
</form>
<script type="text/javascript">
document.paypalform.submit();
</script>
SWAP;
 return $OSWAP_3873857b0d4fc18c764bd207febee031_text; } 