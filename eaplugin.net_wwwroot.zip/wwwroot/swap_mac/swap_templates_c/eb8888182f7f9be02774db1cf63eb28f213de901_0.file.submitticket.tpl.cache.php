<?php
/* Smarty version 3.1.30, created on 2017-06-12 13:30:31
  from "/home/ftp/s/s7234915/wwwroot/templates/goule_bootstrap/submitticket.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_593e26f7af7077_44496786',
  'has_nocache_code' => true,
  'file_dependency' => 
  array (
    'eb8888182f7f9be02774db1cf63eb28f213de901' => 
    array (
      0 => '/home/ftp/s/s7234915/wwwroot/templates/goule_bootstrap/submitticket.tpl',
      1 => 1497237650,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:top.tpl' => 1,
    'file:left.tpl' => 1,
    'file:copyright.tpl' => 1,
    'file:alert.tpl' => 1,
    'file:copyright2.tpl' => 1,
  ),
),false)) {
function content_593e26f7af7077_44496786 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->compiled->nocache_hash = '837908692593e26f7a9d046_92027437';
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?php echo '/*%%SmartyNocache:837908692593e26f7a9d046_92027437%%*/<?php echo $_smarty_tpl->tpl_vars[\'c\']->value[\'网站名称\'];?>
/*/%%SmartyNocache:837908692593e26f7a9d046_92027437%%*/';?>
 - <?php echo '/*%%SmartyNocache:837908692593e26f7a9d046_92027437%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'提交服务单\'];?>
/*/%%SmartyNocache:837908692593e26f7a9d046_92027437%%*/';?>
</title>
<link href="<?php echo '/*%%SmartyNocache:837908692593e26f7a9d046_92027437%%*/<?php echo $_smarty_tpl->tpl_vars[\'templatedir\']->value;?>
/*/%%SmartyNocache:837908692593e26f7a9d046_92027437%%*/';?>
/css/bootstrap.min.css" rel="stylesheet">
<link href="<?php echo '/*%%SmartyNocache:837908692593e26f7a9d046_92027437%%*/<?php echo $_smarty_tpl->tpl_vars[\'templatedir\']->value;?>
/*/%%SmartyNocache:837908692593e26f7a9d046_92027437%%*/';?>
/css/datepicker3.css" rel="stylesheet">
<link href="<?php echo '/*%%SmartyNocache:837908692593e26f7a9d046_92027437%%*/<?php echo $_smarty_tpl->tpl_vars[\'templatedir\']->value;?>
/*/%%SmartyNocache:837908692593e26f7a9d046_92027437%%*/';?>
/css/styles.css" rel="stylesheet">

<!--[if lt IE 9]>
<?php echo '<script'; ?>
 src="<?php echo '/*%%SmartyNocache:837908692593e26f7a9d046_92027437%%*/<?php echo $_smarty_tpl->tpl_vars[\'templatedir\']->value;?>
/*/%%SmartyNocache:837908692593e26f7a9d046_92027437%%*/';?>
/js/html5shiv.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="<?php echo '/*%%SmartyNocache:837908692593e26f7a9d046_92027437%%*/<?php echo $_smarty_tpl->tpl_vars[\'templatedir\']->value;?>
/*/%%SmartyNocache:837908692593e26f7a9d046_92027437%%*/';?>
/js/respond.min.js"><?php echo '</script'; ?>
>
<![endif]-->

</head>
<body>
  <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
    <div class="container-fluid">
      <div class="navbar-header">
        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#sidebar-collapse">
          <span class="sr-only">Toggle navigation</span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
        </button>
        <a class="navbar-brand" href="/"><span><?php echo '/*%%SmartyNocache:837908692593e26f7a9d046_92027437%%*/<?php echo $_smarty_tpl->tpl_vars[\'c\']->value[\'头部LOGO\'];?>
/*/%%SmartyNocache:837908692593e26f7a9d046_92027437%%*/';?>
</span> <?php echo '/*%%SmartyNocache:837908692593e26f7a9d046_92027437%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'提交服务单\'];?>
/*/%%SmartyNocache:837908692593e26f7a9d046_92027437%%*/';?>
</a>
        <?php $_smarty_tpl->_subTemplateRender("file:top.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 9999, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

      </div>
    </div><!-- /.container-fluid -->
  </nav>
    
  <div id="sidebar-collapse" class="col-sm-3 col-lg-2 sidebar">
    <form role="search">
      <div class="form-group">
        <input type="text" class="form-control" placeholder="搜索 (不可用)">
      </div>
    </form>
    <ul class="nav menu">
      <li><a href="<?php echo '/*%%SmartyNocache:837908692593e26f7a9d046_92027437%%*/<?php echo $_smarty_tpl->tpl_vars[\'ROOT\']->value;?>
/*/%%SmartyNocache:837908692593e26f7a9d046_92027437%%*/';?>
/index/"><span class="glyphicon glyphicon-dashboard"></span> <?php echo '/*%%SmartyNocache:837908692593e26f7a9d046_92027437%%*/<?php echo $_smarty_tpl->tpl_vars[\'mlang\']->value[\'仪表盘\'];?>
/*/%%SmartyNocache:837908692593e26f7a9d046_92027437%%*/';?>
</a></li>
      <li class="parent">
        <a data-toggle="collapse" href="#sub-item-1">
          <span class="glyphicon glyphicon-hdd"></span> <?php echo '/*%%SmartyNocache:837908692593e26f7a9d046_92027437%%*/<?php echo $_smarty_tpl->tpl_vars[\'mlang\']->value[\'客户中心\'];?>
/*/%%SmartyNocache:837908692593e26f7a9d046_92027437%%*/';?>
 <span class="icon pull-right"><em class="glyphicon glyphicon-s glyphicon-plus"></em></span> 
        </a>
        <ul class="children collapse" id="sub-item-1">
          <li>
            <a class="" href="<?php echo '/*%%SmartyNocache:837908692593e26f7a9d046_92027437%%*/<?php echo $_smarty_tpl->tpl_vars[\'ROOT\']->value;?>
/*/%%SmartyNocache:837908692593e26f7a9d046_92027437%%*/';?>
/buy/">
              <span class="glyphicon glyphicon-shopping-cart"></span> <?php echo '/*%%SmartyNocache:837908692593e26f7a9d046_92027437%%*/<?php echo $_smarty_tpl->tpl_vars[\'mlang\']->value[\'订购产品\'];?>
/*/%%SmartyNocache:837908692593e26f7a9d046_92027437%%*/';?>

            </a>
          </li>
          <li>
            <a class="" href="<?php echo '/*%%SmartyNocache:837908692593e26f7a9d046_92027437%%*/<?php echo $_smarty_tpl->tpl_vars[\'ROOT\']->value;?>
/*/%%SmartyNocache:837908692593e26f7a9d046_92027437%%*/';?>
/control/">
              <span class="glyphicon glyphicon-tasks"></span> <?php echo '/*%%SmartyNocache:837908692593e26f7a9d046_92027437%%*/<?php echo $_smarty_tpl->tpl_vars[\'mlang\']->value[\'控制面板\'];?>
/*/%%SmartyNocache:837908692593e26f7a9d046_92027437%%*/';?>
  
            </a>
          </li>
        </ul>
      </li>
      <li><a href="<?php echo '/*%%SmartyNocache:837908692593e26f7a9d046_92027437%%*/<?php echo $_smarty_tpl->tpl_vars[\'ROOT\']->value;?>
/*/%%SmartyNocache:837908692593e26f7a9d046_92027437%%*/';?>
/help/"><span class="glyphicon glyphicon-list-alt"></span> <?php echo '/*%%SmartyNocache:837908692593e26f7a9d046_92027437%%*/<?php echo $_smarty_tpl->tpl_vars[\'mlang\']->value[\'帮助中心\'];?>
/*/%%SmartyNocache:837908692593e26f7a9d046_92027437%%*/';?>
</a></li>
	  <li><a href="<?php echo '/*%%SmartyNocache:837908692593e26f7a9d046_92027437%%*/<?php echo $_smarty_tpl->tpl_vars[\'ROOT\']->value;?>
/*/%%SmartyNocache:837908692593e26f7a9d046_92027437%%*/';?>
/user/pay/"><span class="glyphicon glyphicon-jpy"></span><?php echo '/*%%SmartyNocache:837908692593e26f7a9d046_92027437%%*/<?php echo $_smarty_tpl->tpl_vars[\'mlang\']->value[\'账户充值\'];?>
/*/%%SmartyNocache:837908692593e26f7a9d046_92027437%%*/';?>
</a></li>
      <li role="presentation" class="divider"></li>
      <?php $_smarty_tpl->_subTemplateRender("file:left.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 9999, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    </ul>
<?php $_smarty_tpl->_subTemplateRender("file:copyright.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 9999, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

  </div><!--/.sidebar-->
    
  <div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">   
    <div class="row">
      <ol class="breadcrumb">
        <li><span class="glyphicon glyphicon-home"></span></li>
        <li><?php echo '/*%%SmartyNocache:837908692593e26f7a9d046_92027437%%*/<?php echo $_smarty_tpl->tpl_vars[\'mlang\']->value[\'服务单\'];?>
/*/%%SmartyNocache:837908692593e26f7a9d046_92027437%%*/';?>
</li>
        <li class="active">工单提交</li>
      </ol>
    </div><!--/.row-->
    <br/>
    <div class="row">
      <div class="col-md-12">
        <?php $_smarty_tpl->_subTemplateRender("file:alert.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 9999, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

        <div class="panel panel-default">
          <div class="panel-heading"><span class="glyphicon glyphicon-edit"></span> 工单提交</div>
          <div class="panel-body">
            <form class="form-horizontal" method="post">
              <fieldset>
                <!-- Name input-->
                <div class="form-group">
                  <label class="col-md-3 control-label" for="name">服务ID</label>
                  <div class="col-md-9">
                  <input id="name" name="name" type="text" placeholder="请在<?php echo '/*%%SmartyNocache:837908692593e26f7a9d046_92027437%%*/<?php echo $_smarty_tpl->tpl_vars[\'mlang\']->value[\'控制面板\'];?>
/*/%%SmartyNocache:837908692593e26f7a9d046_92027437%%*/';?>
查看服务ID" class="form-control">
                  </div>
                </div>
              
                <!-- Email input-->
                <div class="form-group">
                  <label class="col-md-3 control-label" for="email">E-mail</label>
                  <div class="col-md-9">
                    <input id="email" name="email" type="text" placeholder="您的邮箱地址" class="form-control">
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-md-3 control-label" for="titie">工单主题</label>
                  <div class="col-md-9">
                    <input id="titie" name="subject" type="text" placeholder="工单标题" class="form-control">
                  </div>
                </div>
                <!-- Message body -->
                <div class="form-group">
                  <label class="col-md-3 control-label" for="message">工单信息</label>
                  <div class="col-md-9">
                    <textarea class="form-control" id="message" name="message" placeholder="请详细说明主机出现的问题,以便快速解决!" rows="5"></textarea>
                  </div>
                </div>
                
                <!-- Form actions -->
                <div class="form-group">
                  <div class="col-md-12 widget-right">
                    <button type="submit" class="btn btn-default btn-md pull-right"><?php echo '/*%%SmartyNocache:837908692593e26f7a9d046_92027437%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'提交\'];?>
/*/%%SmartyNocache:837908692593e26f7a9d046_92027437%%*/';?>
</button>
                  </div>
                </div>
              </fieldset>
            </form>
          </div>
        </div>
      </div><!--/.col-->
    </div><!--/.row-->
    <?php $_smarty_tpl->_subTemplateRender("file:copyright2.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 9999, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

  </div>  <!--/.main-->
      
  <?php echo '<script'; ?>
 src="<?php echo '/*%%SmartyNocache:837908692593e26f7a9d046_92027437%%*/<?php echo $_smarty_tpl->tpl_vars[\'templatedir\']->value;?>
/*/%%SmartyNocache:837908692593e26f7a9d046_92027437%%*/';?>
/js/jquery-1.11.1.min.js"><?php echo '</script'; ?>
>
  <?php echo '<script'; ?>
 src="<?php echo '/*%%SmartyNocache:837908692593e26f7a9d046_92027437%%*/<?php echo $_smarty_tpl->tpl_vars[\'templatedir\']->value;?>
/*/%%SmartyNocache:837908692593e26f7a9d046_92027437%%*/';?>
/js/bootstrap.min.js"><?php echo '</script'; ?>
>
  <?php echo '<script'; ?>
 src="<?php echo '/*%%SmartyNocache:837908692593e26f7a9d046_92027437%%*/<?php echo $_smarty_tpl->tpl_vars[\'templatedir\']->value;?>
/*/%%SmartyNocache:837908692593e26f7a9d046_92027437%%*/';?>
/js/chart.min.js"><?php echo '</script'; ?>
>
  <?php echo '<script'; ?>
 src="<?php echo '/*%%SmartyNocache:837908692593e26f7a9d046_92027437%%*/<?php echo $_smarty_tpl->tpl_vars[\'templatedir\']->value;?>
/*/%%SmartyNocache:837908692593e26f7a9d046_92027437%%*/';?>
/js/chart-data.js"><?php echo '</script'; ?>
>
  <?php echo '<script'; ?>
 src="<?php echo '/*%%SmartyNocache:837908692593e26f7a9d046_92027437%%*/<?php echo $_smarty_tpl->tpl_vars[\'templatedir\']->value;?>
/*/%%SmartyNocache:837908692593e26f7a9d046_92027437%%*/';?>
/js/easypiechart.js"><?php echo '</script'; ?>
>
  <?php echo '<script'; ?>
 src="<?php echo '/*%%SmartyNocache:837908692593e26f7a9d046_92027437%%*/<?php echo $_smarty_tpl->tpl_vars[\'templatedir\']->value;?>
/*/%%SmartyNocache:837908692593e26f7a9d046_92027437%%*/';?>
/js/easypiechart-data.js"><?php echo '</script'; ?>
>
  <?php echo '<script'; ?>
 src="<?php echo '/*%%SmartyNocache:837908692593e26f7a9d046_92027437%%*/<?php echo $_smarty_tpl->tpl_vars[\'templatedir\']->value;?>
/*/%%SmartyNocache:837908692593e26f7a9d046_92027437%%*/';?>
/js/bootstrap-datepicker.js"><?php echo '</script'; ?>
>
  <?php echo '<script'; ?>
>
    $('#calendar').datepicker({
    });

    !function ($) {
        $(document).on("click","ul.nav li.parent > a > span.icon", function(){          
            $(this).find('em:first').toggleClass("glyphicon-minus");      
        }); 
        $(".sidebar span.icon").find('em:first').addClass("glyphicon-plus");
    }(window.jQuery);

    $(window).on('resize', function () {
      if ($(window).width() > 768) $('#sidebar-collapse').collapse('show')
    })
    $(window).on('resize', function () {
      if ($(window).width() <= 767) $('#sidebar-collapse').collapse('hide')
    })
  <?php echo '</script'; ?>
> 
</body>

</html>
<?php }
}
