<?php
/* Smarty version 3.1.30, created on 2017-06-12 11:01:01
  from "/home/ftp/s/s7234915/wwwroot/templates/XCAPP_Bootstrap3/index.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_593e03ed6302a6_62690292',
  'has_nocache_code' => true,
  'file_dependency' => 
  array (
    '6d4574dcfe2ffaca588e894b5b69cd0f2336d6b2' => 
    array (
      0 => '/home/ftp/s/s7234915/wwwroot/templates/XCAPP_Bootstrap3/index.tpl',
      1 => 1497236294,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:header.tpl' => 1,
    'file:alert.tpl' => 1,
    'file:footer.tpl' => 1,
  ),
),false)) {
function content_593e03ed6302a6_62690292 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->compiled->nocache_hash = '806248933593e03ed5a64f2_34526146';
echo '/*%%SmartyNocache:806248933593e03ed5a64f2_34526146%%*/<?php $_smarty_tpl->_subTemplateRender("file:header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(\'title\'=>$_smarty_tpl->tpl_vars[\'lang\']->value[\'客户中心\'],\'hostname\'=>$_smarty_tpl->tpl_vars[\'c\']->value[\'网站名称\']), 0, false);
?>
/*/%%SmartyNocache:806248933593e03ed5a64f2_34526146%%*/';?>


<div class="page-header">
  <h1>客户中心</h1>
</div>
<?php $_smarty_tpl->_subTemplateRender("file:alert.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 9999, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

<div class="well well-sm">
<div class="row">
  <div class="col-md-6">
<div class="list-group">
  <li class="list-group-item"><a href="<?php echo '/*%%SmartyNocache:806248933593e03ed5a64f2_34526146%%*/<?php echo $_smarty_tpl->tpl_vars[\'ROOT\']->value;?>
/*/%%SmartyNocache:806248933593e03ed5a64f2_34526146%%*/';?>
/control/index/"><?php echo '/*%%SmartyNocache:806248933593e03ed5a64f2_34526146%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'控制面板\'];?>
/*/%%SmartyNocache:806248933593e03ed5a64f2_34526146%%*/';?>
</a><h5 class="badge"><?php echo '/*%%SmartyNocache:806248933593e03ed5a64f2_34526146%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'控制面板介绍\'];?>
/*/%%SmartyNocache:806248933593e03ed5a64f2_34526146%%*/';?>
</h5></li>
  <li class="list-group-item"><a href="<?php echo '/*%%SmartyNocache:806248933593e03ed5a64f2_34526146%%*/<?php echo $_smarty_tpl->tpl_vars[\'ROOT\']->value;?>
/*/%%SmartyNocache:806248933593e03ed5a64f2_34526146%%*/';?>
/ticket/submit/"><?php echo '/*%%SmartyNocache:806248933593e03ed5a64f2_34526146%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'提交服务单\'];?>
/*/%%SmartyNocache:806248933593e03ed5a64f2_34526146%%*/';?>
</a><h5 class="badge"><?php echo '/*%%SmartyNocache:806248933593e03ed5a64f2_34526146%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'提交服务单介绍\'];?>
/*/%%SmartyNocache:806248933593e03ed5a64f2_34526146%%*/';?>
</h5></li>
  <li class="list-group-item"><a href="<?php echo '/*%%SmartyNocache:806248933593e03ed5a64f2_34526146%%*/<?php echo $_smarty_tpl->tpl_vars[\'ROOT\']->value;?>
/*/%%SmartyNocache:806248933593e03ed5a64f2_34526146%%*/';?>
/ticket/index/"><?php echo '/*%%SmartyNocache:806248933593e03ed5a64f2_34526146%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'服务单\'];?>
/*/%%SmartyNocache:806248933593e03ed5a64f2_34526146%%*/';?>
</a><h5 class="badge"><?php echo '/*%%SmartyNocache:806248933593e03ed5a64f2_34526146%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'服务单介绍\'];?>
/*/%%SmartyNocache:806248933593e03ed5a64f2_34526146%%*/';?>
</h5></li>
  <li class="list-group-item"><a href="<?php echo '/*%%SmartyNocache:806248933593e03ed5a64f2_34526146%%*/<?php echo $_smarty_tpl->tpl_vars[\'ROOT\']->value;?>
/*/%%SmartyNocache:806248933593e03ed5a64f2_34526146%%*/';?>
/networkissues/serverstatus/"><?php echo '/*%%SmartyNocache:806248933593e03ed5a64f2_34526146%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'服务器状态\'];?>
/*/%%SmartyNocache:806248933593e03ed5a64f2_34526146%%*/';?>
</a><h5 class="badge"><?php echo '/*%%SmartyNocache:806248933593e03ed5a64f2_34526146%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'服务器状态介绍\'];?>
/*/%%SmartyNocache:806248933593e03ed5a64f2_34526146%%*/';?>
</h5></li>
</div>
</div>
  <div class="col-md-6">
<div class="list-group">
  <li class="list-group-item"><a href="<?php echo '/*%%SmartyNocache:806248933593e03ed5a64f2_34526146%%*/<?php echo $_smarty_tpl->tpl_vars[\'ROOT\']->value;?>
/*/%%SmartyNocache:806248933593e03ed5a64f2_34526146%%*/';?>
/index/announcements/"><?php echo '/*%%SmartyNocache:806248933593e03ed5a64f2_34526146%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'公告信息\'];?>
/*/%%SmartyNocache:806248933593e03ed5a64f2_34526146%%*/';?>
</a><h5 class="badge"><?php echo '/*%%SmartyNocache:806248933593e03ed5a64f2_34526146%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'公告信息介绍\'];?>
/*/%%SmartyNocache:806248933593e03ed5a64f2_34526146%%*/';?>
</h5></li>
  <li class="list-group-item"><a href="<?php echo '/*%%SmartyNocache:806248933593e03ed5a64f2_34526146%%*/<?php echo $_smarty_tpl->tpl_vars[\'ROOT\']->value;?>
/*/%%SmartyNocache:806248933593e03ed5a64f2_34526146%%*/';?>
/help/index/"><?php echo '/*%%SmartyNocache:806248933593e03ed5a64f2_34526146%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'帮助中心\'];?>
/*/%%SmartyNocache:806248933593e03ed5a64f2_34526146%%*/';?>
</a><h5 class="badge"><?php echo '/*%%SmartyNocache:806248933593e03ed5a64f2_34526146%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'帮助中心介绍\'];?>
/*/%%SmartyNocache:806248933593e03ed5a64f2_34526146%%*/';?>
</h5></li>
  <li class="list-group-item"><a href="<?php echo '/*%%SmartyNocache:806248933593e03ed5a64f2_34526146%%*/<?php echo $_smarty_tpl->tpl_vars[\'ROOT\']->value;?>
/*/%%SmartyNocache:806248933593e03ed5a64f2_34526146%%*/';?>
/buy/index/"><?php echo '/*%%SmartyNocache:806248933593e03ed5a64f2_34526146%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'订购产品\'];?>
/*/%%SmartyNocache:806248933593e03ed5a64f2_34526146%%*/';?>
</a><h5 class="badge"><?php echo '/*%%SmartyNocache:806248933593e03ed5a64f2_34526146%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'订购产品介绍\'];?>
/*/%%SmartyNocache:806248933593e03ed5a64f2_34526146%%*/';?>
</h5></li>
  <li class="list-group-item"><a href="<?php echo '/*%%SmartyNocache:806248933593e03ed5a64f2_34526146%%*/<?php echo $_smarty_tpl->tpl_vars[\'ROOT\']->value;?>
/*/%%SmartyNocache:806248933593e03ed5a64f2_34526146%%*/';?>
/networkissues/index/"><?php echo '/*%%SmartyNocache:806248933593e03ed5a64f2_34526146%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'网络故障\'];?>
/*/%%SmartyNocache:806248933593e03ed5a64f2_34526146%%*/';?>
</a><h5 class="badge"><?php echo '/*%%SmartyNocache:806248933593e03ed5a64f2_34526146%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'网络故障介绍\'];?>
/*/%%SmartyNocache:806248933593e03ed5a64f2_34526146%%*/';?>
</h5></li>
</div>
</div>
    </div>

      <div class="row-fluid">
        <div class="span12">
          <div class="table-panel">
		  		<div class="btn-group pull-right">
	        <a href="<?php echo '/*%%SmartyNocache:806248933593e03ed5a64f2_34526146%%*/<?php echo $_smarty_tpl->tpl_vars[\'ROOT\']->value;?>
/*/%%SmartyNocache:806248933593e03ed5a64f2_34526146%%*/';?>
/index/announcements/" class="btn"><?php echo '/*%%SmartyNocache:806248933593e03ed5a64f2_34526146%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'更多...\'];?>
/*/%%SmartyNocache:806248933593e03ed5a64f2_34526146%%*/';?>
</a>
          </div>
            <h4> <i class="icon-bullhorn"></i><?php echo '/*%%SmartyNocache:806248933593e03ed5a64f2_34526146%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'网站公告\'];?>
/*/%%SmartyNocache:806248933593e03ed5a64f2_34526146%%*/';?>
</h4>
            <table class="table table-striped sortable table-bordered">
              <thead>
                <tr>
                  <th><?php echo '/*%%SmartyNocache:806248933593e03ed5a64f2_34526146%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'标题\'];?>
/*/%%SmartyNocache:806248933593e03ed5a64f2_34526146%%*/';?>
</th>
                  <th><?php echo '/*%%SmartyNocache:806248933593e03ed5a64f2_34526146%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'时间\'];?>
/*/%%SmartyNocache:806248933593e03ed5a64f2_34526146%%*/';?>
</th>
                </tr>
              </thead>
              <tbody>
			  <?php echo '/*%%SmartyNocache:806248933593e03ed5a64f2_34526146%%*/<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars[\'news\']->value, \'new\');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars[\'new\']->value) {
?>/*/%%SmartyNocache:806248933593e03ed5a64f2_34526146%%*/';?>

                <tr>
				  <td><a href="<?php echo '/*%%SmartyNocache:806248933593e03ed5a64f2_34526146%%*/<?php echo $_smarty_tpl->tpl_vars[\'ROOT\']->value;?>
/*/%%SmartyNocache:806248933593e03ed5a64f2_34526146%%*/';?>
/index/announcement/<?php echo '/*%%SmartyNocache:806248933593e03ed5a64f2_34526146%%*/<?php echo $_smarty_tpl->tpl_vars[\'new\']->value[\'公告ID\'];?>
/*/%%SmartyNocache:806248933593e03ed5a64f2_34526146%%*/';?>
"><?php echo '/*%%SmartyNocache:806248933593e03ed5a64f2_34526146%%*/<?php echo $_smarty_tpl->tpl_vars[\'new\']->value[\'公告标题\'];?>
/*/%%SmartyNocache:806248933593e03ed5a64f2_34526146%%*/';?>
</a></td>
                  <td><?php echo '/*%%SmartyNocache:806248933593e03ed5a64f2_34526146%%*/<?php echo $_smarty_tpl->tpl_vars[\'new\']->value[\'公告时间\'];?>
/*/%%SmartyNocache:806248933593e03ed5a64f2_34526146%%*/';?>
</td>
                </tr>
              <?php echo '/*%%SmartyNocache:806248933593e03ed5a64f2_34526146%%*/<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>
/*/%%SmartyNocache:806248933593e03ed5a64f2_34526146%%*/';?>

			  </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
    <div class="row">
  <div class="col-md-6">
      <h4><?php echo '/*%%SmartyNocache:806248933593e03ed5a64f2_34526146%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'快速导航\'];?>
/*/%%SmartyNocache:806248933593e03ed5a64f2_34526146%%*/';?>
</h4>
        <table class="table">
           <tbody>
              <tr><td><a href="<?php echo '/*%%SmartyNocache:806248933593e03ed5a64f2_34526146%%*/<?php echo $_smarty_tpl->tpl_vars[\'ROOT\']->value;?>
/*/%%SmartyNocache:806248933593e03ed5a64f2_34526146%%*/';?>
/index/index/"><span class="label label-success"><?php echo '/*%%SmartyNocache:806248933593e03ed5a64f2_34526146%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'客户中心\'];?>
/*/%%SmartyNocache:806248933593e03ed5a64f2_34526146%%*/';?>
</span></a></td></tr>
              <tr><td><a href="<?php echo '/*%%SmartyNocache:806248933593e03ed5a64f2_34526146%%*/<?php echo $_smarty_tpl->tpl_vars[\'ROOT\']->value;?>
/*/%%SmartyNocache:806248933593e03ed5a64f2_34526146%%*/';?>
/control/index/"><span class="label label-info"> <?php echo '/*%%SmartyNocache:806248933593e03ed5a64f2_34526146%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'控制面板\'];?>
/*/%%SmartyNocache:806248933593e03ed5a64f2_34526146%%*/';?>
</span></a></td></tr>
			  <tr><td><a href="<?php echo '/*%%SmartyNocache:806248933593e03ed5a64f2_34526146%%*/<?php echo $_smarty_tpl->tpl_vars[\'ROOT\']->value;?>
/*/%%SmartyNocache:806248933593e03ed5a64f2_34526146%%*/';?>
/index/announcements/"><span class="label label-warning"> <?php echo '/*%%SmartyNocache:806248933593e03ed5a64f2_34526146%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'公告信息\'];?>
/*/%%SmartyNocache:806248933593e03ed5a64f2_34526146%%*/';?>
</span></a></td></tr>
			  <tr><td><a href="<?php echo '/*%%SmartyNocache:806248933593e03ed5a64f2_34526146%%*/<?php echo $_smarty_tpl->tpl_vars[\'ROOT\']->value;?>
/*/%%SmartyNocache:806248933593e03ed5a64f2_34526146%%*/';?>
/ticket/submit/"><span class="label label-danger"> <?php echo '/*%%SmartyNocache:806248933593e03ed5a64f2_34526146%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'提交服务单\'];?>
/*/%%SmartyNocache:806248933593e03ed5a64f2_34526146%%*/';?>
</span></a></td></tr>
			  <tr><td><a href="<?php echo '/*%%SmartyNocache:806248933593e03ed5a64f2_34526146%%*/<?php echo $_smarty_tpl->tpl_vars[\'ROOT\']->value;?>
/*/%%SmartyNocache:806248933593e03ed5a64f2_34526146%%*/';?>
/buy/index/"><span class="label label-info"> <?php echo '/*%%SmartyNocache:806248933593e03ed5a64f2_34526146%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'订购产品\'];?>
/*/%%SmartyNocache:806248933593e03ed5a64f2_34526146%%*/';?>
</span></a></td></tr>
           </tbody>
        </table>
	  <hr />
	  </div>
  <div class="col-md-6">
	  <?php echo '/*%%SmartyNocache:806248933593e03ed5a64f2_34526146%%*/<?php if ((isset($_smarty_tpl->tpl_vars[\'s\']->value[\'是否已经登陆\'])?$_smarty_tpl->tpl_vars[\'s\']->value[\'是否已经登陆\']:\'\') == \'是\') {?>/*/%%SmartyNocache:806248933593e03ed5a64f2_34526146%%*/';?>

	  <h4><?php echo '/*%%SmartyNocache:806248933593e03ed5a64f2_34526146%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'账户信息\'];?>
/*/%%SmartyNocache:806248933593e03ed5a64f2_34526146%%*/';?>
</h4>
        <table class="table">
           <tbody>
              <tr><td><span class="label label-info">用户名</span><?php echo '/*%%SmartyNocache:806248933593e03ed5a64f2_34526146%%*/<?php echo $_smarty_tpl->tpl_vars[\'s\']->value[\'登陆姓名\'];?>
/*/%%SmartyNocache:806248933593e03ed5a64f2_34526146%%*/';?>
</td></tr>
              <tr><td><span class="label label-info">地址</span><?php echo '/*%%SmartyNocache:806248933593e03ed5a64f2_34526146%%*/<?php echo $_smarty_tpl->tpl_vars[\'s\']->value[\'登陆地址\'];?>
/*/%%SmartyNocache:806248933593e03ed5a64f2_34526146%%*/';?>
</td></tr>
			  <tr><td><span class="label label-info">国家</span><?php echo '/*%%SmartyNocache:806248933593e03ed5a64f2_34526146%%*/<?php echo $_smarty_tpl->tpl_vars[\'s\']->value[\'登陆国家\'];?>
/*/%%SmartyNocache:806248933593e03ed5a64f2_34526146%%*/';?>
</td></tr>
			  <tr><td><span class="label label-info">邮箱</span><?php echo '/*%%SmartyNocache:806248933593e03ed5a64f2_34526146%%*/<?php echo $_smarty_tpl->tpl_vars[\'s\']->value[\'登陆邮箱\'];?>
/*/%%SmartyNocache:806248933593e03ed5a64f2_34526146%%*/';?>
</td></tr>
           </tbody>
        </table>
	  <hr />
	  <?php echo '/*%%SmartyNocache:806248933593e03ed5a64f2_34526146%%*/<?php } else { ?>/*/%%SmartyNocache:806248933593e03ed5a64f2_34526146%%*/';?>

	  请登录<hr />
	  <?php echo '/*%%SmartyNocache:806248933593e03ed5a64f2_34526146%%*/<?php }?>/*/%%SmartyNocache:806248933593e03ed5a64f2_34526146%%*/';?>

	  <h4><?php echo '/*%%SmartyNocache:806248933593e03ed5a64f2_34526146%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'选择语言\'];?>
/*/%%SmartyNocache:806248933593e03ed5a64f2_34526146%%*/';?>
</h4>
		<form method="post" name="languagefrm" id="languagefrom">
			<select name="language" onchange="languagefrom.submit()" class="form-control">
			  <?php echo '/*%%SmartyNocache:806248933593e03ed5a64f2_34526146%%*/<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars[\'l\']->value, \'langs\');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars[\'langs\']->value) {
?>/*/%%SmartyNocache:806248933593e03ed5a64f2_34526146%%*/';?>

			  <option value="<?php echo '/*%%SmartyNocache:806248933593e03ed5a64f2_34526146%%*/<?php echo $_smarty_tpl->tpl_vars[\'langs\']->value;?>
/*/%%SmartyNocache:806248933593e03ed5a64f2_34526146%%*/';?>
"<?php echo '/*%%SmartyNocache:806248933593e03ed5a64f2_34526146%%*/<?php if ((isset($_smarty_tpl->tpl_vars[\'langs\']->value)?$_smarty_tpl->tpl_vars[\'langs\']->value:\'\') == (isset($_smarty_tpl->tpl_vars[\'language\']->value)?$_smarty_tpl->tpl_vars[\'language\']->value:\'\')) {?>/*/%%SmartyNocache:806248933593e03ed5a64f2_34526146%%*/';?>
 selected="selected"<?php echo '/*%%SmartyNocache:806248933593e03ed5a64f2_34526146%%*/<?php }?>/*/%%SmartyNocache:806248933593e03ed5a64f2_34526146%%*/';?>
><?php echo '/*%%SmartyNocache:806248933593e03ed5a64f2_34526146%%*/<?php echo $_smarty_tpl->tpl_vars[\'langs\']->value;?>
/*/%%SmartyNocache:806248933593e03ed5a64f2_34526146%%*/';?>
</option>
			  <?php echo '/*%%SmartyNocache:806248933593e03ed5a64f2_34526146%%*/<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>
/*/%%SmartyNocache:806248933593e03ed5a64f2_34526146%%*/';?>

			</select>
		</form>
    </div>
  </div>
<?php $_smarty_tpl->_subTemplateRender("file:footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 9999, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
