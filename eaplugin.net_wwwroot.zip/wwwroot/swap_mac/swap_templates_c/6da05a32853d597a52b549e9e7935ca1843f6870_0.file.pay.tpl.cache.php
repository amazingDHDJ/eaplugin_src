<?php
/* Smarty version 3.1.30, created on 2017-06-12 12:55:27
  from "/home/ftp/s/s7234915/wwwroot/templates/goule_bootstrap/pay.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_593e1ebfe75826_12540706',
  'has_nocache_code' => true,
  'file_dependency' => 
  array (
    '6da05a32853d597a52b549e9e7935ca1843f6870' => 
    array (
      0 => '/home/ftp/s/s7234915/wwwroot/templates/goule_bootstrap/pay.tpl',
      1 => 1497243319,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:top.tpl' => 1,
    'file:left.tpl' => 1,
    'file:copyright.tpl' => 1,
    'file:alert.tpl' => 1,
    'file:copyright2.tpl' => 1,
  ),
),false)) {
function content_593e1ebfe75826_12540706 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->compiled->nocache_hash = '1575668374593e1ebfe03370_00616380';
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?php echo '/*%%SmartyNocache:1575668374593e1ebfe03370_00616380%%*/<?php echo $_smarty_tpl->tpl_vars[\'c\']->value[\'网站名称\'];?>
/*/%%SmartyNocache:1575668374593e1ebfe03370_00616380%%*/';?>
 - <?php echo '/*%%SmartyNocache:1575668374593e1ebfe03370_00616380%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'账户充值\'];?>
/*/%%SmartyNocache:1575668374593e1ebfe03370_00616380%%*/';?>
</title>
<link href="<?php echo '/*%%SmartyNocache:1575668374593e1ebfe03370_00616380%%*/<?php echo $_smarty_tpl->tpl_vars[\'templatedir\']->value;?>
/*/%%SmartyNocache:1575668374593e1ebfe03370_00616380%%*/';?>
/css/bootstrap.min.css" rel="stylesheet">
<link href="<?php echo '/*%%SmartyNocache:1575668374593e1ebfe03370_00616380%%*/<?php echo $_smarty_tpl->tpl_vars[\'templatedir\']->value;?>
/*/%%SmartyNocache:1575668374593e1ebfe03370_00616380%%*/';?>
/css/datepicker3.css" rel="stylesheet">
<link href="<?php echo '/*%%SmartyNocache:1575668374593e1ebfe03370_00616380%%*/<?php echo $_smarty_tpl->tpl_vars[\'templatedir\']->value;?>
/*/%%SmartyNocache:1575668374593e1ebfe03370_00616380%%*/';?>
/css/styles.css" rel="stylesheet">
<!--[if lt IE 9]>
<?php echo '<script'; ?>
 src="<?php echo '/*%%SmartyNocache:1575668374593e1ebfe03370_00616380%%*/<?php echo $_smarty_tpl->tpl_vars[\'templatedir\']->value;?>
/*/%%SmartyNocache:1575668374593e1ebfe03370_00616380%%*/';?>
/js/html5shiv.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="<?php echo '/*%%SmartyNocache:1575668374593e1ebfe03370_00616380%%*/<?php echo $_smarty_tpl->tpl_vars[\'templatedir\']->value;?>
/*/%%SmartyNocache:1575668374593e1ebfe03370_00616380%%*/';?>
/js/respond.min.js"><?php echo '</script'; ?>
>
<![endif]-->
</head>
<body>
<nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
<div class="container-fluid">
	<div class="navbar-header">
		<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#sidebar-collapse">
		<span class="sr-only">Toggle navigation</span>
		<span class="icon-bar"></span>
		<span class="icon-bar"></span>
		<span class="icon-bar"></span>
		</button>
		<a class="navbar-brand" href="/"><span><?php echo '/*%%SmartyNocache:1575668374593e1ebfe03370_00616380%%*/<?php echo $_smarty_tpl->tpl_vars[\'c\']->value[\'头部LOGO\'];?>
/*/%%SmartyNocache:1575668374593e1ebfe03370_00616380%%*/';?>
</span> <?php echo '/*%%SmartyNocache:1575668374593e1ebfe03370_00616380%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'账户充值\'];?>
/*/%%SmartyNocache:1575668374593e1ebfe03370_00616380%%*/';?>
</a>
        <?php $_smarty_tpl->_subTemplateRender("file:top.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 9999, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

	</div>
</div>
<!-- /.container-fluid -->
</nav>
<div id="sidebar-collapse" class="col-sm-3 col-lg-2 sidebar">
	<form role="search">
		<div class="form-group">
			<input type="text" class="form-control" placeholder="搜索 (不可用)">
		</div>
	</form>
	<ul class="nav menu">
		<li><a href="<?php echo '/*%%SmartyNocache:1575668374593e1ebfe03370_00616380%%*/<?php echo $_smarty_tpl->tpl_vars[\'ROOT\']->value;?>
/*/%%SmartyNocache:1575668374593e1ebfe03370_00616380%%*/';?>
/index/"><span class="glyphicon glyphicon-dashboard"></span> <?php echo '/*%%SmartyNocache:1575668374593e1ebfe03370_00616380%%*/<?php echo $_smarty_tpl->tpl_vars[\'mlang\']->value[\'仪表盘\'];?>
/*/%%SmartyNocache:1575668374593e1ebfe03370_00616380%%*/';?>
</a></li>
		<li class="parent">
		<a data-toggle="collapse" href="#sub-item-1">
		<span class="glyphicon glyphicon-hdd"></span> <?php echo '/*%%SmartyNocache:1575668374593e1ebfe03370_00616380%%*/<?php echo $_smarty_tpl->tpl_vars[\'mlang\']->value[\'客户中心\'];?>
/*/%%SmartyNocache:1575668374593e1ebfe03370_00616380%%*/';?>
 <span class="icon pull-right"><em class="glyphicon glyphicon-s glyphicon-plus"></em></span>
		</a>
		<ul class="children collapse" id="sub-item-1">
			<li>
			<a class="" href="<?php echo '/*%%SmartyNocache:1575668374593e1ebfe03370_00616380%%*/<?php echo $_smarty_tpl->tpl_vars[\'ROOT\']->value;?>
/*/%%SmartyNocache:1575668374593e1ebfe03370_00616380%%*/';?>
/buy/">
			<span class="glyphicon glyphicon-shopping-cart"></span><?php echo '/*%%SmartyNocache:1575668374593e1ebfe03370_00616380%%*/<?php echo $_smarty_tpl->tpl_vars[\'mlang\']->value[\'订购产品\'];?>
/*/%%SmartyNocache:1575668374593e1ebfe03370_00616380%%*/';?>

			</a>
			</li>
			<li>
			<a class="" href="<?php echo '/*%%SmartyNocache:1575668374593e1ebfe03370_00616380%%*/<?php echo $_smarty_tpl->tpl_vars[\'ROOT\']->value;?>
/*/%%SmartyNocache:1575668374593e1ebfe03370_00616380%%*/';?>
/control/">
			<span class="glyphicon glyphicon-tasks"></span><?php echo '/*%%SmartyNocache:1575668374593e1ebfe03370_00616380%%*/<?php echo $_smarty_tpl->tpl_vars[\'mlang\']->value[\'控制面板\'];?>
/*/%%SmartyNocache:1575668374593e1ebfe03370_00616380%%*/';?>
  
			</a>
			</li>
		</ul>
		</li>
		<li><a href="<?php echo '/*%%SmartyNocache:1575668374593e1ebfe03370_00616380%%*/<?php echo $_smarty_tpl->tpl_vars[\'ROOT\']->value;?>
/*/%%SmartyNocache:1575668374593e1ebfe03370_00616380%%*/';?>
/help/"><span class="glyphicon glyphicon-list-alt"></span><?php echo '/*%%SmartyNocache:1575668374593e1ebfe03370_00616380%%*/<?php echo $_smarty_tpl->tpl_vars[\'mlang\']->value[\'帮助中心\'];?>
/*/%%SmartyNocache:1575668374593e1ebfe03370_00616380%%*/';?>
</a></li>
		<li class="active"><a href="<?php echo '/*%%SmartyNocache:1575668374593e1ebfe03370_00616380%%*/<?php echo $_smarty_tpl->tpl_vars[\'ROOT\']->value;?>
/*/%%SmartyNocache:1575668374593e1ebfe03370_00616380%%*/';?>
/user/pay/"><span class="glyphicon glyphicon-jpy"></span><?php echo '/*%%SmartyNocache:1575668374593e1ebfe03370_00616380%%*/<?php echo $_smarty_tpl->tpl_vars[\'mlang\']->value[\'账户充值\'];?>
/*/%%SmartyNocache:1575668374593e1ebfe03370_00616380%%*/';?>
</a></li>
		<li role="presentation" class="divider"></li>
      <?php $_smarty_tpl->_subTemplateRender("file:left.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 9999, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

	</ul>
<?php $_smarty_tpl->_subTemplateRender("file:copyright.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 9999, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

</div>
<!--/.sidebar-->
<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
	<div class="row">
		<ol class="breadcrumb">
			<li><span class="glyphicon glyphicon-home"></span></li>
			<li class="active">在线充值</li>
		</ol>
	</div>
	<!--/.row-->
	<br/>
	<div class="row">
		<div class="col-md-12">
        <?php $_smarty_tpl->_subTemplateRender("file:alert.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 9999, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

			<div class="panel panel-default">
				<div class="panel-heading">
					<span class="glyphicon glyphicon-jpy"></span> 在线充值
				</div>
				<div class="panel-body">
					<div class="col-lg-3">
					</div>
					<div class="col-lg-6" style="margin-top:30px;">
						<div class="table-responsive">
							<table width="100%" class="table">
							<tbody>
							<tr>
								<td>支付用户</td>
								<td><?php echo '/*%%SmartyNocache:1575668374593e1ebfe03370_00616380%%*/<?php echo $_smarty_tpl->tpl_vars[\'s\']->value[\'登陆用户名\'];?>
/*/%%SmartyNocache:1575668374593e1ebfe03370_00616380%%*/';?>
</td>
							</tr>
							<tr>
								<td>账户余额</td>
								<td><?php echo '/*%%SmartyNocache:1575668374593e1ebfe03370_00616380%%*/<?php echo $_smarty_tpl->tpl_vars[\'s\']->value[\'登陆预存款\'];?>
/*/%%SmartyNocache:1575668374593e1ebfe03370_00616380%%*/';
echo '/*%%SmartyNocache:1575668374593e1ebfe03370_00616380%%*/<?php echo $_smarty_tpl->tpl_vars[\'c\']->value[\'交易币名称\'];?>
/*/%%SmartyNocache:1575668374593e1ebfe03370_00616380%%*/';?>
</td>
							</tr>
							</tbody>
							</table>
						</div>
						<ul class="nav nav-tabs">
                            	<h4 class="small-divide"><?php echo '/*%%SmartyNocache:1575668374593e1ebfe03370_00616380%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'存款 / 支付网关\'];?>
/*/%%SmartyNocache:1575668374593e1ebfe03370_00616380%%*/';?>
</h4>
	<?php echo '/*%%SmartyNocache:1575668374593e1ebfe03370_00616380%%*/<?php echo $_smarty_tpl->tpl_vars[\'plug\']->value[\'存款支付网关前端\'];?>
/*/%%SmartyNocache:1575668374593e1ebfe03370_00616380%%*/';?>

						<!--Tab内容开始-->
							<?php if ((function_exists("alipay_pay_config"))) {?>
							<li role="presentation" class="active"><a href="#alipay" aria-controls="alipay" role="tab" data-toggle="tab">支付宝</a></li>
							<?php }?>
							<?php if ((function_exists("spaymq_config"))) {?>
							<li role="presentation" class="active"><a href="#spay" aria-controls="spay" role="tab" data-toggle="tab">支付宝</a></li>
							<?php }?>
							<?php if ((function_exists("xhczk_config"))) {?>
							<li role="presentation" class="active"><a href="#savings" aria-controls="savings" role="tab" data-toggle="tab">充值卡</a></li>
							<?php }?>
						<!--Tab内容开始-->
						</ul>
						<div class="tab-content">
						<!--支付宝内容开始-->
							<?php if ((function_exists("alipay_pay_config"))) {?>
							<div id="alipay" class="tab-pane panel-body active">
								<label>充值金额[CNY]</label>
								<form target="_blank" class="form-horizontal" action="<?php echo '/*%%SmartyNocache:1575668374593e1ebfe03370_00616380%%*/<?php echo $_smarty_tpl->tpl_vars[\'ROOT\']->value;?>
/*/%%SmartyNocache:1575668374593e1ebfe03370_00616380%%*/';?>
/plugin/alipay_pay/index/" method="post">
									<input value="10" id="money" name="money" type="text" class="form-control">
									<p style="text-align:center;margin:2em auto">
										<input type="submit" class="btn btn-primary" value="去支付>>">
									</p>
								</form>
							</div>
							<?php }?>
							<!--支付宝内容结束-->
							<?php if ((function_exists("spaymq_config"))) {?>
							<div id="spay" class="tab-pane panel-body active">
								<label>支付宝充值</label>
								<form target="_blank" class="form-inline" action="<?php echo '/*%%SmartyNocache:1575668374593e1ebfe03370_00616380%%*/<?php echo $_smarty_tpl->tpl_vars[\'ROOT\']->value;?>
/*/%%SmartyNocache:1575668374593e1ebfe03370_00616380%%*/';?>
/plugin/spaymq/index/" method="post">
									<input maxlength="5" class="form-control" name="money"t ype="text" onkeyup="if(isNaN(this.value)){ this.value=''}">
									<p style="text-align:center;margin:2em auto">
										<input type="submit" class="btn btn-primary" value="去充值>>">
									</p>
								</form>
							</div>
							<?php }?>
							<?php if ((function_exists("xhczk_config"))) {?>
							<div id="savings" class="tab-pane panel-body active">
								<label>储值卡密[CNY]</label>
								<form target="_blank" class="form-inline" action="<?php echo '/*%%SmartyNocache:1575668374593e1ebfe03370_00616380%%*/<?php echo $_smarty_tpl->tpl_vars[\'ROOT\']->value;?>
/*/%%SmartyNocache:1575668374593e1ebfe03370_00616380%%*/';?>
/plugin/xhczk/index/" method="post">
									<input name="code" type="text" class="form-control">
									<p style="text-align:center;margin:2em auto">
										<input type="submit" class="btn btn-primary" value="去充值>>">
									</p>
								</form>
							</div>
							<?php }?>
						</div>
					</div>
					<div class="col-lg-3">
					</div>
				</div>
			</div>
		</div>
		<!--/.col-->
	</div>
	<!--/.row-->
	<?php $_smarty_tpl->_subTemplateRender("file:copyright2.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 9999, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

</div>
<!--/.main-->
<?php echo '<script'; ?>
 src="<?php echo '/*%%SmartyNocache:1575668374593e1ebfe03370_00616380%%*/<?php echo $_smarty_tpl->tpl_vars[\'templatedir\']->value;?>
/*/%%SmartyNocache:1575668374593e1ebfe03370_00616380%%*/';?>
/js/jquery-1.11.1.min.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="<?php echo '/*%%SmartyNocache:1575668374593e1ebfe03370_00616380%%*/<?php echo $_smarty_tpl->tpl_vars[\'templatedir\']->value;?>
/*/%%SmartyNocache:1575668374593e1ebfe03370_00616380%%*/';?>
/js/bootstrap.min.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="<?php echo '/*%%SmartyNocache:1575668374593e1ebfe03370_00616380%%*/<?php echo $_smarty_tpl->tpl_vars[\'templatedir\']->value;?>
/*/%%SmartyNocache:1575668374593e1ebfe03370_00616380%%*/';?>
/js/chart.min.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="<?php echo '/*%%SmartyNocache:1575668374593e1ebfe03370_00616380%%*/<?php echo $_smarty_tpl->tpl_vars[\'templatedir\']->value;?>
/*/%%SmartyNocache:1575668374593e1ebfe03370_00616380%%*/';?>
/js/chart-data.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="<?php echo '/*%%SmartyNocache:1575668374593e1ebfe03370_00616380%%*/<?php echo $_smarty_tpl->tpl_vars[\'templatedir\']->value;?>
/*/%%SmartyNocache:1575668374593e1ebfe03370_00616380%%*/';?>
/js/easypiechart.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="<?php echo '/*%%SmartyNocache:1575668374593e1ebfe03370_00616380%%*/<?php echo $_smarty_tpl->tpl_vars[\'templatedir\']->value;?>
/*/%%SmartyNocache:1575668374593e1ebfe03370_00616380%%*/';?>
/js/easypiechart-data.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="<?php echo '/*%%SmartyNocache:1575668374593e1ebfe03370_00616380%%*/<?php echo $_smarty_tpl->tpl_vars[\'templatedir\']->value;?>
/*/%%SmartyNocache:1575668374593e1ebfe03370_00616380%%*/';?>
/js/bootstrap-datepicker.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
>
    $('#calendar').datepicker({
    });
    !function ($) {
        $(document).on("click","ul.nav li.parent > a > span.icon", function(){          
            $(this).find('em:first').toggleClass("glyphicon-minus");      
        }); 
        $(".sidebar span.icon").find('em:first').addClass("glyphicon-plus");
    }(window.jQuery);
    $(window).on('resize', function () {
      if ($(window).width() > 768) $('#sidebar-collapse').collapse('show')
    })
    $(window).on('resize', function () {
      if ($(window).width() <= 767) $('#sidebar-collapse').collapse('hide')
    })
  <?php echo '</script'; ?>
>
</body>
</html><?php }
}
