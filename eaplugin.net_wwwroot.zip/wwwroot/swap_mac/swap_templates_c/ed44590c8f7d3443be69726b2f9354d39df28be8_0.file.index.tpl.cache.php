<?php
/* Smarty version 3.1.30, created on 2017-06-12 10:51:40
  from "/home/ftp/s/s7234915/wwwroot/templates/default/index.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_593e01bc88d172_77967990',
  'has_nocache_code' => true,
  'file_dependency' => 
  array (
    'ed44590c8f7d3443be69726b2f9354d39df28be8' => 
    array (
      0 => '/home/ftp/s/s7234915/wwwroot/templates/default/index.tpl',
      1 => 1497278394,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:header.tpl' => 1,
    'file:alert.tpl' => 1,
    'file:footer.tpl' => 1,
  ),
),false)) {
function content_593e01bc88d172_77967990 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->compiled->nocache_hash = '1441673713593e01bc7bf827_58878343';
echo '/*%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/<?php $_smarty_tpl->_subTemplateRender("file:header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(\'title\'=>$_smarty_tpl->tpl_vars[\'lang\']->value[\'客户中心\'],\'hostname\'=>$_smarty_tpl->tpl_vars[\'c\']->value[\'网站名称\']), 0, false);
?>
/*/%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/';?>

    <div id="in-nav">
      <div class="container">
        <div class="row">
          <div class="span12">
            <ul class="pull-right">
			<?php echo '/*%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/<?php if ((isset($_smarty_tpl->tpl_vars[\'s\']->value[\'是否已经登陆\'])?$_smarty_tpl->tpl_vars[\'s\']->value[\'是否已经登陆\']:\'\') == \'是\') {?>/*/%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/';?>

              <li><?php echo '/*%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'欢迎回来\'];?>
/*/%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/';?>
: <?php echo '/*%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/<?php echo $_smarty_tpl->tpl_vars[\'s\']->value[\'登陆用户名\'];?>
/*/%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/';?>
 / <a href="<?php echo '/*%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/<?php echo $_smarty_tpl->tpl_vars[\'ROOT\']->value;?>
/*/%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/';?>
/user/index/"><?php echo '/*%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'我的资料\'];?>
/*/%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/';?>
</a> / <a href="<?php echo '/*%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/<?php echo $_smarty_tpl->tpl_vars[\'ROOT\']->value;?>
/*/%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/';?>
/index/login/"><?php echo '/*%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'退出帐户\'];?>
/*/%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/';?>
</a></li>
            <?php echo '/*%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/<?php } else { ?>/*/%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/';?>

              <li><a href="<?php echo '/*%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/<?php echo $_smarty_tpl->tpl_vars[\'ROOT\']->value;?>
/*/%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/';?>
/index/login/"><?php echo '/*%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'登陆\'];?>
/*/%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/';?>
</a>/<a href="<?php echo '/*%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/<?php echo $_smarty_tpl->tpl_vars[\'ROOT\']->value;?>
/*/%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/';?>
/index/register/"><?php echo '/*%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'注册\'];?>
/*/%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/';?>
</a></li>
			<?php echo '/*%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/<?php }?>/*/%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/';?>

            </ul><a id="logo" href="<?php echo '/*%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/<?php echo $_smarty_tpl->tpl_vars[\'ROOT\']->value;?>
/*/%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/';?>
/index/index/">
              <h4><?php echo '/*%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/<?php echo $_smarty_tpl->tpl_vars[\'c\']->value[\'头部LOGO\'];?>
/*/%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/';?>
</h4></a>
          </div>
        </div>
      </div>
    </div>
    <div id="in-sub-nav">
      <div class="container">
        <div class="row">
          <div class="span12">
            <ul>
              <li><a href="<?php echo '/*%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/<?php echo $_smarty_tpl->tpl_vars[\'ROOT\']->value;?>
/*/%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/';?>
/index/index/" class="active"><i class="batch home"></i><br /><?php echo '/*%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'客户中心\'];?>
/*/%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/';?>
</a></li>
			  <li><a href="<?php echo '/*%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/<?php echo $_smarty_tpl->tpl_vars[\'ROOT\']->value;?>
/*/%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/';?>
/control/index/"><i class="batch b-database"></i><br><?php echo '/*%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'控制面板\'];?>
/*/%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/';?>
</a></li>
              <li><a href="<?php echo '/*%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/<?php echo $_smarty_tpl->tpl_vars[\'ROOT\']->value;?>
/*/%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/';?>
/buy/index/"><i class="batch quill"></i><br /><?php echo '/*%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'订购产品\'];?>
/*/%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/';?>
</a></li>
              <li><a href="<?php echo '/*%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/<?php echo $_smarty_tpl->tpl_vars[\'ROOT\']->value;?>
/*/%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/';?>
/user/index/"><i class="batch users"></i><br /><?php echo '/*%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'用户中心\'];?>
/*/%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/';?>
</a></li>
            </ul>
          </div>
        </div>
      </div>
    </div>
    <div class="page">
      <div class="page-container">
<div class="container">
  <div class="row">
    <div class="span9">
      <h4 class="header"><?php echo '/*%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'首页标题\'];?>
/*/%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/';?>
</h4><?php $_smarty_tpl->_subTemplateRender("file:alert.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 9999, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

      <div class="row-fluid">
        <div class="span6">
          <ul class="stat-list">
            <li><a href="<?php echo '/*%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/<?php echo $_smarty_tpl->tpl_vars[\'ROOT\']->value;?>
/*/%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/';?>
/control/index/">
              <label class="label-info"><i class="icon-home icon-white"></i></label>
              <h4><?php echo '/*%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'控制面板\'];?>
/*/%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/';?>
</h4></a>
              <h4 class="sub"><?php echo '/*%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'控制面板介绍\'];?>
/*/%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/';?>
</h4>
            </li>
            <li><a href="<?php echo '/*%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/<?php echo $_smarty_tpl->tpl_vars[\'ROOT\']->value;?>
/*/%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/';?>
/ticket/submit/">
              <label class="label-important"><i class="icon-edit icon-white"></i></label>
              <h4><?php echo '/*%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'提交服务单\'];?>
/*/%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/';?>
</h4></a>
              <h4 class="sub"><?php echo '/*%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'提交服务单介绍\'];?>
/*/%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/';?>
</h4>
            </li>
            <li><a href="<?php echo '/*%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/<?php echo $_smarty_tpl->tpl_vars[\'ROOT\']->value;?>
/*/%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/';?>
/ticket/index/">
              <label class="label-success"><i class="icon-check icon-white"></i></label>
              <h4><?php echo '/*%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'服务单\'];?>
/*/%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/';?>
</h4></a>
              <h4 class="sub"><?php echo '/*%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'服务单介绍\'];?>
/*/%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/';?>
</h4>
            </li>
            <li><a href="<?php echo '/*%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/<?php echo $_smarty_tpl->tpl_vars[\'ROOT\']->value;?>
/*/%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/';?>
/networkissues/serverstatus/">
              <label class="label-warning"><i class="icon-fire icon-white"></i></label>
              <h4><?php echo '/*%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'服务器状态\'];?>
/*/%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/';?>
</h4></a>
              <h4 class="sub"><?php echo '/*%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'服务器状态介绍\'];?>
/*/%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/';?>
</h4>
            </li>
          </ul>
        </div>
        <div class="span6">
          <ul class="stat-list">
            <li><a href="<?php echo '/*%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/<?php echo $_smarty_tpl->tpl_vars[\'ROOT\']->value;?>
/*/%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/';?>
/index/announcements/">
              <label class="label-warning"><i class="icon-flag icon-white"></i></label>
              <h4><?php echo '/*%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'公告信息\'];?>
/*/%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/';?>
</h4></a>
              <h4 class="sub"><?php echo '/*%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'公告信息介绍\'];?>
/*/%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/';?>
</h4>
            </li>
            <li><a href="<?php echo '/*%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/<?php echo $_smarty_tpl->tpl_vars[\'ROOT\']->value;?>
/*/%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/';?>
/help/index/">
              <label class="label-success"><i class="icon-search icon-white"></i></label>
              <h4><?php echo '/*%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'帮助中心\'];?>
/*/%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/';?>
</h4></a>
              <h4 class="sub"><?php echo '/*%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'帮助中心介绍\'];?>
/*/%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/';?>
</h4>
            </li>
            <li><a href="<?php echo '/*%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/<?php echo $_smarty_tpl->tpl_vars[\'ROOT\']->value;?>
/*/%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/';?>
/buy/index/">
              <label class="label-info"><i class="icon-shopping-cart icon-white"></i></label>
              <h4><?php echo '/*%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'订购产品\'];?>
/*/%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/';?>
</h4></a>
              <h4 class="sub"><?php echo '/*%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'订购产品介绍\'];?>
/*/%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/';?>
</h4>
            </li>
            <li><a href="<?php echo '/*%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/<?php echo $_smarty_tpl->tpl_vars[\'ROOT\']->value;?>
/*/%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/';?>
/networkissues/index/">
              <label class="label-inverse"><i class="icon-signal icon-white"></i></label>
              <h4><?php echo '/*%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'网络故障\'];?>
/*/%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/';?>
</h4></a>
              <h4 class="sub"><?php echo '/*%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'网络故障介绍\'];?>
/*/%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/';?>
</h4>
           </li>
          </ul>
        </div>
      </div>
      <div class="row-fluid">
        <div class="span12">
          <div class="table-panel">
		  		<div class="btn-group pull-right">
	        <a href="<?php echo '/*%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/<?php echo $_smarty_tpl->tpl_vars[\'ROOT\']->value;?>
/*/%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/';?>
/index/announcements/" class="btn"><?php echo '/*%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'更多...\'];?>
/*/%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/';?>
</a>
          </div>
            <h4> <i class="icon-bullhorn"></i><?php echo '/*%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'网站公告\'];?>
/*/%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/';?>
</h4>
            <table class="table table-striped sortable table-bordered">
              <thead>
                <tr>
                  <th><?php echo '/*%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'标题\'];?>
/*/%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/';?>
</th>
                  <th><?php echo '/*%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'时间\'];?>
/*/%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/';?>
</th>
                </tr>
              </thead>
              <tbody>
			  <?php echo '/*%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars[\'news\']->value, \'new\');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars[\'new\']->value) {
?>/*/%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/';?>

                <tr>
				  <td><a href="<?php echo '/*%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/<?php echo $_smarty_tpl->tpl_vars[\'ROOT\']->value;?>
/*/%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/';?>
/index/announcement/<?php echo '/*%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/<?php echo $_smarty_tpl->tpl_vars[\'new\']->value[\'公告ID\'];?>
/*/%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/';?>
"><?php echo '/*%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/<?php echo $_smarty_tpl->tpl_vars[\'new\']->value[\'公告标题\'];?>
/*/%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/';?>
</a></td>
                  <td><?php echo '/*%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/<?php echo $_smarty_tpl->tpl_vars[\'new\']->value[\'公告时间\'];?>
/*/%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/';?>
</td>
                </tr>
              <?php echo '/*%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>
/*/%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/';?>

			  </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
    <div class="span3">
      <h4><?php echo '/*%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'快速导航\'];?>
/*/%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/';?>
</h4>
        <table class="table">
           <tbody>
              <tr><td><a href="<?php echo '/*%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/<?php echo $_smarty_tpl->tpl_vars[\'ROOT\']->value;?>
/*/%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/';?>
/index/index/"><span class="label label-success">1</span> <?php echo '/*%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'客户中心\'];?>
/*/%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/';?>
</a></td></tr>
              <tr><td><a href="<?php echo '/*%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/<?php echo $_smarty_tpl->tpl_vars[\'ROOT\']->value;?>
/*/%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/';?>
/control/index/"><span class="label label-info">2</span> <?php echo '/*%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'控制面板\'];?>
/*/%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/';?>
</a></td></tr>
			  <tr><td><a href="<?php echo '/*%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/<?php echo $_smarty_tpl->tpl_vars[\'ROOT\']->value;?>
/*/%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/';?>
/index/announcements/"><span class="label label-warning">3</span> <?php echo '/*%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'公告信息\'];?>
/*/%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/';?>
</a></td></tr>
			  <tr><td><a href="<?php echo '/*%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/<?php echo $_smarty_tpl->tpl_vars[\'ROOT\']->value;?>
/*/%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/';?>
/ticket/submit/"><span class="label label-important">4</span> <?php echo '/*%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'提交服务单\'];?>
/*/%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/';?>
</a></td></tr>
			  <tr><td><a href="<?php echo '/*%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/<?php echo $_smarty_tpl->tpl_vars[\'ROOT\']->value;?>
/*/%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/';?>
/buy/index/"><span class="label label-info">5</span> <?php echo '/*%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'订购产品\'];?>
/*/%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/';?>
</a></td></tr>
           </tbody>
        </table>
	  <hr />
	  <?php echo '/*%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/<?php if ((isset($_smarty_tpl->tpl_vars[\'s\']->value[\'是否已经登陆\'])?$_smarty_tpl->tpl_vars[\'s\']->value[\'是否已经登陆\']:\'\') == \'是\') {?>/*/%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/';?>

	  <h4><?php echo '/*%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'账户信息\'];?>
/*/%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/';?>
</h4>
        <table class="table">
           <tbody>
              <tr><td><?php echo '/*%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/<?php echo $_smarty_tpl->tpl_vars[\'s\']->value[\'登陆姓名\'];?>
/*/%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/';?>
</td></tr>
              <tr><td><?php echo '/*%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/<?php echo $_smarty_tpl->tpl_vars[\'s\']->value[\'登陆地址\'];?>
/*/%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/';?>
</td></tr>
			  <tr><td><?php echo '/*%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/<?php echo $_smarty_tpl->tpl_vars[\'s\']->value[\'登陆国家\'];?>
/*/%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/';?>
</td></tr>
			  <tr><td><?php echo '/*%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/<?php echo $_smarty_tpl->tpl_vars[\'s\']->value[\'登陆邮箱\'];?>
/*/%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/';?>
</td></tr>
           </tbody>
        </table>
	  <hr />
	  <?php echo '/*%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/<?php }?>/*/%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/';?>

	  <h4><?php echo '/*%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'选择语言\'];?>
/*/%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/';?>
</h4>
		<form method="post" name="languagefrm" id="languagefrom">
			<select name="language" onchange="languagefrom.submit()">
			  <?php echo '/*%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars[\'l\']->value, \'langs\');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars[\'langs\']->value) {
?>/*/%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/';?>

			  <option value="<?php echo '/*%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/<?php echo $_smarty_tpl->tpl_vars[\'langs\']->value;?>
/*/%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/';?>
"<?php echo '/*%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/<?php if ((isset($_smarty_tpl->tpl_vars[\'langs\']->value)?$_smarty_tpl->tpl_vars[\'langs\']->value:\'\') == (isset($_smarty_tpl->tpl_vars[\'language\']->value)?$_smarty_tpl->tpl_vars[\'language\']->value:\'\')) {?>/*/%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/';?>
 selected="selected"<?php echo '/*%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/<?php }?>/*/%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/';?>
><?php echo '/*%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/<?php echo $_smarty_tpl->tpl_vars[\'langs\']->value;?>
/*/%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/';?>
</option>
			  <?php echo '/*%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>
/*/%%SmartyNocache:1441673713593e01bc7bf827_58878343%%*/';?>

			</select>
		</form>
    </div>
  </div>
</div>
      </div>
    </div>
<?php $_smarty_tpl->_subTemplateRender("file:footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 9999, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
