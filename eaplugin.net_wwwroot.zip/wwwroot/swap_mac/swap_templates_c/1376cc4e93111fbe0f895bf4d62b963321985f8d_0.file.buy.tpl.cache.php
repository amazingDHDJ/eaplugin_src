<?php
/* Smarty version 3.1.30, created on 2017-06-12 11:55:52
  from "/home/ftp/s/s7234915/wwwroot/templates/goule_bootstrap/buy.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_593e10c8d16150_65091987',
  'has_nocache_code' => true,
  'file_dependency' => 
  array (
    '1376cc4e93111fbe0f895bf4d62b963321985f8d' => 
    array (
      0 => '/home/ftp/s/s7234915/wwwroot/templates/goule_bootstrap/buy.tpl',
      1 => 1497237650,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:top.tpl' => 1,
    'file:left.tpl' => 1,
    'file:copyright.tpl' => 1,
    'file:alert.tpl' => 1,
    'file:copyright2.tpl' => 1,
  ),
),false)) {
function content_593e10c8d16150_65091987 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->compiled->nocache_hash = '1925194400593e10c8c34262_54829186';
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?php echo '/*%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/<?php echo $_smarty_tpl->tpl_vars[\'c\']->value[\'网站名称\'];?>
/*/%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/';?>
 - <?php echo '/*%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'客户中心\'];?>
/*/%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/';?>
</title>
<link href="<?php echo '/*%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/<?php echo $_smarty_tpl->tpl_vars[\'templatedir\']->value;?>
/*/%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/';?>
/css/bootstrap.min.css" rel="stylesheet">
<link href="<?php echo '/*%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/<?php echo $_smarty_tpl->tpl_vars[\'templatedir\']->value;?>
/*/%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/';?>
/css/datepicker3.css" rel="stylesheet">
<link href="<?php echo '/*%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/<?php echo $_smarty_tpl->tpl_vars[\'templatedir\']->value;?>
/*/%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/';?>
/css/styles.css" rel="stylesheet">
<link href="<?php echo '/*%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/<?php echo $_smarty_tpl->tpl_vars[\'templatedir\']->value;?>
/*/%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/';?>
/css/main.css" rel="stylesheet">

<!--[if lt IE 9]>
<?php echo '<script'; ?>
 src="<?php echo '/*%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/<?php echo $_smarty_tpl->tpl_vars[\'templatedir\']->value;?>
/*/%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/';?>
/js/html5shiv.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="<?php echo '/*%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/<?php echo $_smarty_tpl->tpl_vars[\'templatedir\']->value;?>
/*/%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/';?>
/js/respond.min.js"><?php echo '</script'; ?>
>
<![endif]-->

</head>
<body>
  <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
    <div class="container-fluid">
      <div class="navbar-header">
        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#sidebar-collapse">
          <span class="sr-only">Toggle navigation</span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
        </button>
        <a class="navbar-brand" href="/"><span><?php echo '/*%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/<?php echo $_smarty_tpl->tpl_vars[\'c\']->value[\'头部LOGO\'];?>
/*/%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/';?>
</span> <?php echo '/*%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'客户中心\'];?>
/*/%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/';?>
</a>
        <?php $_smarty_tpl->_subTemplateRender("file:top.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 9999, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

      </div>
    </div><!-- /.container-fluid -->
  </nav>
    
  <div id="sidebar-collapse" class="col-sm-3 col-lg-2 sidebar">
    <form role="search">
      <div class="form-group">
        <input type="text" class="form-control" placeholder="搜索 (不可用)">
      </div>
    </form>
    <ul class="nav menu">
      <li><a href="<?php echo '/*%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/<?php echo $_smarty_tpl->tpl_vars[\'ROOT\']->value;?>
/*/%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/';?>
/index/"><span class="glyphicon glyphicon-dashboard"></span> <?php echo '/*%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/<?php echo $_smarty_tpl->tpl_vars[\'mlang\']->value[\'仪表盘\'];?>
/*/%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/';?>
</a></li>
      <li class="parent">
        <a data-toggle="collapse" href="#sub-item-1">
          <span class="glyphicon glyphicon-hdd"></span> <?php echo '/*%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/<?php echo $_smarty_tpl->tpl_vars[\'mlang\']->value[\'客户中心\'];?>
/*/%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/';?>
 <span class="icon pull-right"><em class="glyphicon glyphicon-s glyphicon-plus"></em></span> 
        </a>
        <ul class="children collapse in" id="sub-item-1">
          <li>
            <a href="<?php echo '/*%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/<?php echo $_smarty_tpl->tpl_vars[\'ROOT\']->value;?>
/*/%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/';?>
/buy/">
              <span class="glyphicon glyphicon-shopping-cart"></span> <?php echo '/*%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/<?php echo $_smarty_tpl->tpl_vars[\'mlang\']->value[\'订购产品\'];?>
/*/%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/';?>

            </a>
          </li>
          <li>
            <a href="<?php echo '/*%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/<?php echo $_smarty_tpl->tpl_vars[\'ROOT\']->value;?>
/*/%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/';?>
/control/">
              <span class="glyphicon glyphicon-tasks"></span> <?php echo '/*%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/<?php echo $_smarty_tpl->tpl_vars[\'mlang\']->value[\'控制面板\'];?>
/*/%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/';?>
  
            </a>
          </li>
        </ul>
      </li>
      <li><a href="<?php echo '/*%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/<?php echo $_smarty_tpl->tpl_vars[\'ROOT\']->value;?>
/*/%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/';?>
/help/"><span class="glyphicon glyphicon-list-alt"></span> <?php echo '/*%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/<?php echo $_smarty_tpl->tpl_vars[\'mlang\']->value[\'帮助中心\'];?>
/*/%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/';?>
</a></li>
	  <li><a href="<?php echo '/*%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/<?php echo $_smarty_tpl->tpl_vars[\'ROOT\']->value;?>
/*/%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/';?>
/user/pay/"><span class="glyphicon glyphicon-jpy"></span><?php echo '/*%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/<?php echo $_smarty_tpl->tpl_vars[\'mlang\']->value[\'账户充值\'];?>
/*/%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/';?>
</a></li>
      <li role="presentation" class="divider"></li>
      <?php $_smarty_tpl->_subTemplateRender("file:left.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 9999, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    </ul>
<?php $_smarty_tpl->_subTemplateRender("file:copyright.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 9999, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

  </div><!--/.sidebar-->
    
  <div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">     
    <div class="row">
      <ol class="breadcrumb">
        <li><span class="glyphicon glyphicon-home"></span></li>
        <li><?php echo '/*%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/<?php echo $_smarty_tpl->tpl_vars[\'mlang\']->value[\'客户中心\'];?>
/*/%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/';?>
</li>
        <li class="active"><?php echo '/*%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/<?php echo $_smarty_tpl->tpl_vars[\'mlang\']->value[\'订购产品\'];?>
/*/%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/';?>
</li>
      </ol>
    </div><!--/.row-->
    <br/>
    <div class="row">
      <div class="col-lg-12">
        <?php $_smarty_tpl->_subTemplateRender("file:alert.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 9999, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

        <div class="panel panel-default">
          <center><div class="panel-heading"><?php echo '/*%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars[\'farray\']->value, \'fs\');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars[\'fs\']->value) {
?>/*/%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/';?>

<a href="<?php echo '/*%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/<?php echo $_smarty_tpl->tpl_vars[\'ROOT\']->value;?>
/*/%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/';?>
/buy/index/<?php echo '/*%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/<?php echo $_smarty_tpl->tpl_vars[\'fs\']->value[\'id\'];?>
/*/%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/';?>
/" class="btn btn-danger btn-sm"><?php echo '/*%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/<?php echo $_smarty_tpl->tpl_vars[\'fs\']->value[\'分类名称\'];?>
/*/%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/';?>
</a>&nbsp;<?php echo '/*%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>
/*/%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/';?>
</div></center>
          <div class="panel-body">
            <div class="col-md-12">
              <section id="pricing">
                <?php echo '/*%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars[\'buys\']->value, \'buy\');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars[\'buy\']->value) {
?>/*/%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/';?>

                <div class="col-sm-4">
                  <ul class="plan">
                    <li class="plan-name"><?php echo '/*%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/<?php echo $_smarty_tpl->tpl_vars[\'buy\']->value[\'名称\'];?>
/*/%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/';?>
</li>
					<?php echo '/*%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/<?php if (is_array((isset($_smarty_tpl->tpl_vars[\'buy\']->value[\'周期\'])?$_smarty_tpl->tpl_vars[\'buy\']->value[\'周期\']:\'\'))) {?>/*/%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/';?>

										<?php echo '/*%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/<?php if (isset($_smarty_tpl->tpl_vars[\'buy\']->value[\'周期\'][0])) {?>/*/%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/';?>

										<li class="plan-price" title="<?php echo '/*%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars[\'buy\']->value[\'周期\'], \'row\', false, \'num\');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars[\'num\']->value => $_smarty_tpl->tpl_vars[\'row\']->value) {
?>/*/%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/';
echo '/*%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/<?php echo $_smarty_tpl->tpl_vars[\'row\']->value[\'价格\'];?>
/*/%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/';
echo '/*%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/<?php echo $_smarty_tpl->tpl_vars[\'c\']->value[\'交易币名称\'];?>
/*/%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/';?>
/<?php echo '/*%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/<?php echo $_smarty_tpl->tpl_vars[\'row\']->value[\'时间\'];?>
/*/%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/';
echo '/*%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'天\'];?>
/*/%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/';?>

<?php echo '/*%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/<?php
}
} else {
?>
/*/%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/';?>
无价格套餐<?php echo '/*%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/<?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>
/*/%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/';?>
"><?php echo '/*%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/<?php echo $_smarty_tpl->tpl_vars[\'buy\']->value[\'周期\'][0][\'价格\'];?>
/*/%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/';
echo '/*%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/<?php echo $_smarty_tpl->tpl_vars[\'c\']->value[\'交易币名称\'];?>
/*/%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/';?>
起</li>
										<?php echo '/*%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/<?php } else { ?>/*/%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/';?>

										<?php echo '/*%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'无法购买\'];?>
/*/%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/';?>

										<?php echo '/*%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/<?php }?>/*/%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/';?>

										<?php echo '/*%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/<?php } else { ?>/*/%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/';?>

										<?php echo '/*%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/<?php if ((isset($_smarty_tpl->tpl_vars[\'buy\']->value[\'价格\'])?$_smarty_tpl->tpl_vars[\'buy\']->value[\'价格\']:\'\') == \'免费\') {?>/*/%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/';?>
<li class="plan-price"><?php echo '/*%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'免费\'];?>
/*/%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/';?>
/<?php echo '/*%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[$_smarty_tpl->tpl_vars[\'buy\']->value[\'周期\']];?>
/*/%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/';?>
</li>
										<?php echo '/*%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/<?php } else { ?>/*/%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/';?>

										<li class="plan-price"><?php echo '/*%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/<?php echo $_smarty_tpl->tpl_vars[\'buy\']->value[\'价格\'];?>
/*/%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/';
echo '/*%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/<?php echo $_smarty_tpl->tpl_vars[\'c\']->value[\'交易币名称\'];?>
/*/%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/';?>
/<?php echo '/*%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[$_smarty_tpl->tpl_vars[\'buy\']->value[\'周期\']];?>
/*/%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/';?>
</li>
										<?php echo '/*%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/<?php }?>/*/%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/';?>

										<?php echo '/*%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/<?php }?>/*/%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/';?>

                    
                    <?php echo '/*%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/<?php echo $_smarty_tpl->tpl_vars[\'buy\']->value[\'描述\'];?>
/*/%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/';?>

                    <li class="plan-action">
                    <?php echo '/*%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/<?php if ((isset($_smarty_tpl->tpl_vars[\'buy\']->value[\'库存\'])?$_smarty_tpl->tpl_vars[\'buy\']->value[\'库存\']:\'\') == 0) {?>/*/%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/';?>
<a href="#" disabled="disabled" class="btn btn-round btn-danger">无库存</a><?php echo '/*%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/<?php } elseif ((isset($_smarty_tpl->tpl_vars[\'buy\']->value[\'库存\'])?$_smarty_tpl->tpl_vars[\'buy\']->value[\'库存\']:\'\') < 5) {?>/*/%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/';?>
<a href="<?php echo '/*%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/<?php echo $_smarty_tpl->tpl_vars[\'ROOT\']->value;?>
/*/%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/';?>
/buy/cart/<?php echo '/*%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/<?php echo $_smarty_tpl->tpl_vars[\'buy\']->value[\'id\'];?>
/*/%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/';?>
/" class="btn btn-round btn-warning">购买</a><?php echo '/*%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/<?php } else { ?>/*/%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/';?>
<a href="<?php echo '/*%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/<?php echo $_smarty_tpl->tpl_vars[\'ROOT\']->value;?>
/*/%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/';?>
/buy/cart/<?php echo '/*%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/<?php echo $_smarty_tpl->tpl_vars[\'buy\']->value[\'id\'];?>
/*/%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/';?>
/" class="btn btn-round btn-success">购买</a><?php echo '/*%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/<?php }?>/*/%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/';?>

                    </li>
                  </ul>
                </div><!--/.col-sm-4-->
                <?php echo '/*%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>
/*/%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/';?>

              </div>
            </section><!--/#pricing-->
            <!--<div class="col-sm-12">
              <div class="alert alert-warning fade in">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button><i class="icon-heart-4"></i><strong>定制定价：</strong> 储存容量 ( 100 MB ) = 1 元，出网流量 ( 10 GB ) = 1 元，域名 ( 1 ) = 1 元。  费率: 国内1 香港1.4
              </div>
              <div class="alert alert-success">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button><i class="icon-attention-circled"></i><strong>提示：</strong>信客主机提供完全管理服务，为主机用户提供包括但不限于主机故障、程序安装、软件排错等服务。
              </div>
            </div>-->
          </div>
        </div>
      </div><!-- /.col-->
    </div><!-- /.row --><?php $_smarty_tpl->_subTemplateRender("file:copyright2.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 9999, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

  </div>  <!--/.main-->

  <?php echo '<script'; ?>
 src="<?php echo '/*%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/<?php echo $_smarty_tpl->tpl_vars[\'templatedir\']->value;?>
/*/%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/';?>
/js/jquery-1.11.1.min.js"><?php echo '</script'; ?>
>
  <?php echo '<script'; ?>
 src="<?php echo '/*%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/<?php echo $_smarty_tpl->tpl_vars[\'templatedir\']->value;?>
/*/%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/';?>
/js/bootstrap.min.js"><?php echo '</script'; ?>
>
  <?php echo '<script'; ?>
 src="<?php echo '/*%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/<?php echo $_smarty_tpl->tpl_vars[\'templatedir\']->value;?>
/*/%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/';?>
/js/chart.min.js"><?php echo '</script'; ?>
>
  <?php echo '<script'; ?>
 src="<?php echo '/*%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/<?php echo $_smarty_tpl->tpl_vars[\'templatedir\']->value;?>
/*/%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/';?>
/js/chart-data.js"><?php echo '</script'; ?>
>
  <?php echo '<script'; ?>
 src="<?php echo '/*%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/<?php echo $_smarty_tpl->tpl_vars[\'templatedir\']->value;?>
/*/%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/';?>
/js/easypiechart.js"><?php echo '</script'; ?>
>
  <?php echo '<script'; ?>
 src="<?php echo '/*%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/<?php echo $_smarty_tpl->tpl_vars[\'templatedir\']->value;?>
/*/%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/';?>
/js/easypiechart-data.js"><?php echo '</script'; ?>
>
  <?php echo '<script'; ?>
 src="<?php echo '/*%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/<?php echo $_smarty_tpl->tpl_vars[\'templatedir\']->value;?>
/*/%%SmartyNocache:1925194400593e10c8c34262_54829186%%*/';?>
/js/bootstrap-datepicker.js"><?php echo '</script'; ?>
>
  <?php echo '<script'; ?>
>
    $('#calendar').datepicker({
    });

    !function ($) {
        $(document).on("click","ul.nav li.parent > a > span.icon", function(){          
            $(this).find('em:first').toggleClass("glyphicon-minus");      
        }); 
        $(".sidebar span.icon").find('em:first').addClass("glyphicon-plus");
    }(window.jQuery);

    $(window).on('resize', function () {
      if ($(window).width() > 768) $('#sidebar-collapse').collapse('show')
    })
    $(window).on('resize', function () {
      if ($(window).width() <= 767) $('#sidebar-collapse').collapse('hide')
    })
  <?php echo '</script'; ?>
> 
</body>

</html><?php }
}
