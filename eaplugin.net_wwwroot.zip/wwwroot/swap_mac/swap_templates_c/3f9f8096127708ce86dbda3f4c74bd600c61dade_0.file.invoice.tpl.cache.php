<?php
/* Smarty version 3.1.30, created on 2017-06-12 12:16:34
  from "/home/ftp/s/s7234915/wwwroot/templates/goule_bootstrap/invoice.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_593e15a25e0b21_43549058',
  'has_nocache_code' => true,
  'file_dependency' => 
  array (
    '3f9f8096127708ce86dbda3f4c74bd600c61dade' => 
    array (
      0 => '/home/ftp/s/s7234915/wwwroot/templates/goule_bootstrap/invoice.tpl',
      1 => 1497237650,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_593e15a25e0b21_43549058 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->compiled->nocache_hash = '686375640593e15a2547976_80781324';
?>
<html>
<head>
    <title><?php echo '/*%%SmartyNocache:686375640593e15a2547976_80781324%%*/<?php echo $_smarty_tpl->tpl_vars[\'c\']->value[\'网站名称\'];?>
/*/%%SmartyNocache:686375640593e15a2547976_80781324%%*/';
echo '/*%%SmartyNocache:686375640593e15a2547976_80781324%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'订单\'];?>
/*/%%SmartyNocache:686375640593e15a2547976_80781324%%*/';?>
 - <?php echo '/*%%SmartyNocache:686375640593e15a2547976_80781324%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'编号\'];?>
/*/%%SmartyNocache:686375640593e15a2547976_80781324%%*/';?>
:<?php echo '/*%%SmartyNocache:686375640593e15a2547976_80781324%%*/<?php echo $_smarty_tpl->tpl_vars[\'server\']->value[\'id\'];?>
/*/%%SmartyNocache:686375640593e15a2547976_80781324%%*/';?>
</title>
    <meta name="ROBOTS" content="NOINDEX, NOFOLLOW">
    <style>
        body { margin:0;padding:0; background-color:#eee;}
            table td { border-collapse:collapse;margin:0;padding:0;}
            img { border: none;}
    </style>
    <?php echo '<script'; ?>
>
        window["_GOOG_TRANS_EXT_VER"] = "1";
    <?php echo '</script'; ?>
>
    <link type="text/css" rel="stylesheet" href="/css/invoice.style.css"/>
	<?php echo '<script'; ?>
 src="/js/jquery-1.11.0.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 language="javascript" type="text/javascript">
function daydd() {
$("#daysst").attr('class','btn active');
$("#daysst").html('<?php echo '/*%%SmartyNocache:686375640593e15a2547976_80781324%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'请稍后……\'];?>
/*/%%SmartyNocache:686375640593e15a2547976_80781324%%*/';?>
');
$.ajax({
type:　"post",
url:　"/index.php/buy/rate/",
data:　"cartid=<?php echo '/*%%SmartyNocache:686375640593e15a2547976_80781324%%*/<?php echo $_smarty_tpl->tpl_vars[\'goods\']->value[\'id\'];?>
/*/%%SmartyNocache:686375640593e15a2547976_80781324%%*/';?>
&days="+$("#days").val(),
success:　function (msg){
$("#payall").html(msg);
$("#daysst").html('<?php echo '/*%%SmartyNocache:686375640593e15a2547976_80781324%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'计算价格 >>\'];?>
/*/%%SmartyNocache:686375640593e15a2547976_80781324%%*/';?>
');
$("#daysst").attr('class','btn');
},
error:　function (mag){
$("#daysst").html('<?php echo '/*%%SmartyNocache:686375640593e15a2547976_80781324%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'网络错误,重试\'];?>
/*/%%SmartyNocache:686375640593e15a2547976_80781324%%*/';?>
');
$("#daysst").attr('class','btn');
},
});
};
<?php echo '</script'; ?>
>
</head>

<body>
    <table width="100%" cellpadding="0" cellspacing="0" border="0">
        <tbody>
            <tr>
                <td valign="top" align="right" width="50%" style="background-color: #eee;">
                    <img src="<?php echo '/*%%SmartyNocache:686375640593e15a2547976_80781324%%*/<?php echo $_smarty_tpl->tpl_vars[\'templatedir\']->value;?>
/*/%%SmartyNocache:686375640593e15a2547976_80781324%%*/';?>
/img/bg_left.jpg" height="770" width="99">
                </td>
                <td valign="top" style="background-color:#eee;">
                    <!-- PREHEADER -->
                    <table width="676" cellpadding="0" cellspacing="0" border="0">
                        <tbody>
                            <tr>
                                <td width="676" align="right" style="background-color:#ebebeb; color:#3f4042; font-family:'Segoe UI',Arial,sans-serif; font-size:10px; font-weight:600; padding:24px 0 3px;">
                                </td>
                            </tr>
                        </tbody>
                    </table>
                    <!-- /PREHEADER -->
                    <!-- BODY -->
                    <table width="676" cellpadding="0" cellspacing="0" border="0">
                        <tbody>
                            <tr>
                                <td width="15" bgcolor="#323f48">&nbsp;</td>
                                <td width="646" height="20" valign="middle" style="padding:13px 0;background-color:#323f48;">
                                    <img align="left" src="/img/bg_logo.png" alt="Windows Azure" width="236" height="20" border="0">
                                </td>
                                <td width="15" bgcolor="#323f48">&nbsp;</td>
                            </tr>
                        </tbody>
                    </table>
                    <table width="676" cellpadding="0" cellspacing="0" border="0">
                        <tbody>
                            <tr>
                                <td width="50" bgcolor="#323f48">&nbsp;</td>
                                <td width="611" align="left" valign="middle" style="padding:0 0 13px 0; background-color:#323f48; color:#fff;font-family:'Segoe UI',Arial,sans-serif; font-size:17px; line-height:21px; font-weight:600;"><?php echo '/*%%SmartyNocache:686375640593e15a2547976_80781324%%*/<?php echo $_smarty_tpl->tpl_vars[\'c\']->value[\'网站名称\'];?>
/*/%%SmartyNocache:686375640593e15a2547976_80781324%%*/';
echo '/*%%SmartyNocache:686375640593e15a2547976_80781324%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'已创建您的账单 编号\'];?>
/*/%%SmartyNocache:686375640593e15a2547976_80781324%%*/';?>
:<?php echo '/*%%SmartyNocache:686375640593e15a2547976_80781324%%*/<?php echo $_smarty_tpl->tpl_vars[\'server\']->value[\'id\'];?>
/*/%%SmartyNocache:686375640593e15a2547976_80781324%%*/';?>
</td>
                                <td width="15" bgcolor="#323f48">&nbsp;</td>
                            </tr>
                        </tbody>
                    </table>
                    <table width="676" cellpadding="0" cellspacing="0" border="0">
                        <tbody>
                            <tr>
                                <td width="50" style="background:#ffffff; line-height:1px;">&nbsp;</td>
                                <td width="386" align="left" valign="top" style="background:#fff; padding:20px 0;">
                                    <table cellpadding="0" cellspacing="0" border="0" width="100%">
                                        <tbody>
                                            <tr>
                                                <td align="left" style="color:#4d4d4d; font-family:'Segoe UI',Arial,sans-serif; font-size:14px; line-height:20px; padding-bottom:12px;">
                                                    <span style="font-size:17px; font-weight:100; line-height:21px;"><?php echo '/*%%SmartyNocache:686375640593e15a2547976_80781324%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'立即支付订单并开始使用！\'];?>
/*/%%SmartyNocache:686375640593e15a2547976_80781324%%*/';?>
</span>
                                                    <br>
                                                    <br>
                                                    <strong><?php echo '/*%%SmartyNocache:686375640593e15a2547976_80781324%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'账单日期\'];?>
/*/%%SmartyNocache:686375640593e15a2547976_80781324%%*/';?>
：<?php echo '/*%%SmartyNocache:686375640593e15a2547976_80781324%%*/<?php echo $_smarty_tpl->tpl_vars[\'server\']->value[\'申请时间\'];?>
/*/%%SmartyNocache:686375640593e15a2547976_80781324%%*/';?>
</strong>
                                                    <br>
                                                    <br>
                                                    <!-- START AMPSCRIPT                  -->
                                                    <table cellpadding="0" cellspacing="0" border="0" width="100%">
                                                        <!--                     -->
                                                        <!--                         -->
                                                        <tbody>
                                                            <tr>
                                                                <td style="color:#4d4d4d; font-family:'Segoe UI',Arial,sans-serif; font-size:14px; line-height:20px; padding-bottom:12px;">
                                                                    <strong><?php echo '/*%%SmartyNocache:686375640593e15a2547976_80781324%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'主域名\'];?>
/*/%%SmartyNocache:686375640593e15a2547976_80781324%%*/';?>
：</strong><?php echo '/*%%SmartyNocache:686375640593e15a2547976_80781324%%*/<?php echo $_smarty_tpl->tpl_vars[\'server\']->value[\'域名\'];?>
/*/%%SmartyNocache:686375640593e15a2547976_80781324%%*/';?>

                                                                    <br>
                                                                    <br><strong><?php echo '/*%%SmartyNocache:686375640593e15a2547976_80781324%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'产品类型\'];?>
/*/%%SmartyNocache:686375640593e15a2547976_80781324%%*/';?>
：</strong>
                                                                    <br><?php echo '/*%%SmartyNocache:686375640593e15a2547976_80781324%%*/<?php echo $_smarty_tpl->tpl_vars[\'goods\']->value[\'名称\'];?>
/*/%%SmartyNocache:686375640593e15a2547976_80781324%%*/';?>

																	<br><strong><?php echo '/*%%SmartyNocache:686375640593e15a2547976_80781324%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'产品价格\'];?>
/*/%%SmartyNocache:686375640593e15a2547976_80781324%%*/';?>
：</strong><?php echo '/*%%SmartyNocache:686375640593e15a2547976_80781324%%*/<?php echo $_smarty_tpl->tpl_vars[\'goods\']->value[\'价格\'];?>
/*/%%SmartyNocache:686375640593e15a2547976_80781324%%*/';
echo '/*%%SmartyNocache:686375640593e15a2547976_80781324%%*/<?php if ((isset($_smarty_tpl->tpl_vars[\'goods\']->value[\'价格\'])?$_smarty_tpl->tpl_vars[\'goods\']->value[\'价格\']:\'\') != \'免费\') {?>/*/%%SmartyNocache:686375640593e15a2547976_80781324%%*/';?>
 <?php echo '/*%%SmartyNocache:686375640593e15a2547976_80781324%%*/<?php echo $_smarty_tpl->tpl_vars[\'c\']->value[\'交易币名称\'];?>
/*/%%SmartyNocache:686375640593e15a2547976_80781324%%*/';
echo '/*%%SmartyNocache:686375640593e15a2547976_80781324%%*/<?php }?>/*/%%SmartyNocache:686375640593e15a2547976_80781324%%*/';?>

																	<br>
																	<br><strong><?php echo '/*%%SmartyNocache:686375640593e15a2547976_80781324%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'付款周期\'];?>
/*/%%SmartyNocache:686375640593e15a2547976_80781324%%*/';?>
：</strong><?php echo '/*%%SmartyNocache:686375640593e15a2547976_80781324%%*/<?php echo $_smarty_tpl->tpl_vars[\'goods\']->value[\'周期\'];?>
/*/%%SmartyNocache:686375640593e15a2547976_80781324%%*/';?>

                                                                </td>
                                                            </tr>
                                                            <!---->
                                                        </tbody>
                                                    </table>
                                                    <!-- END AMPSCRIPT -->
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </td>
                                <td width="240" align="left" valign="top" style="background:#eee; padding:0;">
                                    <table width="240" cellpadding="0" cellspacing="0" border="0">
                                        <tbody>
                                            <tr>
                                                <td width="240" align="left" valign="top" style="background-color:#eee;padding:35px 0 20px;">
                                                    <table width="200px" border="0" cellpadding="0" cellspacing="0" align="center">
                                                        <tbody>
                                                            <tr>
                                                                <td><form name="pay" method="post" action="<?php echo '/*%%SmartyNocache:686375640593e15a2547976_80781324%%*/<?php echo $_smarty_tpl->tpl_vars[\'ROOT\']->value;?>
/*/%%SmartyNocache:686375640593e15a2547976_80781324%%*/';?>
/control/pay/<?php echo '/*%%SmartyNocache:686375640593e15a2547976_80781324%%*/<?php echo $_smarty_tpl->tpl_vars[\'server\']->value[\'id\'];?>
/*/%%SmartyNocache:686375640593e15a2547976_80781324%%*/';?>
/">
																    <div onclick="javascript:pay.submit();" align="center" valign="middle" style="background:#00ADEF; padding:10px 11px; font-family:Segoe UI, Tahoma, sans-serif; font-size:11pt;color:#fff;cursor: hand;">
                                                                        <b><?php echo '/*%%SmartyNocache:686375640593e15a2547976_80781324%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'支付\'];?>
/*/%%SmartyNocache:686375640593e15a2547976_80781324%%*/';?>
</b>
																    </div>
                                                                </td>
                                                            </tr>
															<tr style="display:none">
																<td align="center"></br>
																Powered by <a href="http://www.swapidc.com/">SWAPIDC</a>
																</td>
															</tr>
                                                        </tbody>
                                                    </table>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td width="240" align="left" valign="top" style="background-color:#eee;padding:20px 0 20px;">
                                                    <table cellpadding="0" cellspacing="0" border="0" width="240px">
                                                        <tbody>
                                                            <tr>
                                                                <td width="20" bgcolor="#686868" style="border-top:2px solid #fff;">&nbsp;</td>
                                                                <td width="200" align="left" bgcolor="#686868" style="color:#fff; font-family:'Segoe UI',Arial,sans-serif; font-size:17px; line-height:19px; padding:10px 0; border-top:2px solid #fff;"><?php echo '/*%%SmartyNocache:686375640593e15a2547976_80781324%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'支付选项\'];?>
/*/%%SmartyNocache:686375640593e15a2547976_80781324%%*/';?>
</td>
                                                                <td width="20" bgcolor="#686868" style="border-top:2px solid #fff;">&nbsp;</td>
                                                            </tr>
                                                            <tr>
                                                                <td width="20">&nbsp;</td>
                                                                <td width="200" align="left" style="color:#3d3d3d; font-family:'Segoe UI',Arial,sans-serif; font-size:13px; line-height:16px; padding:20px 0;">
 																	<strong><?php echo '/*%%SmartyNocache:686375640593e15a2547976_80781324%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'您要支付开通的时间\'];?>
/*/%%SmartyNocache:686375640593e15a2547976_80781324%%*/';?>
:</strong><br>
                                                                    <strong><input type="txt" name="days" id="days" value="1" /> /<?php echo '/*%%SmartyNocache:686375640593e15a2547976_80781324%%*/<?php echo $_smarty_tpl->tpl_vars[\'goods\']->value[\'周期\'];?>
/*/%%SmartyNocache:686375640593e15a2547976_80781324%%*/';?>
</strong><br>
                                                                    <strong><?php echo '/*%%SmartyNocache:686375640593e15a2547976_80781324%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'当前预存款\'];?>
/*/%%SmartyNocache:686375640593e15a2547976_80781324%%*/';?>
: <?php echo '/*%%SmartyNocache:686375640593e15a2547976_80781324%%*/<?php echo $_smarty_tpl->tpl_vars[\'s\']->value[\'登陆预存款\'];?>
/*/%%SmartyNocache:686375640593e15a2547976_80781324%%*/';?>
 <?php echo '/*%%SmartyNocache:686375640593e15a2547976_80781324%%*/<?php echo $_smarty_tpl->tpl_vars[\'c\']->value[\'交易币名称\'];?>
/*/%%SmartyNocache:686375640593e15a2547976_80781324%%*/';?>
</strong><br><br>
																    <div onclick="daydd()" id="daysst" align="center" valign="middle" style="background:#199900; padding:10px 11px; font-family:Segoe UI, Tahoma, sans-serif; font-size:11pt;color:#fff;cursor: hand;">
                                                                        <b><?php echo '/*%%SmartyNocache:686375640593e15a2547976_80781324%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'计算价格\'];?>
/*/%%SmartyNocache:686375640593e15a2547976_80781324%%*/';?>
</b>
																    </div>
                                                                </td>
                                                                <td width="20">&nbsp;</td>
                                                            </tr></form>
                                                        </tbody>
                                                    </table>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td width="240" align="left" valign="top" style="background-color:#eee;padding:20px 0 20px;">
                                                    <table cellpadding="0" cellspacing="0" border="0" width="240px">
                                                        <tbody>
                                                            <tr>
                                                                <td width="20" bgcolor="#686868" style="border-top:2px solid #fff;">&nbsp;</td>
                                                                <td width="200" align="left" bgcolor="#686868" style="color:#fff; font-family:'Segoe UI',Arial,sans-serif; font-size:17px; line-height:19px; padding:10px 0; border-top:2px solid #fff;"><?php echo '/*%%SmartyNocache:686375640593e15a2547976_80781324%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'金额总计\'];?>
/*/%%SmartyNocache:686375640593e15a2547976_80781324%%*/';?>
</td>
                                                                <td width="20" bgcolor="#686868" style="border-top:2px solid #fff;">&nbsp;</td>
                                                            </tr>
                                                            <tr>
                                                                <td width="20">&nbsp;</td>
                                                                <td width="200" align="left" style="color:#3d3d3d; font-family:'Segoe UI',Arial,sans-serif; font-size:13px; line-height:16px; padding:20px 0;">
                                                                    <center>
                                                                        <strong>
                                                                            <font size="3px"><span id="payall"><?php echo '/*%%SmartyNocache:686375640593e15a2547976_80781324%%*/<?php if ((isset($_smarty_tpl->tpl_vars[\'goods\']->value[\'价格\'])?$_smarty_tpl->tpl_vars[\'goods\']->value[\'价格\']:\'\') == \'免费\') {?>/*/%%SmartyNocache:686375640593e15a2547976_80781324%%*/';?>
0<?php echo '/*%%SmartyNocache:686375640593e15a2547976_80781324%%*/<?php } else { ?>/*/%%SmartyNocache:686375640593e15a2547976_80781324%%*/';
echo '/*%%SmartyNocache:686375640593e15a2547976_80781324%%*/<?php echo $_smarty_tpl->tpl_vars[\'goods\']->value[\'价格\'];?>
/*/%%SmartyNocache:686375640593e15a2547976_80781324%%*/';
echo '/*%%SmartyNocache:686375640593e15a2547976_80781324%%*/<?php }?>/*/%%SmartyNocache:686375640593e15a2547976_80781324%%*/';?>
</span> <?php echo '/*%%SmartyNocache:686375640593e15a2547976_80781324%%*/<?php echo $_smarty_tpl->tpl_vars[\'c\']->value[\'交易币名称\'];?>
/*/%%SmartyNocache:686375640593e15a2547976_80781324%%*/';?>
</font>
                                                                        </strong>
                                                                    </center>
                                                                </td>
                                                                <td width="20">&nbsp;</td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                    <!-- /BODY -->
                    <!-- FOOTER -->
                    <table width="676" cellpadding="0" cellspacing="0" border="0">
                        <tbody>
                            <tr>
                                <td width="50" style="background:#fff; border-top:solid 2px #898989;">&nbsp;</td>
                                <td width="606" align="left" valign="top" style="background:#fff; color:#4c4c4c; font-family:'Segoe UI',Arial,sans-serif; font-size:11px; padding:20px 0; border-top:solid 2px #898989;">
                                    <table width="100%" cellpadding="0" cellspacing="0" border="0" style="">
                                        <tbody>
                                            <tr>
                                                <td align="left" style="font-family:'Segoe UI',Arial,sans-serif; color:#4d4d4d; font-size:12px;">
                                                    <center>
                                                        <a href="<?php echo '/*%%SmartyNocache:686375640593e15a2547976_80781324%%*/<?php echo $_smarty_tpl->tpl_vars[\'ROOT\']->value;?>
/*/%%SmartyNocache:686375640593e15a2547976_80781324%%*/';?>
/control/"><?php echo '/*%%SmartyNocache:686375640593e15a2547976_80781324%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'<< 回到客户中心\'];?>
/*/%%SmartyNocache:686375640593e15a2547976_80781324%%*/';?>
</a>
                                                    </center>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </td>
                                <td width="20" style="background:#fff; border-top:solid 2px #898989;">&nbsp;</td>
                            </tr>
                            <tr>
                                <td width="50" style="background:#fff; color:#4c4c4c;">&nbsp;</td>
                                <td width="606" valign="top" align="right" style="background:#fff; color:#4c4c4c; font-family:'Segoe UI',Arial,sans-serif; font-size:11px; padding:0 0 24px 0;">
                                </td>
                                <td width="20" style="background:#fff; color:#4c4c4c;">&nbsp;</td>
                            </tr>
                        </tbody>
                    </table>
                    <!-- /FOOTER -->
                </td>
                <td valign="top" align="left" width="50%" style="background-color:#eee;">
                    <img src="<?php echo '/*%%SmartyNocache:686375640593e15a2547976_80781324%%*/<?php echo $_smarty_tpl->tpl_vars[\'templatedir\']->value;?>
/*/%%SmartyNocache:686375640593e15a2547976_80781324%%*/';?>
/img/bg_right.jpg" height="770" width="99">
                </td>
            </tr>
        </tbody>
    </table>
</body>

</html><?php }
}
