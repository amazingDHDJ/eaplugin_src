<?php
/* Smarty version 3.1.30, created on 2017-06-12 11:25:34
  from "/home/ftp/s/s7234915/wwwroot/templates/goule_bootstrap/alert.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_593e09ae326521_49213114',
  'has_nocache_code' => true,
  'file_dependency' => 
  array (
    'c87b3a109afa55c1ebfa903b35e48e86d51bcf8b' => 
    array (
      0 => '/home/ftp/s/s7234915/wwwroot/templates/goule_bootstrap/alert.tpl',
      1 => 1497237650,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_593e09ae326521_49213114 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->compiled->nocache_hash = '657757326593e09ae30c1c3_00203970';
echo '/*%%SmartyNocache:657757326593e09ae30c1c3_00203970%%*/<?php if ((isset($_smarty_tpl->tpl_vars[\'alert\']->value[\'warning\'])?$_smarty_tpl->tpl_vars[\'alert\']->value[\'warning\']:\'\') != \'\') {?>/*/%%SmartyNocache:657757326593e09ae30c1c3_00203970%%*/';?>

<div class="alert alert-warning alert-dismissible fade in" role="alert">
      <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
      <strong><?php echo '/*%%SmartyNocache:657757326593e09ae30c1c3_00203970%%*/<?php echo $_smarty_tpl->tpl_vars[\'alert\']->value[\'warning\'];?>
/*/%%SmartyNocache:657757326593e09ae30c1c3_00203970%%*/';?>
</strong>
    </div>
<?php echo '/*%%SmartyNocache:657757326593e09ae30c1c3_00203970%%*/<?php }?>/*/%%SmartyNocache:657757326593e09ae30c1c3_00203970%%*/';?>

<?php echo '/*%%SmartyNocache:657757326593e09ae30c1c3_00203970%%*/<?php if ((isset($_smarty_tpl->tpl_vars[\'alert\']->value[\'error\'])?$_smarty_tpl->tpl_vars[\'alert\']->value[\'error\']:\'\') != \'\') {?>/*/%%SmartyNocache:657757326593e09ae30c1c3_00203970%%*/';?>

<div class="alert alert-danger alert-dismissible fade in" role="alert">
      <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
      <strong><?php echo '/*%%SmartyNocache:657757326593e09ae30c1c3_00203970%%*/<?php echo $_smarty_tpl->tpl_vars[\'alert\']->value[\'error\'];?>
/*/%%SmartyNocache:657757326593e09ae30c1c3_00203970%%*/';?>
</strong>
    </div>
<?php echo '/*%%SmartyNocache:657757326593e09ae30c1c3_00203970%%*/<?php }?>/*/%%SmartyNocache:657757326593e09ae30c1c3_00203970%%*/';?>

<?php echo '/*%%SmartyNocache:657757326593e09ae30c1c3_00203970%%*/<?php if ((isset($_smarty_tpl->tpl_vars[\'alert\']->value[\'success\'])?$_smarty_tpl->tpl_vars[\'alert\']->value[\'success\']:\'\') != \'\') {?>/*/%%SmartyNocache:657757326593e09ae30c1c3_00203970%%*/';?>

<div class="alert alert-success alert-dismissible fade in" role="alert">
      <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
      <strong><?php echo '/*%%SmartyNocache:657757326593e09ae30c1c3_00203970%%*/<?php echo $_smarty_tpl->tpl_vars[\'alert\']->value[\'success\'];?>
/*/%%SmartyNocache:657757326593e09ae30c1c3_00203970%%*/';?>
</strong>
    </div>
<?php echo '/*%%SmartyNocache:657757326593e09ae30c1c3_00203970%%*/<?php }?>/*/%%SmartyNocache:657757326593e09ae30c1c3_00203970%%*/';?>

<?php echo '/*%%SmartyNocache:657757326593e09ae30c1c3_00203970%%*/<?php if ((isset($_smarty_tpl->tpl_vars[\'alert\']->value[\'info\'])?$_smarty_tpl->tpl_vars[\'alert\']->value[\'info\']:\'\') != \'\') {?>/*/%%SmartyNocache:657757326593e09ae30c1c3_00203970%%*/';?>

<div class="alert alert-info alert-dismissible fade in" role="alert">
      <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
      <strong><?php echo '/*%%SmartyNocache:657757326593e09ae30c1c3_00203970%%*/<?php echo $_smarty_tpl->tpl_vars[\'alert\']->value[\'info\'];?>
/*/%%SmartyNocache:657757326593e09ae30c1c3_00203970%%*/';?>
</strong>
    </div>
<?php echo '/*%%SmartyNocache:657757326593e09ae30c1c3_00203970%%*/<?php }?>/*/%%SmartyNocache:657757326593e09ae30c1c3_00203970%%*/';
}
}
