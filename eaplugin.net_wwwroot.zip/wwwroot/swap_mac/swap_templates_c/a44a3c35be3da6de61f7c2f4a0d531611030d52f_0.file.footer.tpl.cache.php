<?php
/* Smarty version 3.1.30, created on 2017-06-12 10:51:40
  from "/home/ftp/s/s7234915/wwwroot/templates/default/footer.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_593e01bc8b8a83_19493078',
  'has_nocache_code' => true,
  'file_dependency' => 
  array (
    'a44a3c35be3da6de61f7c2f4a0d531611030d52f' => 
    array (
      0 => '/home/ftp/s/s7234915/wwwroot/templates/default/footer.tpl',
      1 => 1497278394,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_593e01bc8b8a83_19493078 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->compiled->nocache_hash = '1014378555593e01bc8b2be4_22785039';
?>
    <footer>
      <div class="container">
        <div class="row">
          <div class="span12">
            <p class="pull-right">Theme by Nathan Speller | Powered by <a href="http://www.swapidc.cn/">SWAPIDC</a> | Execution Time:<?php echo '/*%%SmartyNocache:1014378555593e01bc8b2be4_22785039%%*/<?php echo $_smarty_tpl->tpl_vars[\'runtime\']->value;?>
/*/%%SmartyNocache:1014378555593e01bc8b2be4_22785039%%*/';?>
 SEC</p>
            <p><?php echo '/*%%SmartyNocache:1014378555593e01bc8b2be4_22785039%%*/<?php echo $_smarty_tpl->tpl_vars[\'c\']->value[\'底部版权\'];?>
/*/%%SmartyNocache:1014378555593e01bc8b2be4_22785039%%*/';?>
 <?php echo '/*%%SmartyNocache:1014378555593e01bc8b2be4_22785039%%*/<?php echo $_smarty_tpl->tpl_vars[\'c\']->value[\'网站名称\'];?>
/*/%%SmartyNocache:1014378555593e01bc8b2be4_22785039%%*/';?>
</p>
          </div>
        </div>
      </div>
    </footer>
  </body>
  <?php echo '<script'; ?>
 src="<?php echo '/*%%SmartyNocache:1014378555593e01bc8b2be4_22785039%%*/<?php echo $_smarty_tpl->tpl_vars[\'templatedir\']->value;?>
/*/%%SmartyNocache:1014378555593e01bc8b2be4_22785039%%*/';?>
/js/d3-setup.js"><?php echo '</script'; ?>
>
</html><?php }
}
