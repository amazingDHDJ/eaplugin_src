<?php
/* Smarty version 3.1.30, created on 2017-06-12 12:15:50
  from "/home/ftp/s/s7234915/wwwroot/templates/goule_bootstrap/cart.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_593e1576c24d68_93858220',
  'has_nocache_code' => true,
  'file_dependency' => 
  array (
    'd12687fb0760bd357327522cdff1450a1679dab5' => 
    array (
      0 => '/home/ftp/s/s7234915/wwwroot/templates/goule_bootstrap/cart.tpl',
      1 => 1497237650,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:top.tpl' => 1,
    'file:left.tpl' => 1,
    'file:copyright.tpl' => 1,
    'file:alert.tpl' => 1,
    'file:copyright2.tpl' => 1,
  ),
),false)) {
function content_593e1576c24d68_93858220 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->compiled->nocache_hash = '1029767941593e1576aa1b74_19402019';
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?php echo '/*%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/<?php echo $_smarty_tpl->tpl_vars[\'c\']->value[\'网站名称\'];?>
/*/%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/';?>
 - <?php echo '/*%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'购物车\'];?>
/*/%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/';?>
</title>
<?php echo '<script'; ?>
 src="<?php echo '/*%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/<?php echo $_smarty_tpl->tpl_vars[\'templatedir\']->value;?>
/*/%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/';?>
/js/jquery-1.11.0.js"><?php echo '</script'; ?>
>
<link href="<?php echo '/*%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/<?php echo $_smarty_tpl->tpl_vars[\'templatedir\']->value;?>
/*/%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/';?>
/css/bootstrap.min.css" rel="stylesheet">
<link href="<?php echo '/*%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/<?php echo $_smarty_tpl->tpl_vars[\'templatedir\']->value;?>
/*/%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/';?>
/css/datepicker3.css" rel="stylesheet">
<link href="<?php echo '/*%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/<?php echo $_smarty_tpl->tpl_vars[\'templatedir\']->value;?>
/*/%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/';?>
/css/styles.css" rel="stylesheet">
<link href="<?php echo '/*%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/<?php echo $_smarty_tpl->tpl_vars[\'templatedir\']->value;?>
/*/%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/';?>
/css/main.css" rel="stylesheet">

<!--[if lt IE 9]>
<?php echo '<script'; ?>
 src="<?php echo '/*%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/<?php echo $_smarty_tpl->tpl_vars[\'templatedir\']->value;?>
/*/%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/';?>
/js/html5shiv.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="<?php echo '/*%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/<?php echo $_smarty_tpl->tpl_vars[\'templatedir\']->value;?>
/*/%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/';?>
/js/respond.min.js"><?php echo '</script'; ?>
>
<![endif]-->

</head>
<body>
  <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
    <div class="container-fluid">
      <div class="navbar-header">
        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#sidebar-collapse">
          <span class="sr-only">Toggle navigation</span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
        </button>
        <a class="navbar-brand" href="/"><span><?php echo '/*%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/<?php echo $_smarty_tpl->tpl_vars[\'c\']->value[\'头部LOGO\'];?>
/*/%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/';?>
</span> <?php echo '/*%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'购物车\'];?>
/*/%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/';?>
</a>
        <?php $_smarty_tpl->_subTemplateRender("file:top.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 9999, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

      </div>
    </div><!-- /.container-fluid -->
  </nav>
    
  <div id="sidebar-collapse" class="col-sm-3 col-lg-2 sidebar">
    <form role="search">
      <div class="form-group">
        <input type="text" class="form-control" placeholder="搜索 (不可用)">
      </div>
    </form>
    <ul class="nav menu">
      <li><a href="<?php echo '/*%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/<?php echo $_smarty_tpl->tpl_vars[\'ROOT\']->value;?>
/*/%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/';?>
/index/"><span class="glyphicon glyphicon-dashboard"></span> <?php echo '/*%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/<?php echo $_smarty_tpl->tpl_vars[\'mlang\']->value[\'仪表盘\'];?>
/*/%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/';?>
</a></li>
      <li class="parent">
        <a data-toggle="collapse" href="#sub-item-1">
          <span class="glyphicon glyphicon-hdd"></span> <?php echo '/*%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/<?php echo $_smarty_tpl->tpl_vars[\'mlang\']->value[\'客户中心\'];?>
/*/%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/';?>
 <span class="icon pull-right"><em class="glyphicon glyphicon-s glyphicon-plus"></em></span> 
        </a>
        <ul class="children collapse in" id="sub-item-1">
          <li>
            <a href="<?php echo '/*%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/<?php echo $_smarty_tpl->tpl_vars[\'ROOT\']->value;?>
/*/%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/';?>
/buy/">
              <span class="glyphicon glyphicon-shopping-cart"></span> <?php echo '/*%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/<?php echo $_smarty_tpl->tpl_vars[\'mlang\']->value[\'订购产品\'];?>
/*/%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/';?>

            </a>
          </li>
          <li>
            <a href="<?php echo '/*%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/<?php echo $_smarty_tpl->tpl_vars[\'ROOT\']->value;?>
/*/%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/';?>
/control/">
              <span class="glyphicon glyphicon-tasks"></span> <?php echo '/*%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/<?php echo $_smarty_tpl->tpl_vars[\'mlang\']->value[\'控制面板\'];?>
/*/%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/';?>
  
            </a>
          </li>
        </ul>
      </li>
      <li><a href="<?php echo '/*%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/<?php echo $_smarty_tpl->tpl_vars[\'ROOT\']->value;?>
/*/%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/';?>
/help/"><span class="glyphicon glyphicon-list-alt"></span> <?php echo '/*%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/<?php echo $_smarty_tpl->tpl_vars[\'mlang\']->value[\'帮助中心\'];?>
/*/%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/';?>
</a></li>
	  <li><a href="<?php echo '/*%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/<?php echo $_smarty_tpl->tpl_vars[\'ROOT\']->value;?>
/*/%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/';?>
/user/pay/"><span class="glyphicon glyphicon-jpy"></span><?php echo '/*%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/<?php echo $_smarty_tpl->tpl_vars[\'mlang\']->value[\'账户充值\'];?>
/*/%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/';?>
</a></li>
      <li role="presentation" class="divider"></li>
      <?php $_smarty_tpl->_subTemplateRender("file:left.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 9999, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    </ul>
<?php $_smarty_tpl->_subTemplateRender("file:copyright.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 9999, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

  </div><!--/.sidebar-->
    
  <div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">     
    <div class="row">
      <ol class="breadcrumb">
        <li><a href="#"><span class="glyphicon glyphicon-home"></span></a></li>
        <li class="active">Forms</li>
      </ol>
    </div><!--/.row-->
    <br/>
    <div class="row">
      <div class="col-lg-12">
        <?php $_smarty_tpl->_subTemplateRender("file:alert.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 9999, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

        <div class="panel panel-default">
          <div class="panel-heading"><?php echo '/*%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'订购产品\'];?>
/*/%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/';?>
</div>
          <div class="panel-body">
            <div class="col-md-12">
              <form method="post" action="submit/">
              <table class="table">
                <thead>
                  <tr>
                    <th><b><?php echo '/*%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/<?php echo $_smarty_tpl->tpl_vars[\'cart\']->value[\'名称\'];?>
/*/%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/';?>
</b></th>
                    <th><?php echo '/*%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/<?php if ((isset($_smarty_tpl->tpl_vars[\'cart\']->value[\'库存\'])?$_smarty_tpl->tpl_vars[\'cart\']->value[\'库存\']:\'\') == 0) {?>/*/%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/';?>
<font color="#930000">缺货</font><?php echo '/*%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/<?php } elseif ((isset($_smarty_tpl->tpl_vars[\'cart\']->value[\'库存\'])?$_smarty_tpl->tpl_vars[\'cart\']->value[\'库存\']:\'\') < 5) {?>/*/%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/';?>
<font color="#796400">较少</font><?php echo '/*%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/<?php } else { ?>/*/%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/';?>
<font color="#006000">充足</font><?php echo '/*%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/<?php }?>/*/%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/';?>
</th>
                    <th><?php echo '/*%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/<?php if (is_array((isset($_smarty_tpl->tpl_vars[\'cart\']->value[\'周期\'])?$_smarty_tpl->tpl_vars[\'cart\']->value[\'周期\']:\'\'))) {?>/*/%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/';?>

					<select name="cycleid" class="form-control">
						<?php echo '/*%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars[\'cart\']->value[\'周期\'], \'row\', false, \'num\');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars[\'num\']->value => $_smarty_tpl->tpl_vars[\'row\']->value) {
?>/*/%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/';?>

							<option value="<?php echo '/*%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/<?php echo $_smarty_tpl->tpl_vars[\'num\']->value;?>
/*/%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/';?>
"><?php echo '/*%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/<?php echo $_smarty_tpl->tpl_vars[\'row\']->value[\'价格\'];?>
/*/%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/';
echo '/*%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/<?php echo $_smarty_tpl->tpl_vars[\'c\']->value[\'交易币名称\'];?>
/*/%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/';?>
/<?php echo '/*%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/<?php echo $_smarty_tpl->tpl_vars[\'row\']->value[\'时间\'];?>
/*/%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/';?>
天</option>
						<?php echo '/*%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/<?php
}
} else {
?>
/*/%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/';?>

							无法购买
						<?php echo '/*%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/<?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>
/*/%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/';?>

					</select>
					<?php echo '/*%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/<?php } else { ?>/*/%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/';?>

					<?php echo '/*%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/<?php if ((isset($_smarty_tpl->tpl_vars[\'cart\']->value[\'价格\'])?$_smarty_tpl->tpl_vars[\'cart\']->value[\'价格\']:\'\') == \'免费\') {?>/*/%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/';
echo '/*%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'免费\'];?>
/*/%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/';
echo '/*%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/<?php } else { ?>/*/%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/';
echo '/*%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/<?php echo $_smarty_tpl->tpl_vars[\'cart\']->value[\'价格\'];?>
/*/%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/';?>
 <?php echo '/*%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/<?php echo $_smarty_tpl->tpl_vars[\'c\']->value[\'交易币名称\'];?>
/*/%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/';
echo '/*%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/<?php }?>/*/%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/';?>
/<?php echo '/*%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[$_smarty_tpl->tpl_vars[\'cart\']->value[\'周期\']];?>
/*/%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/';?>

					<?php echo '/*%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/<?php }?>/*/%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/';?>

					</th>
                  </tr>
                </thead>
              </table>
              <table class="table table-striped table-bordered">
            <tbody>
            <?php echo '/*%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/<?php if ((isset($_smarty_tpl->tpl_vars[\'cart\']->value[\'隐藏域名配置\'])?$_smarty_tpl->tpl_vars[\'cart\']->value[\'隐藏域名配置\']:\'\') != \'1\') {?>/*/%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/';?>

            <tr>
            <td><?php echo '/*%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'您选择的产品/服务需要域名，请将域名填写在下面\'];?>
/*/%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/';?>
</td>
            </tr>
            <tr>
            <td>
            <label><input type="radio" name="domainoption" value="domain" id="seldomain" onclick="document.getElementById('domain').style.display='';document.getElementById('freedomain').style.display='none';" />
            自有域名
            </label>
            </td>
            </tr>
            <?php echo '/*%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/<?php if ((isset($_smarty_tpl->tpl_vars[\'cart\']->value[\'显示域名选项\'])?$_smarty_tpl->tpl_vars[\'cart\']->value[\'显示域名选项\']:\'\') == \'开\') {?>/*/%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/';?>

            <tr>
            <td>
            <label>
        <input type="radio" name="domainoption" value="freedomain" id="selfreedomain" onclick="document.getElementById('domain').style.display='none';document.getElementById('freedomain').style.display='';" />
        免费域名
        </label></td>
              </tr>
<?php echo '/*%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/<?php }?>/*/%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/';?>

              <tr>
                <td>
        <div id="freedomain" align="center">输入前骤 <input type="text" name="freedomain" size="40" value="" /> <b>.</b>
        <select name="freedomainhz" style="width:150px;">
<?php echo '/*%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars[\'freedomains\']->value, \'freedomain\');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars[\'freedomain\']->value) {
?>/*/%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/';?>

              <option value="<?php echo '/*%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/<?php echo $_smarty_tpl->tpl_vars[\'freedomain\']->value;?>
/*/%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/';?>
"><?php echo '/*%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/<?php echo $_smarty_tpl->tpl_vars[\'freedomain\']->value;?>
/*/%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/';?>
</option>
<?php echo '/*%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>
/*/%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/';?>

        </select>
        </div>
        <div id="domain" align="center">
        <input type="text" name="domain" size="40" value="" style="width:276px;"/>
        .
        <input type="text" name="domainhz" size="7" value="" style="width:80px;"/>
        </div>
        </td>
              </tr>
<?php echo '/*%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/<?php }?>/*/%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/';?>

<?php echo '/*%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars[\'buyoptions\']->value, \'option\');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars[\'option\']->value) {
?>/*/%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/';?>

<?php echo '/*%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/<?php if ((isset($_smarty_tpl->tpl_vars[\'option\']->value[\'Type\'])?$_smarty_tpl->tpl_vars[\'option\']->value[\'Type\']:\'\') == \'yesno\') {?>/*/%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/';?>

        <tr>
          <td>
        <div  align="center">
        <?php echo '/*%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/<?php echo $_smarty_tpl->tpl_vars[\'option\']->value[\'Name\'];?>
/*/%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/';?>
 : <input name="buyoptions[<?php echo '/*%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/<?php echo $_smarty_tpl->tpl_vars[\'option\']->value[\'Name\'];?>
/*/%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/';?>
]" type="radio" value="on" /><?php echo '/*%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'开\'];?>
/*/%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/';?>
 <input name="buyoptions[<?php echo '/*%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/<?php echo $_smarty_tpl->tpl_vars[\'option\']->value[\'Name\'];?>
/*/%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/';?>
]" type="radio" value="0" checked /><?php echo '/*%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'关\'];?>
/*/%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/';?>

        </div>
        </td>
        </tr>
<?php echo '/*%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/<?php } elseif ((isset($_smarty_tpl->tpl_vars[\'option\']->value[\'Type\'])?$_smarty_tpl->tpl_vars[\'option\']->value[\'Type\']:\'\') == \'text\') {?>/*/%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/';?>

        <tr>
          <td>
        <div  align="center">
        <?php echo '/*%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/<?php echo $_smarty_tpl->tpl_vars[\'option\']->value[\'Name\'];?>
/*/%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/';?>
 : <input type="text" name="buyoptions[<?php echo '/*%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/<?php echo $_smarty_tpl->tpl_vars[\'option\']->value[\'Name\'];?>
/*/%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/';?>
]" size="<?php echo '/*%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/<?php echo $_smarty_tpl->tpl_vars[\'option\']->value[\'Size\'];?>
/*/%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/';?>
">
        </div>
        </td>
        </tr>
<?php echo '/*%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/<?php } elseif ((isset($_smarty_tpl->tpl_vars[\'option\']->value[\'Type\'])?$_smarty_tpl->tpl_vars[\'option\']->value[\'Type\']:\'\') == \'dropdown\') {?>/*/%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/';?>

        <tr>
          <td>
        <div  align="center">
        <?php echo '/*%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/<?php echo $_smarty_tpl->tpl_vars[\'option\']->value[\'Name\'];?>
/*/%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/';?>
 : 
        <select name="buyoptions[<?php echo '/*%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/<?php echo $_smarty_tpl->tpl_vars[\'option\']->value[\'Name\'];?>
/*/%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/';?>
]">
<?php echo '/*%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars[\'option\']->value[\'Options\'], \'optsub\');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars[\'optsub\']->value) {
?>/*/%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/';?>

          <option value="<?php echo '/*%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/<?php echo $_smarty_tpl->tpl_vars[\'optsub\']->value;?>
/*/%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/';?>
"><?php echo '/*%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/<?php echo $_smarty_tpl->tpl_vars[\'optsub\']->value;?>
/*/%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/';?>
</option>
<?php echo '/*%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>
/*/%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/';?>

        </select>
        </div>
        </td>
        </tr>
<?php echo '/*%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/<?php }?>/*/%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/';?>

<?php echo '/*%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>
/*/%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/';?>

<?php echo '/*%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars[\'options\']->value, \'option\');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars[\'option\']->value) {
?>/*/%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/';?>

        <tr>
          <td>
        <div  align="center">
        <?php echo '/*%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/<?php echo $_smarty_tpl->tpl_vars[\'option\']->value[\'名称\'];?>
/*/%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/';?>
 : 
        <select name="config[<?php echo '/*%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/<?php echo $_smarty_tpl->tpl_vars[\'option\']->value[\'id\'];?>
/*/%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/';?>
]">
<?php echo '/*%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars[\'option\']->value[\'选项\'], \'optsub\');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars[\'optsub\']->value) {
?>/*/%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/';?>

          <option value="<?php echo '/*%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/<?php echo $_smarty_tpl->tpl_vars[\'optsub\']->value[\'id\'];?>
/*/%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/';?>
"><?php echo '/*%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/<?php echo $_smarty_tpl->tpl_vars[\'optsub\']->value[\'名称\'];?>
/*/%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/';?>
</option>
<?php echo '/*%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>
/*/%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/';?>

        </select>
        </div>
        </td>
        </tr>
<?php echo '/*%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>
/*/%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/';?>

            </tbody>
          </table>
<?php echo '/*%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/<?php if ((isset($_smarty_tpl->tpl_vars[\'cart\']->value[\'隐藏域名配置\'])?$_smarty_tpl->tpl_vars[\'cart\']->value[\'隐藏域名配置\']:\'\') != \'1\') {?>/*/%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/';?>

<?php echo '<script'; ?>
 language="javascript" type="text/javascript">
document.getElementById('seldomain').checked='true';
document.getElementById('freedomain').style.display='none';
document.getElementById('domain').style.display='';
<?php echo '</script'; ?>
>
<?php echo '/*%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/<?php }?>/*/%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/';?>

              </div>
              <div class="col-md-12">
                <div class="col-md-6">
				<?php echo '/*%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/<?php if (is_array((isset($_smarty_tpl->tpl_vars[\'cart\']->value[\'周期\'])?$_smarty_tpl->tpl_vars[\'cart\']->value[\'周期\']:\'\'))) {?>/*/%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/';
echo '/*%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/<?php } else { ?>/*/%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/';
echo '/*%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/<?php if ((isset($_smarty_tpl->tpl_vars[\'cart\']->value[\'周期\'])?$_smarty_tpl->tpl_vars[\'cart\']->value[\'周期\']:\'\') != \'一次性\') {?>/*/%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/';?>

				<div class="form-group">
                  <label><?php echo '/*%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'购买时间\'];?>
/*/%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/';?>
 / <?php echo '/*%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[$_smarty_tpl->tpl_vars[\'cart\']->value[\'周期\']];?>
/*/%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/';?>
</label>
                  <input class="form-control" type="text" name="days" id="days" value="1" /><br/><a class="btn" id="daysst"><?php echo '/*%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'计算价格 >>\'];?>
/*/%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/';?>
</a>
                </div>
				<?php echo '/*%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/<?php }?>/*/%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/';
echo '/*%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/<?php }?>/*/%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/';?>

                <div class="form-group">
                  <label><?php echo '/*%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'优惠码\'];?>
/*/%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/';?>
</label>
                  <input class="form-control" type="text" name="promocode" placeholder="输入优惠码" size="20" id="promocode" /><br/><a class="btn" id="validatepromo"><?php echo '/*%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'验证 >>\'];?>
/*/%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/';?>
</a>
                </div>
				<div class="form-group">
                    <label><?php echo '/*%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'备注/额外信息\'];?>
/*/%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/';?>
</label>
                    <textarea class="form-control" name="notes" rows="3" onFocus="if(this.value=='<?php echo '/*%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'您可以输入任何您想包含在订单中的额外注释或信息……\'];?>
/*/%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/';?>
'){ this.value=''; }" onBlur="if (this.value==''){ this.value='<?php echo '/*%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'您可以输入任何您想包含在订单中的额外注释或信息……\'];?>
/*/%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/';?>
'; }"><?php echo '/*%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'您可以输入任何您想包含在订单中的额外注释或信息……\'];?>
/*/%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/';?>
</textarea>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <label><?php echo '/*%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'确认订单/合计\'];?>
/*/%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/';?>
</label><br/>
                    <?php echo '/*%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'预存款\'];?>
/*/%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/';?>
: <?php echo '/*%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/<?php echo $_smarty_tpl->tpl_vars[\'s\']->value[\'登陆预存款\'];?>
/*/%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/';?>
 <?php echo '/*%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/<?php echo $_smarty_tpl->tpl_vars[\'c\']->value[\'交易币名称\'];?>
/*/%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/';?>
<br/><br/><input type="submit" value="<?php echo '/*%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'确认订单并且完成订购\'];?>
/*/%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/';?>
" onclick="this.value='<?php echo '/*%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'请稍后……\'];?>
/*/%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/';?>
'" class="btn btn-success" />
                  </div>
                </div>
              </div>
              </form>
          </div>
        </div>
      </div><!-- /.col-->
    </div><!-- /.row -->
    <?php $_smarty_tpl->_subTemplateRender("file:copyright2.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 9999, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

  </div><!--/.main-->

  <?php echo '<script'; ?>
 src="<?php echo '/*%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/<?php echo $_smarty_tpl->tpl_vars[\'templatedir\']->value;?>
/*/%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/';?>
/js/jquery-1.11.1.min.js"><?php echo '</script'; ?>
>
  <?php echo '<script'; ?>
 src="<?php echo '/*%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/<?php echo $_smarty_tpl->tpl_vars[\'templatedir\']->value;?>
/*/%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/';?>
/js/bootstrap.min.js"><?php echo '</script'; ?>
>
  <?php echo '<script'; ?>
 src="<?php echo '/*%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/<?php echo $_smarty_tpl->tpl_vars[\'templatedir\']->value;?>
/*/%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/';?>
/js/chart.min.js"><?php echo '</script'; ?>
>
  <?php echo '<script'; ?>
 src="<?php echo '/*%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/<?php echo $_smarty_tpl->tpl_vars[\'templatedir\']->value;?>
/*/%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/';?>
/js/chart-data.js"><?php echo '</script'; ?>
>
  <?php echo '<script'; ?>
 src="<?php echo '/*%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/<?php echo $_smarty_tpl->tpl_vars[\'templatedir\']->value;?>
/*/%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/';?>
/js/easypiechart.js"><?php echo '</script'; ?>
>
  <?php echo '<script'; ?>
 src="<?php echo '/*%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/<?php echo $_smarty_tpl->tpl_vars[\'templatedir\']->value;?>
/*/%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/';?>
/js/easypiechart-data.js"><?php echo '</script'; ?>
>
  <?php echo '<script'; ?>
 src="<?php echo '/*%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/<?php echo $_smarty_tpl->tpl_vars[\'templatedir\']->value;?>
/*/%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/';?>
/js/bootstrap-datepicker.js"><?php echo '</script'; ?>
>
  <?php echo '<script'; ?>
 language="javascript" type="text/javascript">
$("#daysst").click(function () {
$("#daysst").attr('class','btn btn-default');
$("#daysst").html('<?php echo '/*%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'请稍后……\'];?>
/*/%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/';?>
');
$.ajax({
type:　"post",
url:　"/index.php/buy/rate/",
data:　"cartid=<?php echo '/*%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/<?php echo $_smarty_tpl->tpl_vars[\'cart\']->value[\'id\'];?>
/*/%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/';?>
&days="+$("#days").val(),
success:　function (msg){
$("#payall").html(msg);
$("#daysst").html('<?php echo '/*%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'计算价格 >>\'];?>
/*/%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/';?>
');
$("#daysst").attr('class','btn');
},
error:　function (mag){
$("#daysst").html('<?php echo '/*%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'网络错误,重试\'];?>
/*/%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/';?>
');
$("#daysst").attr('class','btn');
},
});
});


$("#validatepromo").click(function () {
$("#validatepromo").attr('class','btn');
$("#validatepromo").html('<?php echo '/*%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'请稍后……\'];?>
/*/%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/';?>
');
$.ajax({
type:　"post",
url:　"/index.php/buy/promo/",
data:　"swap="+$("#promocode").val(),
success:　function (msg){
if(msg==='ok'){
$("#validatepromo").html('<?php echo '/*%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'优惠码有效\'];?>
/*/%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/';?>
');
$("#validatepromo").attr('class','btn');
}else{
$("#validatepromo").html(msg);
$("#validatepromo").attr('class','btn');
}
},
error:　function (mag){
$("#validatepromo").html('<?php echo '/*%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'网络错误,重试\'];?>
/*/%%SmartyNocache:1029767941593e1576aa1b74_19402019%%*/';?>
');
$("#validatepromo").attr('class','btn');
},
});
});
<?php echo '</script'; ?>
>
  <?php echo '<script'; ?>
>
    $('#calendar').datepicker({
    });

    !function ($) {
        $(document).on("click","ul.nav li.parent > a > span.icon", function(){          
            $(this).find('em:first').toggleClass("glyphicon-minus");      
        }); 
        $(".sidebar span.icon").find('em:first').addClass("glyphicon-plus");
    }(window.jQuery);

    $(window).on('resize', function () {
      if ($(window).width() > 768) $('#sidebar-collapse').collapse('show')
    })
    $(window).on('resize', function () {
      if ($(window).width() <= 767) $('#sidebar-collapse').collapse('hide')
    })
  <?php echo '</script'; ?>
> 
</body>

</html><?php }
}
