<?php
/* Smarty version 3.1.30, created on 2017-06-12 12:23:40
  from "/home/ftp/s/s7234915/wwwroot/templates/goule_bootstrap/detail.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_593e174c83c1c5_51538769',
  'has_nocache_code' => true,
  'file_dependency' => 
  array (
    '0400a4c84e5b4b30bc76c76cfb4e763be68c04a4' => 
    array (
      0 => '/home/ftp/s/s7234915/wwwroot/templates/goule_bootstrap/detail.tpl',
      1 => 1497237650,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:top.tpl' => 1,
    'file:left.tpl' => 1,
    'file:copyright.tpl' => 1,
    'file:alert.tpl' => 1,
    'file:copyright2.tpl' => 1,
  ),
),false)) {
function content_593e174c83c1c5_51538769 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->compiled->nocache_hash = '586805295593e174c5fb122_39130018';
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php echo $_smarty_tpl->tpl_vars[\'c\']->value[\'网站名称\'];?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>
 - <?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'详细管理\'];?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>
</title>
<link href="<?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php echo $_smarty_tpl->tpl_vars[\'templatedir\']->value;?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>
/css/bootstrap.min.css" rel="stylesheet">
<link href="<?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php echo $_smarty_tpl->tpl_vars[\'templatedir\']->value;?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>
/css/datepicker3.css" rel="stylesheet">
<link href="<?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php echo $_smarty_tpl->tpl_vars[\'templatedir\']->value;?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>
/css/styles.css" rel="stylesheet">

<!--[if lt IE 9]>
<?php echo '<script'; ?>
 src="<?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php echo $_smarty_tpl->tpl_vars[\'templatedir\']->value;?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>
/js/html5shiv.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="<?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php echo $_smarty_tpl->tpl_vars[\'templatedir\']->value;?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>
/js/respond.min.js"><?php echo '</script'; ?>
>
<![endif]-->

</head>
<body>
  <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
    <div class="container-fluid">
      <div class="navbar-header">
        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#sidebar-collapse">
          <span class="sr-only">Toggle navigation</span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
        </button>
        <a class="navbar-brand" href="/"><span><?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php echo $_smarty_tpl->tpl_vars[\'c\']->value[\'头部LOGO\'];?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>
</span> <?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'客户中心\'];?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>
</a>
        <?php $_smarty_tpl->_subTemplateRender("file:top.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 9999, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

      </div>
    </div><!-- /.container-fluid -->
  </nav>
    
  <div id="sidebar-collapse" class="col-sm-3 col-lg-2 sidebar">
    <form role="search">
      <div class="form-group">
        <input type="text" class="form-control" placeholder="搜索 (不可用)">
      </div>
    </form>
    <ul class="nav menu">
      <li><a href="<?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php echo $_smarty_tpl->tpl_vars[\'ROOT\']->value;?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>
/index/"><span class="glyphicon glyphicon-dashboard"></span> <?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php echo $_smarty_tpl->tpl_vars[\'mlang\']->value[\'仪表盘\'];?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>
</a></li>
      <li class="parent">
        <a data-toggle="collapse" href="#sub-item-1">
          <span class="glyphicon glyphicon-hdd"></span> <?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php echo $_smarty_tpl->tpl_vars[\'mlang\']->value[\'客户中心\'];?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>
 <span class="icon pull-right"><em class="glyphicon glyphicon-s glyphicon-plus"></em></span> 
        </a>
        <ul class="children collapse in" id="sub-item-1">
          <li>
            <a href="<?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php echo $_smarty_tpl->tpl_vars[\'ROOT\']->value;?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>
/buy/">
              <span class="glyphicon glyphicon-shopping-cart"></span> <?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php echo $_smarty_tpl->tpl_vars[\'mlang\']->value[\'订购产品\'];?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>

            </a>
          </li>
          <li>
            <a href="<?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php echo $_smarty_tpl->tpl_vars[\'ROOT\']->value;?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>
/control/">
              <span class="glyphicon glyphicon-tasks"></span> <?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php echo $_smarty_tpl->tpl_vars[\'mlang\']->value[\'控制面板\'];?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>
  
            </a>
          </li>
        </ul>
      </li>
      <li><a href="<?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php echo $_smarty_tpl->tpl_vars[\'ROOT\']->value;?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>
/help/"><span class="glyphicon glyphicon-list-alt"></span> <?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php echo $_smarty_tpl->tpl_vars[\'mlang\']->value[\'帮助中心\'];?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>
</a></li>
	  <li><a href="<?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php echo $_smarty_tpl->tpl_vars[\'ROOT\']->value;?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>
/user/pay/"><span class="glyphicon glyphicon-jpy"></span><?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php echo $_smarty_tpl->tpl_vars[\'mlang\']->value[\'账户充值\'];?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>
</a></li>
      <li role="presentation" class="divider"></li>
      <?php $_smarty_tpl->_subTemplateRender("file:left.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 9999, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    </ul>
<?php $_smarty_tpl->_subTemplateRender("file:copyright.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 9999, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

  </div><!--/.sidebar-->
    
  <div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">     
    <div class="row">
      <ol class="breadcrumb">
        <li><span class="glyphicon glyphicon-home"></span></li>
        <li><?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php echo $_smarty_tpl->tpl_vars[\'mlang\']->value[\'客户中心\'];?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>
</li>
        <li><?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php echo $_smarty_tpl->tpl_vars[\'mlang\']->value[\'控制面板\'];?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>
</li>
        <li class="active">详细管理</li>
      </ol>
    </div><!--/.row-->
      <br/>
    <div class="row">
      <div class="col-md-12">
        <?php $_smarty_tpl->_subTemplateRender("file:alert.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 9999, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

        <div class="panel panel-default">
          <div class="panel-body tabs">
          
            <ul class="nav nav-pills">
              <li class="active"><a href="#pilltab1" data-toggle="tab">信息</a></li>
			  <?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php if ((isset($_smarty_tpl->tpl_vars[\'server\']->value[\'周期\'])?$_smarty_tpl->tpl_vars[\'server\']->value[\'周期\']:\'\') != \'一次性\') {?>/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>

			  <?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php if (!(isset($_smarty_tpl->tpl_vars[\'goods\']->value[\'禁止续费\'])?$_smarty_tpl->tpl_vars[\'goods\']->value[\'禁止续费\']:\'\')) {?>/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>

              <li><a href="#pilltab2" data-toggle="tab">基础管理</a></li>
			  <?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php }?>/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>

			  <?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php if ((isset($_smarty_tpl->tpl_vars[\'goods\']->value[\'开启升级选项\'])?$_smarty_tpl->tpl_vars[\'goods\']->value[\'开启升级选项\']:\'\')) {?>/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>

			  <li><a href="<?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php echo $_smarty_tpl->tpl_vars[\'ROOT\']->value;?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>
/control/package/<?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php echo $_smarty_tpl->tpl_vars[\'server\']->value[\'id\'];?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>
/"><?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'升级/降级产品\'];?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>
</a></li>
			  <?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php }?>/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>

			  <?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php }?>/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>

              <?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars[\'logins\']->value, \'login\');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars[\'login\']->value) {
?>/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>

              <li><?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php echo $_smarty_tpl->tpl_vars[\'login\']->value;?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>
</li>
              <?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>

            </ul>
            <div class="tab-content">
              <div class="tab-pane fade in active" id="pilltab1">
                <div class="panel-body">
						<div class="col-md-6">
						<div style="display: none;"><?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php echo $_smarty_tpl->tpl_vars[\'plug\']->value[\'产品控制面板详情\'];?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>
</div>
						<div class="form-group"><label><?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'产品名称\'];?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>
:</label><p class="help-block"><?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php echo $_smarty_tpl->tpl_vars[\'goods\']->value[\'名称\'];?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>
</p></div>
						<?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php if ((isset($_smarty_tpl->tpl_vars[\'server\']->value[\'主机名\'])?$_smarty_tpl->tpl_vars[\'server\']->value[\'主机名\']:\'\') != \'\') {?>/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>
<div class="form-group"><label>别名解析:</label><p class="help-block"><?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php echo $_smarty_tpl->tpl_vars[\'server\']->value[\'主机名\'];?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>
</p></div><?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php }?>/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>

							<?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php if ((isset($_smarty_tpl->tpl_vars[\'goods\']->value[\'隐藏域名配置\'])?$_smarty_tpl->tpl_vars[\'goods\']->value[\'隐藏域名配置\']:\'\') != \'1\') {?>/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>
<div class="form-group"><label><?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'主域名(服务名)\'];?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>
:</label><p class="help-block"><?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php echo $_smarty_tpl->tpl_vars[\'server\']->value[\'域名\'];?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>
</p></div><?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php }?>/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>

							<?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php if ((isset($_smarty_tpl->tpl_vars[\'server\']->value[\'密码\'])?$_smarty_tpl->tpl_vars[\'server\']->value[\'密码\']:\'\') != \'\') {?>/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>
<div class="form-group"><label><?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'用户名\'];?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>
:</label><p class="help-block"><?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php echo $_smarty_tpl->tpl_vars[\'server\']->value[\'用户名\'];?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>
</p></div>
							<div class="form-group"><label><?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'密码\'];?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>
:</label><p class="help-block"><?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php echo $_smarty_tpl->tpl_vars[\'server\']->value[\'密码\'];?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>
</p></div><?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php }?>/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>

							<?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php if ((isset($_smarty_tpl->tpl_vars[\'server\']->value[\'ip地址\'])?$_smarty_tpl->tpl_vars[\'server\']->value[\'ip地址\']:\'\') != \'\') {?>/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>
<div class="form-group"><label><?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'IP解析\'];?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>
:</label><p class="help-block"><?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php echo $_smarty_tpl->tpl_vars[\'server\']->value[\'ip地址\'];?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>
</p></div><?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php }?>/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>

							<?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php if ((isset($_smarty_tpl->tpl_vars[\'server\']->value[\'专用IP\'])?$_smarty_tpl->tpl_vars[\'server\']->value[\'专用IP\']:\'\') != \'\') {?>/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>
<div class="form-group"><label><?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'专用IP\'];?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>
:</label><p class="help-block"><?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php echo $_smarty_tpl->tpl_vars[\'server\']->value[\'专用IP\'];?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>
</p></div><?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php }?>/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>

							<?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php if ((isset($_smarty_tpl->tpl_vars[\'server\']->value[\'指定IP\'])?$_smarty_tpl->tpl_vars[\'server\']->value[\'指定IP\']:\'\') != \'\') {?>/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>
<div class="form-group"><label><?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'指定IP\'];?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>
:</label><p class="help-block"><?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php echo $_smarty_tpl->tpl_vars[\'server\']->value[\'指定IP\'];?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>
</p></div><?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php }?>/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>

							<?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars[\'options\']->value, \'option\');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars[\'option\']->value) {
?>/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>
<div class="form-group"><label><?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php echo $_smarty_tpl->tpl_vars[\'option\']->value[\'名称\'];?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>
:</label><p class="help-block"><?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php echo $_smarty_tpl->tpl_vars[\'option\']->value[\'值\'];?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>
</p></div><?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>

							<?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars[\'configs\']->value, \'config\');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars[\'config\']->value) {
?>/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>
<div class="form-group"><label><?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php echo $_smarty_tpl->tpl_vars[\'config\']->value[\'名字\'];?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>
:</label><p class="help-block"><?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php echo $_smarty_tpl->tpl_vars[\'config\']->value[\'内容\'];?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>
</p></div><?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>

							</div>
							<div class="col-md-6">
							<?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php if ((isset($_smarty_tpl->tpl_vars[\'server\']->value[\'DNS服务器1\'])?$_smarty_tpl->tpl_vars[\'server\']->value[\'DNS服务器1\']:\'\') != \'\' || (isset($_smarty_tpl->tpl_vars[\'server\']->value[\'DNS服务器2\'])?$_smarty_tpl->tpl_vars[\'server\']->value[\'DNS服务器2\']:\'\') != \'\' || (isset($_smarty_tpl->tpl_vars[\'server\']->value[\'DNS服务器3\'])?$_smarty_tpl->tpl_vars[\'server\']->value[\'DNS服务器3\']:\'\') != \'\' || (isset($_smarty_tpl->tpl_vars[\'server\']->value[\'DNS服务器4\'])?$_smarty_tpl->tpl_vars[\'server\']->value[\'DNS服务器4\']:\'\') != \'\' || (isset($_smarty_tpl->tpl_vars[\'server\']->value[\'DNS服务器5\'])?$_smarty_tpl->tpl_vars[\'server\']->value[\'DNS服务器5\']:\'\') != \'\') {?>/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>
<div class="form-group"><label><?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'DNS解析(NS)\'];?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>
:</label><p class="help-block"><?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php if ((isset($_smarty_tpl->tpl_vars[\'server\']->value[\'DNS服务器1\'])?$_smarty_tpl->tpl_vars[\'server\']->value[\'DNS服务器1\']:\'\') != \'\') {?>/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';
echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php echo $_smarty_tpl->tpl_vars[\'server\']->value[\'DNS服务器1\'];?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';
echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php }?>/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>
,<?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php if ((isset($_smarty_tpl->tpl_vars[\'server\']->value[\'DNS服务器2\'])?$_smarty_tpl->tpl_vars[\'server\']->value[\'DNS服务器2\']:\'\') != \'\') {?>/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';
echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php echo $_smarty_tpl->tpl_vars[\'server\']->value[\'DNS服务器2\'];?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';
echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php }?>/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>
,<?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php if ((isset($_smarty_tpl->tpl_vars[\'server\']->value[\'DNS服务器3\'])?$_smarty_tpl->tpl_vars[\'server\']->value[\'DNS服务器3\']:\'\') != \'\') {?>/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';
echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php echo $_smarty_tpl->tpl_vars[\'server\']->value[\'DNS服务器3\'];?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';
echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php }?>/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>
,<?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php if ((isset($_smarty_tpl->tpl_vars[\'server\']->value[\'DNS服务器4\'])?$_smarty_tpl->tpl_vars[\'server\']->value[\'DNS服务器4\']:\'\') != \'\') {?>/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';
echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php echo $_smarty_tpl->tpl_vars[\'server\']->value[\'DNS服务器4\'];?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';
echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php }?>/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>
,<?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php if ((isset($_smarty_tpl->tpl_vars[\'server\']->value[\'DNS服务器5\'])?$_smarty_tpl->tpl_vars[\'server\']->value[\'DNS服务器5\']:\'\') != \'\') {?>/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';
echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php echo $_smarty_tpl->tpl_vars[\'server\']->value[\'DNS服务器5\'];?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';
echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php }?>/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>
</p></div><?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php }?>/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>

							<div class="form-group"><label><?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'价格 / 周期\'];?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>
:</label><p class="help-block"><?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php if (is_array((isset($_smarty_tpl->tpl_vars[\'server\']->value[\'周期\'])?$_smarty_tpl->tpl_vars[\'server\']->value[\'周期\']:\'\'))) {?>/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>
一<?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php echo $_smarty_tpl->tpl_vars[\'server\']->value[\'周期\'][\'名称\'];?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>
 <?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php echo $_smarty_tpl->tpl_vars[\'server\']->value[\'周期\'][\'价格\'];?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';
echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php echo $_smarty_tpl->tpl_vars[\'c\']->value[\'交易币名称\'];?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>
/<?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php echo $_smarty_tpl->tpl_vars[\'server\']->value[\'周期\'][\'时间\'];?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>
天<?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php } else { ?>/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';
echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php echo $_smarty_tpl->tpl_vars[\'goods\']->value[\'价格\'];?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';
echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php if ((isset($_smarty_tpl->tpl_vars[\'goods\']->value[\'价格\'])?$_smarty_tpl->tpl_vars[\'goods\']->value[\'价格\']:\'\') != \'免费\') {?>/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>
 <?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php echo $_smarty_tpl->tpl_vars[\'c\']->value[\'交易币名称\'];?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';
echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php }?>/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>
 / <?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[$_smarty_tpl->tpl_vars[\'server\']->value[\'周期\']];?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';
echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php }?>/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>
</p></div>
							<?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php if ((isset($_smarty_tpl->tpl_vars[\'server\']->value[\'开通时间\'])?$_smarty_tpl->tpl_vars[\'server\']->value[\'开通时间\']:\'\') != \'\') {?>/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>
<div class="form-group"><label><?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'开通时间\'];?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>
:</label><p class="help-block"><?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php echo $_smarty_tpl->tpl_vars[\'server\']->value[\'开通时间\'];?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>
</p></div><?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php }?>/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>

							<?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php if ((isset($_smarty_tpl->tpl_vars[\'server\']->value[\'到期时间\'])?$_smarty_tpl->tpl_vars[\'server\']->value[\'到期时间\']:\'\') != \'\') {?>/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>
<div class="form-group"><label><?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'到期时间\'];?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>
:</label><p class="help-block"><?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php echo $_smarty_tpl->tpl_vars[\'server\']->value[\'到期时间\'];?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>
</p></div><?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php }?>/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>

							<div class="form-group"><label><?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'状态\'];?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>
:</label><p class="help-block"><?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php if ((isset($_smarty_tpl->tpl_vars[\'server\']->value[\'状态\'])?$_smarty_tpl->tpl_vars[\'server\']->value[\'状态\']:\'\') == \'激活\') {?>/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>
<span class="label label-success"><?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'激活\'];?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>
</span><?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php } elseif ((isset($_smarty_tpl->tpl_vars[\'server\']->value[\'状态\'])?$_smarty_tpl->tpl_vars[\'server\']->value[\'状态\']:\'\') == \'暂停\') {?>/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>
<span class="label label-warning"><?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'暂停\'];?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>
</span><?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php } else { ?>/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>
<span class="label label-info"><?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php echo $_smarty_tpl->tpl_vars[\'server\']->value[\'状态\'];?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>
</span><?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php }?>/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>
</p></div>
							</div>
							<div class="form-group"><p class="text-danger text-left">请勿在高级控制面板修改密码,否则无法一键登录!<br/>经系统排查出现网站被攻击,暂停主机3~5天!严重者删主机处理!(测试功能)</p></div>
					</div>
              </div>
              <div class="tab-pane fade" id="pilltab2">
                
                  <?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php if ((isset($_smarty_tpl->tpl_vars[\'goods\']->value[\'允许用户自己停止\'])?$_smarty_tpl->tpl_vars[\'goods\']->value[\'允许用户自己停止\']:\'\')) {?>/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>

                  <div class="col-md-6">
                  <h3><?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'续期产品\'];?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>
</h3>
                <form role="form" action="pay/" method="post">
                  <div class="form-group">
                  <label><?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'续期天数\'];?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>
</label>
                  <?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php if (is_array((isset($_smarty_tpl->tpl_vars[\'goods\']->value[\'周期\'])?$_smarty_tpl->tpl_vars[\'goods\']->value[\'周期\']:\'\'))) {?>/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>

                  <select name="cycleid" class="form-control">
                    <?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars[\'goods\']->value[\'可续期周期\'], \'row\', false, \'num\');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars[\'num\']->value => $_smarty_tpl->tpl_vars[\'row\']->value) {
?>/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>

                    <option value="<?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php echo $_smarty_tpl->tpl_vars[\'num\']->value;?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>
">一<?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php echo $_smarty_tpl->tpl_vars[\'row\']->value[\'名称\'];?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>
 <?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php echo $_smarty_tpl->tpl_vars[\'row\']->value[\'价格\'];?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';
echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php echo $_smarty_tpl->tpl_vars[\'c\']->value[\'交易币名称\'];?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>
/<?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php echo $_smarty_tpl->tpl_vars[\'row\']->value[\'时间\'];?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>
天</option>
                    <?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php
}
} else {
?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>

                    无法续费
                    <?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>

                     </select>
                     <p class="text-info"><?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'您目前拥有预存款\'];?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>
 <?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php echo $_smarty_tpl->tpl_vars[\'s\']->value[\'登陆预存款\'];?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>
 <?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php echo $_smarty_tpl->tpl_vars[\'c\']->value[\'交易币名称\'];?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>
</p>
                  <?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php } else { ?>/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>

                  <?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php if ((isset($_smarty_tpl->tpl_vars[\'goods\']->value[\'价格\'])?$_smarty_tpl->tpl_vars[\'goods\']->value[\'价格\']:\'\') != \'免费\') {?>/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>

                  <input class="form-control" name="day" value="1" type="text" placeholder="续费数量" id="inputDay" onkeyup="this.value=this.value.replace(/\D|^0/g,'')" />
                  <?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php } else { ?>/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>

                  <?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'免费产品会自动帮你续期到目前最大的时间!!\'];?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>

                  <?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php }?>/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>

                  <span class="help-block"><?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'请确定续期日期在预存款可以续期内,否则续期失败!\'];?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>
</span>
                  <p class="text-info"><?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php if ((isset($_smarty_tpl->tpl_vars[\'goods\']->value[\'价格\'])?$_smarty_tpl->tpl_vars[\'goods\']->value[\'价格\']:\'\') != \'免费\') {?>/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';
echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'您目前拥有预存款\'];?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>
 <?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php echo $_smarty_tpl->tpl_vars[\'s\']->value[\'登陆预存款\'];?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>
 <?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php echo $_smarty_tpl->tpl_vars[\'c\']->value[\'交易币名称\'];?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';
echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'，最多可以激活该产品\'];?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>
 <?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php echo $_smarty_tpl->tpl_vars[\'payday\']->value;?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>
 /<?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php echo $_smarty_tpl->tpl_vars[\'goods\']->value[\'周期\'];?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';
echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php } else { ?>/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';
echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'产品为免费产品,最多可续期\'];?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';
echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php if ((isset($_smarty_tpl->tpl_vars[\'goods\']->value[\'周期\'])?$_smarty_tpl->tpl_vars[\'goods\']->value[\'周期\']:\'\') == \'日付\') {?>/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';
echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'30日\'];?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';
echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php } elseif ((isset($_smarty_tpl->tpl_vars[\'goods\']->value[\'周期\'])?$_smarty_tpl->tpl_vars[\'goods\']->value[\'周期\']:\'\') == \'月付\') {?>/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';
echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'1月\'];?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';
echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php } elseif ((isset($_smarty_tpl->tpl_vars[\'goods\']->value[\'周期\'])?$_smarty_tpl->tpl_vars[\'goods\']->value[\'周期\']:\'\') == \'年付\') {?>/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';
echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'1年\'];?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';
echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php }?>/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';
echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php }?>/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>
</p>
                  <?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php }?>/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>

                </div>
                <button class="btn btn-primary"><?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'续期\'];?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>
</button>
                </form><br/>
                </div>
				<div class="col-md-6">
                  <h3><?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'重置产品密码\'];?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>
</h3>
                  <br/><br/>
                  <form action="repass/" method="post">
                    <p><?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'考虑到安全问题，控制中心不提供自定义修改产品密码，您可以在产品面板自定义修改密码，如果您忘记了修改的密码，请点击重置按钮，系统将为您重置为一个10位随机密码。\'];?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>
</p>
                    <button class="btn" data-dismiss="modal" ><?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'取消\'];?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>
</button>
					<button class="btn btn-primary" onclick="$('#resetPass').find('form').submit();$(this).button('loading');"><?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'重置\'];?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>
</button>
                  </form>
                  </div>
                  <div class="col-md-6">
                  <h3><?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'停止/取消服务\'];?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>
</h3>
                  <br/><br/>
                  <form action="stop/" method="post">
                    <p><?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'如果您的产品出现问题,或者不想使用服务了,可以选择停止产品并取消服务,但是这个操作不能逆转,并且将不返还任何预存款!!\'];?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>
</p>
                    <button class="btn btn-primary" onclick="$('#Stop').find('form').submit();$(this).button('loading');"><?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'确定\'];?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>
</button>
                  </form>
                  </div>
                  <?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php } else { ?>/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>

                  <div class="col-md-6">
                  <h3><?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'续期产品\'];?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>
</h3>
                <form role="form" action="pay/" method="post">
                  <div class="form-group">
                  <label><?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'续期天数\'];?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>
</label>
                  <?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php if (is_array((isset($_smarty_tpl->tpl_vars[\'goods\']->value[\'周期\'])?$_smarty_tpl->tpl_vars[\'goods\']->value[\'周期\']:\'\'))) {?>/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>

                  <select name="cycleid" class="form-control">
                    <?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars[\'goods\']->value[\'可续期周期\'], \'row\', false, \'num\');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars[\'num\']->value => $_smarty_tpl->tpl_vars[\'row\']->value) {
?>/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>

                    <option value="<?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php echo $_smarty_tpl->tpl_vars[\'num\']->value;?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>
"><?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php echo $_smarty_tpl->tpl_vars[\'row\']->value[\'价格\'];?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';
echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php echo $_smarty_tpl->tpl_vars[\'c\']->value[\'交易币名称\'];?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>
/<?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php echo $_smarty_tpl->tpl_vars[\'row\']->value[\'时间\'];?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>
天</option>
                    <?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php
}
} else {
?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>

                    无法续费
                    <?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>

                     </select>
                  <?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php } else { ?>/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>

                  <?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php if ((isset($_smarty_tpl->tpl_vars[\'goods\']->value[\'价格\'])?$_smarty_tpl->tpl_vars[\'goods\']->value[\'价格\']:\'\') != \'免费\') {?>/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>

                  <input class="form-control" name="day" value="1" type="text" placeholder="续费数量" id="inputDay" onkeyup="this.value=this.value.replace(/\D|^0/g,'')" />
                  <?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php } else { ?>/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>

                  <?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'免费产品会自动帮你续期到目前最大的时间!!\'];?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>

                  <?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php }?>/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>

                  <span class="help-block"><?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'请确定续期日期在预存款可以续期内,否则续期失败!\'];?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>
</span>
                  <p class="text-info"><?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php if ((isset($_smarty_tpl->tpl_vars[\'goods\']->value[\'价格\'])?$_smarty_tpl->tpl_vars[\'goods\']->value[\'价格\']:\'\') != \'免费\') {?>/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';
echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'您目前拥有预存款\'];?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>
 <?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php echo $_smarty_tpl->tpl_vars[\'s\']->value[\'登陆预存款\'];?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>
 <?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php echo $_smarty_tpl->tpl_vars[\'c\']->value[\'交易币名称\'];?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';
echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'，最多可以激活该产品\'];?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>
 <?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php echo $_smarty_tpl->tpl_vars[\'payday\']->value;?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>
 /<?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php echo $_smarty_tpl->tpl_vars[\'goods\']->value[\'周期\'];?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';
echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php } else { ?>/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';
echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'产品为免费产品,最多可续期\'];?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';
echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php if ((isset($_smarty_tpl->tpl_vars[\'goods\']->value[\'周期\'])?$_smarty_tpl->tpl_vars[\'goods\']->value[\'周期\']:\'\') == \'日付\') {?>/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';
echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'30日\'];?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';
echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php } elseif ((isset($_smarty_tpl->tpl_vars[\'goods\']->value[\'周期\'])?$_smarty_tpl->tpl_vars[\'goods\']->value[\'周期\']:\'\') == \'月付\') {?>/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';
echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'1月\'];?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';
echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php } elseif ((isset($_smarty_tpl->tpl_vars[\'goods\']->value[\'周期\'])?$_smarty_tpl->tpl_vars[\'goods\']->value[\'周期\']:\'\') == \'年付\') {?>/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';
echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'1年\'];?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';
echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php }?>/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';
echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php }?>/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>
</p>
                  <?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php }?>/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>

                </div>
                <button class="btn btn-primary"><?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'续期\'];?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>
</button>
                </form>
                </div>
                  <?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php ob_start();
}
$_prefixVariable1=ob_get_clean();
echo $_prefixVariable1;?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>

              </div>
            </div>
          </div>
        </div><!--/.panel-->
      </div><!-- /.col-->
    </div><!-- /.row --><?php $_smarty_tpl->_subTemplateRender("file:copyright2.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 9999, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

  </div><!--/.main-->

  <?php echo '<script'; ?>
 src="<?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php echo $_smarty_tpl->tpl_vars[\'templatedir\']->value;?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>
/js/jquery-1.11.1.min.js"><?php echo '</script'; ?>
>
  <?php echo '<script'; ?>
 src="<?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php echo $_smarty_tpl->tpl_vars[\'templatedir\']->value;?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>
/js/bootstrap.min.js"><?php echo '</script'; ?>
>
  <?php echo '<script'; ?>
 src="<?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php echo $_smarty_tpl->tpl_vars[\'templatedir\']->value;?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>
/js/chart.min.js"><?php echo '</script'; ?>
>
  <?php echo '<script'; ?>
 src="<?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php echo $_smarty_tpl->tpl_vars[\'templatedir\']->value;?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>
/js/chart-data.js"><?php echo '</script'; ?>
>
  <?php echo '<script'; ?>
 src="<?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php echo $_smarty_tpl->tpl_vars[\'templatedir\']->value;?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>
/js/easypiechart.js"><?php echo '</script'; ?>
>
  <?php echo '<script'; ?>
 src="<?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php echo $_smarty_tpl->tpl_vars[\'templatedir\']->value;?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>
/js/easypiechart-data.js"><?php echo '</script'; ?>
>
  <?php echo '<script'; ?>
 src="<?php echo '/*%%SmartyNocache:586805295593e174c5fb122_39130018%%*/<?php echo $_smarty_tpl->tpl_vars[\'templatedir\']->value;?>
/*/%%SmartyNocache:586805295593e174c5fb122_39130018%%*/';?>
/js/bootstrap-datepicker.js"><?php echo '</script'; ?>
>
</body>

</html><?php }
}
