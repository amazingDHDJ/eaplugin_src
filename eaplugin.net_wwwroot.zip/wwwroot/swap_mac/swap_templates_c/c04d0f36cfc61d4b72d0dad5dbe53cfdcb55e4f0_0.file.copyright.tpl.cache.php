<?php
/* Smarty version 3.1.30, created on 2017-06-12 11:25:34
  from "/home/ftp/s/s7234915/wwwroot/templates/goule_bootstrap/copyright.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_593e09ae2f91b8_45032618',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'c04d0f36cfc61d4b72d0dad5dbe53cfdcb55e4f0' => 
    array (
      0 => '/home/ftp/s/s7234915/wwwroot/templates/goule_bootstrap/copyright.tpl',
      1 => 1497237650,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_593e09ae2f91b8_45032618 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->compiled->nocache_hash = '303557092593e09ae2f8877_83134129';
}
}
