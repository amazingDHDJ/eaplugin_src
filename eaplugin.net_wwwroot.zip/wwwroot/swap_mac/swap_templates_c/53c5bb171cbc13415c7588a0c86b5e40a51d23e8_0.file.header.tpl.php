<?php
/* Smarty version 3.1.30, created on 2017-06-12 11:18:43
  from "/home/ftp/s/s7234915/wwwroot/templates/XCAPP_Bootstrap3/header.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_593e0813754f58_14210031',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '53c5bb171cbc13415c7588a0c86b5e40a51d23e8' => 
    array (
      0 => '/home/ftp/s/s7234915/wwwroot/templates/XCAPP_Bootstrap3/header.tpl',
      1 => 1497237473,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_593e0813754f58_14210031 (Smarty_Internal_Template $_smarty_tpl) {
?>
<!DOCTYPE html>
<html lang="zh-cn">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
<meta name="author" content="XuxuGzs" />
<title><?php echo $_smarty_tpl->tpl_vars['hostname']->value;?>
 - <?php echo $_smarty_tpl->tpl_vars['title']->value;?>
</title>
<link rel="stylesheet" href="//cdn.bootcss.com/zui/1.6.0/css/zui.min.css">
<?php echo '<script'; ?>
 src="//cdn.bootcss.com/zui/1.6.0/lib/jquery/jquery.js"><?php echo '</script'; ?>
>
<!-- ZUI 标准版压缩后的 JavaScript 文件 -->
<?php echo '<script'; ?>
 src="//cdn.bootcss.com/zui/1.6.0/js/zui.min.js"><?php echo '</script'; ?>
>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<?php echo $_smarty_tpl->tpl_vars['plug']->value['HEAD区域'];?>

</head>
<body>
<nav class="navbar navbar-default">
  <div class="container-fluid">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
        <span class="sr-only">Menu</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="<?php echo $_smarty_tpl->tpl_vars['ROOT']->value;?>
/index/index/"><?php echo $_smarty_tpl->tpl_vars['c']->value['头部LOGO'];?>
</a>
    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav">
              <li><a href="<?php echo $_smarty_tpl->tpl_vars['ROOT']->value;?>
/index/index/" class=""><i class="glyphicon glyphicon-home"></i><?php echo $_smarty_tpl->tpl_vars['lang']->value['客户中心'];?>
</a></li>
			  <li><a href="<?php echo $_smarty_tpl->tpl_vars['ROOT']->value;?>
/control/index/"><i class="glyphicon glyphicon-tasks"></i><?php echo $_smarty_tpl->tpl_vars['lang']->value['控制面板'];?>
</a></li>
              <li><a href="<?php echo $_smarty_tpl->tpl_vars['ROOT']->value;?>
/buy/index/"><i class="glyphicon glyphicon-jpy"></i><?php echo $_smarty_tpl->tpl_vars['lang']->value['订购产品'];?>
</a></li>
              <li><a href="<?php echo $_smarty_tpl->tpl_vars['ROOT']->value;?>
/user/index/"><i class="glyphicon glyphicon-user"></i><?php echo $_smarty_tpl->tpl_vars['lang']->value['用户中心'];?>
</a></li>
      </ul>
      <ul class="nav navbar-nav navbar-right">
        <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><i class="glyphicon glyphicon-user"></i>
          <?php if ((isset($_smarty_tpl->tpl_vars['s']->value['是否已经登陆'])?$_smarty_tpl->tpl_vars['s']->value['是否已经登陆']:'') == '是') {
echo $_smarty_tpl->tpl_vars['lang']->value['欢迎回来'];?>
: <?php echo $_smarty_tpl->tpl_vars['s']->value['登陆用户名'];
} else { ?> 点此登录/注册 <?php }?><span class="caret"></span></a>
          <ul class="dropdown-menu">
           <?php if ((isset($_smarty_tpl->tpl_vars['s']->value['是否已经登陆'])?$_smarty_tpl->tpl_vars['s']->value['是否已经登陆']:'') == '是') {?>
          <li><a href="<?php echo $_smarty_tpl->tpl_vars['ROOT']->value;?>
/user/index/"><?php echo $_smarty_tpl->tpl_vars['lang']->value['我的资料'];?>
</a></li>
              <li><a href="<?php echo $_smarty_tpl->tpl_vars['ROOT']->value;?>
/index/login/"><?php echo $_smarty_tpl->tpl_vars['lang']->value['退出帐户'];?>
</a></li>
            <?php } else { ?>
              <li><a href="<?php echo $_smarty_tpl->tpl_vars['ROOT']->value;?>
/index/login/"><?php echo $_smarty_tpl->tpl_vars['lang']->value['登陆'];?>
</a></li>
              <li><a href="<?php echo $_smarty_tpl->tpl_vars['ROOT']->value;?>
/index/register/"><?php echo $_smarty_tpl->tpl_vars['lang']->value['注册'];?>
</a></li>
			      <?php }?> 
          </ul>
        </li>
      </ul>
    </div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
</nav>
<div class="container"><?php }
}
