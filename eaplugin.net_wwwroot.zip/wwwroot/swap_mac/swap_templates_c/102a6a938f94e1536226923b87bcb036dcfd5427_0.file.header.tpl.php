<?php
/* Smarty version 3.1.30, created on 2017-06-12 10:51:40
  from "/home/ftp/s/s7234915/wwwroot/templates/default/header.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_593e01bc8d6285_30658614',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '102a6a938f94e1536226923b87bcb036dcfd5427' => 
    array (
      0 => '/home/ftp/s/s7234915/wwwroot/templates/default/header.tpl',
      1 => 1497278394,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_593e01bc8d6285_30658614 (Smarty_Internal_Template $_smarty_tpl) {
?>
<html>
<head>
<meta charset="utf8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge, chrome=1" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<meta name="author" content="swapidc" />
<title><?php echo $_smarty_tpl->tpl_vars['hostname']->value;?>
 - <?php echo $_smarty_tpl->tpl_vars['title']->value;?>
</title>
<link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['templatedir']->value;?>
/css/bootstrap.css" />
<link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['templatedir']->value;?>
/css/bootstrap-responsive.css" />
<link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['templatedir']->value;?>
/css/googleapis.css" />
<link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['templatedir']->value;?>
/css/styles.css" />
<link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['templatedir']->value;?>
/css/toastr.css" />
<link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['templatedir']->value;?>
/css/fullcalendar.css" />
<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['templatedir']->value;?>
/js/jquery-1.11.0.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['templatedir']->value;?>
/js/bootstrap.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['templatedir']->value;?>
/js/jquery.knob.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['templatedir']->value;?>
/js/d3.v3.min.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['templatedir']->value;?>
/js/jquery.sparkline.min.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['templatedir']->value;?>
/js/toastr.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['templatedir']->value;?>
/js/jquery.tablesorter.min.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['templatedir']->value;?>
/js/jquery.peity.min.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['templatedir']->value;?>
/js/fullcalendar.min.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['templatedir']->value;?>
/js/gcal.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['templatedir']->value;?>
/js/setup.js"><?php echo '</script'; ?>
>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" /><?php echo $_smarty_tpl->tpl_vars['plug']->value['HEAD区域'];?>
</head><?php }
}
