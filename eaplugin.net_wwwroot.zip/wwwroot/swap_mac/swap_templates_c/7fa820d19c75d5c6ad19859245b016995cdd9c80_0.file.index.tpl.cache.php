<?php
/* Smarty version 3.1.30, created on 2017-06-12 16:52:08
  from "/home/ftp/s/s7234915/wwwroot/templates/goule_bootstrap/index.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_593e5638921c47_99317407',
  'has_nocache_code' => true,
  'file_dependency' => 
  array (
    '7fa820d19c75d5c6ad19859245b016995cdd9c80' => 
    array (
      0 => '/home/ftp/s/s7234915/wwwroot/templates/goule_bootstrap/index.tpl',
      1 => 1497257520,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:top.tpl' => 1,
    'file:left.tpl' => 1,
    'file:copyright.tpl' => 1,
    'file:alert.tpl' => 1,
    'file:copyright2.tpl' => 1,
  ),
),false)) {
function content_593e5638921c47_99317407 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->compiled->nocache_hash = '174562390593e56388a2b62_92727002';
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?php echo '/*%%SmartyNocache:174562390593e56388a2b62_92727002%%*/<?php echo $_smarty_tpl->tpl_vars[\'c\']->value[\'网站名称\'];?>
/*/%%SmartyNocache:174562390593e56388a2b62_92727002%%*/';?>
 - <?php echo '/*%%SmartyNocache:174562390593e56388a2b62_92727002%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'客户中心\'];?>
/*/%%SmartyNocache:174562390593e56388a2b62_92727002%%*/';?>
</title>
<link href="<?php echo '/*%%SmartyNocache:174562390593e56388a2b62_92727002%%*/<?php echo $_smarty_tpl->tpl_vars[\'templatedir\']->value;?>
/*/%%SmartyNocache:174562390593e56388a2b62_92727002%%*/';?>
/css/bootstrap.min.css" rel="stylesheet">
<link href="<?php echo '/*%%SmartyNocache:174562390593e56388a2b62_92727002%%*/<?php echo $_smarty_tpl->tpl_vars[\'templatedir\']->value;?>
/*/%%SmartyNocache:174562390593e56388a2b62_92727002%%*/';?>
/css/datepicker3.css" rel="stylesheet">
<link href="<?php echo '/*%%SmartyNocache:174562390593e56388a2b62_92727002%%*/<?php echo $_smarty_tpl->tpl_vars[\'templatedir\']->value;?>
/*/%%SmartyNocache:174562390593e56388a2b62_92727002%%*/';?>
/css/styles.css" rel="stylesheet">

<!--[if lt IE 9]>
<?php echo '<script'; ?>
 src="<?php echo '/*%%SmartyNocache:174562390593e56388a2b62_92727002%%*/<?php echo $_smarty_tpl->tpl_vars[\'templatedir\']->value;?>
/*/%%SmartyNocache:174562390593e56388a2b62_92727002%%*/';?>
/js/html5shiv.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="<?php echo '/*%%SmartyNocache:174562390593e56388a2b62_92727002%%*/<?php echo $_smarty_tpl->tpl_vars[\'templatedir\']->value;?>
/*/%%SmartyNocache:174562390593e56388a2b62_92727002%%*/';?>
/js/respond.min.js"><?php echo '</script'; ?>
>
<![endif]-->

</head>
<body>
  <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
    <div class="container-fluid">
      <div class="navbar-header">
        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#sidebar-collapse" aria-controls="bs-navbar" aria-expanded="false">
          <span class="sr-only">Toggle navigation</span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
        </button>
        <a class="navbar-brand" href="/"><span><?php echo '/*%%SmartyNocache:174562390593e56388a2b62_92727002%%*/<?php echo $_smarty_tpl->tpl_vars[\'c\']->value[\'头部LOGO\'];?>
/*/%%SmartyNocache:174562390593e56388a2b62_92727002%%*/';?>
</span> <?php echo '/*%%SmartyNocache:174562390593e56388a2b62_92727002%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'客户中心\'];?>
/*/%%SmartyNocache:174562390593e56388a2b62_92727002%%*/';?>
</a>
        <?php $_smarty_tpl->_subTemplateRender("file:top.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 9999, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

      </div>
    </div><!-- /.container-fluid -->
  </nav>
    
  <div id="sidebar-collapse" class="col-sm-3 col-lg-2 sidebar">
    <form role="search">
      <div class="form-group">
        <input type="text" class="form-control" placeholder="搜索 (不可用)">
      </div>
    </form>
    <ul class="nav menu">
      <li class="active"><a href="<?php echo '/*%%SmartyNocache:174562390593e56388a2b62_92727002%%*/<?php echo $_smarty_tpl->tpl_vars[\'ROOT\']->value;?>
/*/%%SmartyNocache:174562390593e56388a2b62_92727002%%*/';?>
/index/"><span class="glyphicon glyphicon-dashboard"></span> <?php echo '/*%%SmartyNocache:174562390593e56388a2b62_92727002%%*/<?php echo $_smarty_tpl->tpl_vars[\'mlang\']->value[\'仪表盘\'];?>
/*/%%SmartyNocache:174562390593e56388a2b62_92727002%%*/';?>
</a></li>
      <li class="parent">
        <a data-toggle="collapse" href="#sub-item-1">
          <span class="glyphicon glyphicon-hdd"></span> <?php echo '/*%%SmartyNocache:174562390593e56388a2b62_92727002%%*/<?php echo $_smarty_tpl->tpl_vars[\'mlang\']->value[\'客户中心\'];?>
/*/%%SmartyNocache:174562390593e56388a2b62_92727002%%*/';?>
 <span class="icon pull-right"><em class="glyphicon glyphicon-s glyphicon-plus"></em></span> 
        </a>
        <ul class="children collapse" id="sub-item-1">
          <li>
            <a class="" href="<?php echo '/*%%SmartyNocache:174562390593e56388a2b62_92727002%%*/<?php echo $_smarty_tpl->tpl_vars[\'ROOT\']->value;?>
/*/%%SmartyNocache:174562390593e56388a2b62_92727002%%*/';?>
/buy/">
              <span class="glyphicon glyphicon-shopping-cart"></span> <?php echo '/*%%SmartyNocache:174562390593e56388a2b62_92727002%%*/<?php echo $_smarty_tpl->tpl_vars[\'mlang\']->value[\'订购产品\'];?>
/*/%%SmartyNocache:174562390593e56388a2b62_92727002%%*/';?>

            </a>
          </li>
          <li>
            <a class="" href="<?php echo '/*%%SmartyNocache:174562390593e56388a2b62_92727002%%*/<?php echo $_smarty_tpl->tpl_vars[\'ROOT\']->value;?>
/*/%%SmartyNocache:174562390593e56388a2b62_92727002%%*/';?>
/control/">
              <span class="glyphicon glyphicon-tasks"></span> <?php echo '/*%%SmartyNocache:174562390593e56388a2b62_92727002%%*/<?php echo $_smarty_tpl->tpl_vars[\'mlang\']->value[\'控制面板\'];?>
/*/%%SmartyNocache:174562390593e56388a2b62_92727002%%*/';?>
  
            </a>
          </li>
        </ul>
      </li>
      <li><a href="<?php echo '/*%%SmartyNocache:174562390593e56388a2b62_92727002%%*/<?php echo $_smarty_tpl->tpl_vars[\'ROOT\']->value;?>
/*/%%SmartyNocache:174562390593e56388a2b62_92727002%%*/';?>
/help/"><span class="glyphicon glyphicon-list-alt"></span> <?php echo '/*%%SmartyNocache:174562390593e56388a2b62_92727002%%*/<?php echo $_smarty_tpl->tpl_vars[\'mlang\']->value[\'帮助中心\'];?>
/*/%%SmartyNocache:174562390593e56388a2b62_92727002%%*/';?>
</a></li>
	  <li><a href="<?php echo '/*%%SmartyNocache:174562390593e56388a2b62_92727002%%*/<?php echo $_smarty_tpl->tpl_vars[\'ROOT\']->value;?>
/*/%%SmartyNocache:174562390593e56388a2b62_92727002%%*/';?>
/user/pay/"><span class="glyphicon glyphicon-jpy"></span> <?php echo '/*%%SmartyNocache:174562390593e56388a2b62_92727002%%*/<?php echo $_smarty_tpl->tpl_vars[\'mlang\']->value[\'账户充值\'];?>
/*/%%SmartyNocache:174562390593e56388a2b62_92727002%%*/';?>
</a></li>
      <li role="presentation" class="divider"></li>
      <?php $_smarty_tpl->_subTemplateRender("file:left.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 9999, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    </ul>
    <?php $_smarty_tpl->_subTemplateRender("file:copyright.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 9999, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

  </div><!--/.sidebar-->

  <div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">     
    <div class="row">
      <ol class="breadcrumb">
        <li><span class="glyphicon glyphicon-home"></span></li>
        <li class="active"><?php echo '/*%%SmartyNocache:174562390593e56388a2b62_92727002%%*/<?php echo $_smarty_tpl->tpl_vars[\'mlang\']->value[\'用户引索\'];?>
/*/%%SmartyNocache:174562390593e56388a2b62_92727002%%*/';?>
</li>
      </ol>
    </div><!--/.row-->
    <br/>
    <?php echo '/*%%SmartyNocache:174562390593e56388a2b62_92727002%%*/<?php if ((isset($_smarty_tpl->tpl_vars[\'s\']->value[\'是否已经登陆\'])?$_smarty_tpl->tpl_vars[\'s\']->value[\'是否已经登陆\']:\'\') == \'是\') {?>/*/%%SmartyNocache:174562390593e56388a2b62_92727002%%*/';?>

    <div class="row">
      <div class="col-xs-12 col-md-6 col-lg-3">
        <div class="panel panel-blue panel-widget ">
          <a href="<?php echo '/*%%SmartyNocache:174562390593e56388a2b62_92727002%%*/<?php echo $_smarty_tpl->tpl_vars[\'ROOT\']->value;?>
/*/%%SmartyNocache:174562390593e56388a2b62_92727002%%*/';?>
/control/">
          <div class="row no-padding">
            <div class="col-sm-3 col-lg-5 widget-left">
              <em class="glyphicon glyphicon-tasks glyphicon-l"></em>
            </div>
            <div class="col-sm-9 col-lg-7 widget-right">
              <div class="large"><?php echo '/*%%SmartyNocache:174562390593e56388a2b62_92727002%%*/<?php echo $_smarty_tpl->tpl_vars[\'ActiveService\']->value;?>
/*/%%SmartyNocache:174562390593e56388a2b62_92727002%%*/';?>
个</div>
              <div class="text-muted"><?php echo '/*%%SmartyNocache:174562390593e56388a2b62_92727002%%*/<?php echo $_smarty_tpl->tpl_vars[\'mlang\']->value[\'有效的服务\'];?>
/*/%%SmartyNocache:174562390593e56388a2b62_92727002%%*/';?>
</div>
            </div>
          </div>
          </a>
        </div>
      </div>
      <div class="col-xs-12 col-md-6 col-lg-3">
        <div class="panel panel-orange panel-widget">
          <a href="<?php echo '/*%%SmartyNocache:174562390593e56388a2b62_92727002%%*/<?php echo $_smarty_tpl->tpl_vars[\'ROOT\']->value;?>
/*/%%SmartyNocache:174562390593e56388a2b62_92727002%%*/';?>
/ticket/">
          <div class="row no-padding">
            <div class="col-sm-3 col-lg-5 widget-left">
              <em class="glyphicon glyphicon-signal glyphicon-l"></em>
            </div>
            <div class="col-sm-9 col-lg-7 widget-right">
              <div class="large"><?php echo '/*%%SmartyNocache:174562390593e56388a2b62_92727002%%*/<?php echo $_smarty_tpl->tpl_vars[\'OpenTicket\']->value;?>
/*/%%SmartyNocache:174562390593e56388a2b62_92727002%%*/';?>
个</div>
              <div class="text-muted"><?php echo '/*%%SmartyNocache:174562390593e56388a2b62_92727002%%*/<?php echo $_smarty_tpl->tpl_vars[\'mlang\']->value[\'开启的工单\'];?>
/*/%%SmartyNocache:174562390593e56388a2b62_92727002%%*/';?>
</div>
            </div>
          </div>
          </a>
        </div>
      </div>
      <div class="col-xs-12 col-md-6 col-lg-3">
        <div class="panel panel-teal panel-widget">
          <a href="<?php echo '/*%%SmartyNocache:174562390593e56388a2b62_92727002%%*/<?php echo $_smarty_tpl->tpl_vars[\'ROOT\']->value;?>
/*/%%SmartyNocache:174562390593e56388a2b62_92727002%%*/';?>
/user/pay/">
          <div class="row no-padding">
            <div class="col-sm-3 col-lg-5 widget-left">
              <em class="glyphicon glyphicon-credit-card glyphicon-l"></em>
            </div>
            <div class="col-sm-9 col-lg-7 widget-right">
              <div class="large"><?php echo '/*%%SmartyNocache:174562390593e56388a2b62_92727002%%*/<?php echo $_smarty_tpl->tpl_vars[\'s\']->value[\'登陆预存款\'];?>
/*/%%SmartyNocache:174562390593e56388a2b62_92727002%%*/';
echo '/*%%SmartyNocache:174562390593e56388a2b62_92727002%%*/<?php echo $_smarty_tpl->tpl_vars[\'c\']->value[\'交易币名称\'];?>
/*/%%SmartyNocache:174562390593e56388a2b62_92727002%%*/';?>
</div>
              <div class="text-muted"><?php echo '/*%%SmartyNocache:174562390593e56388a2b62_92727002%%*/<?php echo $_smarty_tpl->tpl_vars[\'mlang\']->value[\'预存款\'];?>
/*/%%SmartyNocache:174562390593e56388a2b62_92727002%%*/';?>
</div>
            </div>
          </div>
          </a>
        </div>
      </div>
      <div class="col-xs-12 col-md-6 col-lg-3">
        <div class="panel panel-red panel-widget">
          <a href="<?php echo '/*%%SmartyNocache:174562390593e56388a2b62_92727002%%*/<?php echo $_smarty_tpl->tpl_vars[\'ROOT\']->value;?>
/*/%%SmartyNocache:174562390593e56388a2b62_92727002%%*/';?>
/control/">
          <div class="row no-padding">
            <div class="col-sm-3 col-lg-5 widget-left">
              <em class="glyphicon glyphicon-exclamation-sign glyphicon-l"></em>
            </div>
            <div class="col-sm-9 col-lg-7 widget-right">
              <div class="large"><?php echo '/*%%SmartyNocache:174562390593e56388a2b62_92727002%%*/<?php echo $_smarty_tpl->tpl_vars[\'Date\']->value;?>
/*/%%SmartyNocache:174562390593e56388a2b62_92727002%%*/';?>
个</div>
              <div class="text-muted"><?php echo '/*%%SmartyNocache:174562390593e56388a2b62_92727002%%*/<?php echo $_smarty_tpl->tpl_vars[\'mlang\']->value[\'15天内到期\'];?>
/*/%%SmartyNocache:174562390593e56388a2b62_92727002%%*/';?>
</div>
            </div>
          </div>
        </a>
        </div>
      </div>
    </div><!--/.row-->
     <?php echo '/*%%SmartyNocache:174562390593e56388a2b62_92727002%%*/<?php } else { ?>/*/%%SmartyNocache:174562390593e56388a2b62_92727002%%*/';?>

    <br/><br/><br/>
      <center><font size="36"color="red"><?php echo '/*%%SmartyNocache:174562390593e56388a2b62_92727002%%*/<?php echo $_smarty_tpl->tpl_vars[\'c\']->value[\'网站名称\'];?>
/*/%%SmartyNocache:174562390593e56388a2b62_92727002%%*/';?>
 登陆后享受更多服务!</font></center>
    <?php echo '/*%%SmartyNocache:174562390593e56388a2b62_92727002%%*/<?php }?>/*/%%SmartyNocache:174562390593e56388a2b62_92727002%%*/';?>

    <div class="row">
      <div class="col-lg-12">
        <?php $_smarty_tpl->_subTemplateRender("file:alert.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 9999, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

        <div class="panel panel-default">
          <div class="panel-body">
            <div class="canvas-wrapper">
              <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th class="span5">
                                        网站公告
                                    </th>
                                    <th class="span1">
                                        <span class="line"></span>发布时间
                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                                <!-- row -->
                                <?php echo '/*%%SmartyNocache:174562390593e56388a2b62_92727002%%*/<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars[\'news\']->value, \'new\');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars[\'new\']->value) {
?>/*/%%SmartyNocache:174562390593e56388a2b62_92727002%%*/';?>

                                <tr class="first">
                                  <td>
                                        <a href="<?php echo '/*%%SmartyNocache:174562390593e56388a2b62_92727002%%*/<?php echo $_smarty_tpl->tpl_vars[\'ROOT\']->value;?>
/*/%%SmartyNocache:174562390593e56388a2b62_92727002%%*/';?>
/index/announcement/<?php echo '/*%%SmartyNocache:174562390593e56388a2b62_92727002%%*/<?php echo $_smarty_tpl->tpl_vars[\'new\']->value[\'公告ID\'];?>
/*/%%SmartyNocache:174562390593e56388a2b62_92727002%%*/';?>
/"><?php echo '/*%%SmartyNocache:174562390593e56388a2b62_92727002%%*/<?php echo $_smarty_tpl->tpl_vars[\'new\']->value[\'公告标题\'];?>
/*/%%SmartyNocache:174562390593e56388a2b62_92727002%%*/';?>
</a>
                                    </td>
                  <td class="description">
                                        <?php echo '/*%%SmartyNocache:174562390593e56388a2b62_92727002%%*/<?php echo $_smarty_tpl->tpl_vars[\'new\']->value[\'公告时间\'];?>
/*/%%SmartyNocache:174562390593e56388a2b62_92727002%%*/';?>

                                    </td>
                                </tr>
                                <?php echo '/*%%SmartyNocache:174562390593e56388a2b62_92727002%%*/<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>
/*/%%SmartyNocache:174562390593e56388a2b62_92727002%%*/';?>

                            </tbody>
                        </table>
            </div>
          </div>
        </div>
      </div>
    </div><!--/.row-->
    <?php $_smarty_tpl->_subTemplateRender("file:copyright2.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 9999, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

  </div>  <!--/.main-->

  <?php echo '<script'; ?>
 src="<?php echo '/*%%SmartyNocache:174562390593e56388a2b62_92727002%%*/<?php echo $_smarty_tpl->tpl_vars[\'templatedir\']->value;?>
/*/%%SmartyNocache:174562390593e56388a2b62_92727002%%*/';?>
/js/jquery-1.11.1.min.js"><?php echo '</script'; ?>
>
  <?php echo '<script'; ?>
 src="<?php echo '/*%%SmartyNocache:174562390593e56388a2b62_92727002%%*/<?php echo $_smarty_tpl->tpl_vars[\'templatedir\']->value;?>
/*/%%SmartyNocache:174562390593e56388a2b62_92727002%%*/';?>
/js/bootstrap.min.js"><?php echo '</script'; ?>
>
  <?php echo '<script'; ?>
 src="<?php echo '/*%%SmartyNocache:174562390593e56388a2b62_92727002%%*/<?php echo $_smarty_tpl->tpl_vars[\'templatedir\']->value;?>
/*/%%SmartyNocache:174562390593e56388a2b62_92727002%%*/';?>
/js/chart.min.js"><?php echo '</script'; ?>
>
  <?php echo '<script'; ?>
 src="<?php echo '/*%%SmartyNocache:174562390593e56388a2b62_92727002%%*/<?php echo $_smarty_tpl->tpl_vars[\'templatedir\']->value;?>
/*/%%SmartyNocache:174562390593e56388a2b62_92727002%%*/';?>
/js/chart-data.js"><?php echo '</script'; ?>
>
  <?php echo '<script'; ?>
 src="<?php echo '/*%%SmartyNocache:174562390593e56388a2b62_92727002%%*/<?php echo $_smarty_tpl->tpl_vars[\'templatedir\']->value;?>
/*/%%SmartyNocache:174562390593e56388a2b62_92727002%%*/';?>
/js/easypiechart.js"><?php echo '</script'; ?>
>
  <?php echo '<script'; ?>
 src="<?php echo '/*%%SmartyNocache:174562390593e56388a2b62_92727002%%*/<?php echo $_smarty_tpl->tpl_vars[\'templatedir\']->value;?>
/*/%%SmartyNocache:174562390593e56388a2b62_92727002%%*/';?>
/js/easypiechart-data.js"><?php echo '</script'; ?>
>
  <?php echo '<script'; ?>
 src="<?php echo '/*%%SmartyNocache:174562390593e56388a2b62_92727002%%*/<?php echo $_smarty_tpl->tpl_vars[\'templatedir\']->value;?>
/*/%%SmartyNocache:174562390593e56388a2b62_92727002%%*/';?>
/js/bootstrap-datepicker.js"><?php echo '</script'; ?>
>
  <?php echo '<script'; ?>
>
    $('#calendar').datepicker({
    });

    !function ($) {
        $(document).on("click","ul.nav li.parent > a > span.icon", function(){          
            $(this).find('em:first').toggleClass("glyphicon-minus");      
        }); 
        $(".sidebar span.icon").find('em:first').addClass("glyphicon-plus");
    }(window.jQuery);

    $(window).on('resize', function () {
      if ($(window).width() > 768) $('#sidebar-collapse').collapse('show')
    })
    $(window).on('resize', function () {
      if ($(window).width() <= 767) $('#sidebar-collapse').collapse('hide')
    })
  <?php echo '</script'; ?>
> 
</body>

</html><?php }
}
