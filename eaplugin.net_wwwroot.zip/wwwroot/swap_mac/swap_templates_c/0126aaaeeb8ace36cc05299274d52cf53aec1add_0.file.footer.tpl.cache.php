<?php
/* Smarty version 3.1.30, created on 2017-06-12 11:50:17
  from "/home/ftp/s/s7234915/wwwroot/templates/goule_bootstrap/footer.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_593e0f79f32835_92690145',
  'has_nocache_code' => true,
  'file_dependency' => 
  array (
    '0126aaaeeb8ace36cc05299274d52cf53aec1add' => 
    array (
      0 => '/home/ftp/s/s7234915/wwwroot/templates/goule_bootstrap/footer.tpl',
      1 => 1497237650,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_593e0f79f32835_92690145 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->compiled->nocache_hash = '950964437593e0f79f30177_90265353';
?>
<p class="pull-right" style="display:none">Powered by <a href="http://www.swapidc.com/">SWAPIDC</a></p>
<p><center><?php echo '/*%%SmartyNocache:950964437593e0f79f30177_90265353%%*/<?php echo $_smarty_tpl->tpl_vars[\'c\']->value[\'底部版权\'];?>
/*/%%SmartyNocache:950964437593e0f79f30177_90265353%%*/';?>

</center></p>
</body>
</html><?php }
}
