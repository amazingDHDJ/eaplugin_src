<?php
/* Smarty version 3.1.30, created on 2017-06-12 13:28:06
  from "/home/ftp/s/s7234915/wwwroot/templates/goule_bootstrap/login.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_593e26669554f5_25750328',
  'has_nocache_code' => true,
  'file_dependency' => 
  array (
    '2738cbf162820bfb1145fe2397f726abda7f9f52' => 
    array (
      0 => '/home/ftp/s/s7234915/wwwroot/templates/goule_bootstrap/login.tpl',
      1 => 1497239666,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:alert.tpl' => 1,
    'file:copyright.tpl' => 1,
    'file:copyright2.tpl' => 1,
  ),
),false)) {
function content_593e26669554f5_25750328 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->compiled->nocache_hash = '525562043593e26668b4153_24797769';
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
      <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title><?php echo '/*%%SmartyNocache:525562043593e26668b4153_24797769%%*/<?php echo $_smarty_tpl->tpl_vars[\'c\']->value[\'网站名称\'];?>
/*/%%SmartyNocache:525562043593e26668b4153_24797769%%*/';?>
 - <?php echo '/*%%SmartyNocache:525562043593e26668b4153_24797769%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'登陆\'];?>
/*/%%SmartyNocache:525562043593e26668b4153_24797769%%*/';?>
</title>

    <!-- BOOTSTRAP STYLES-->
    <link href="<?php echo '/*%%SmartyNocache:525562043593e26668b4153_24797769%%*/<?php echo $_smarty_tpl->tpl_vars[\'templatedir\']->value;?>
/*/%%SmartyNocache:525562043593e26668b4153_24797769%%*/';?>
/css/bootstrap.min.css" rel="stylesheet" />
    <!-- GOOGLE FONTS-->
    <link href='//fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
</head>
<body style="background: url('<?php echo '/*%%SmartyNocache:525562043593e26668b4153_24797769%%*/<?php echo $_smarty_tpl->tpl_vars[\'ROOT\']->value;?>
/*/%%SmartyNocache:525562043593e26668b4153_24797769%%*/';?>
/watermark.png') center center no-repeat;">
    <div class="container">
        <div class="row text-center " style="padding-top:100px;">
            <div class="col-md-12">
                <font size="36">
                <?php echo '/*%%SmartyNocache:525562043593e26668b4153_24797769%%*/<?php echo $_smarty_tpl->tpl_vars[\'c\']->value[\'头部LOGO\'];?>
/*/%%SmartyNocache:525562043593e26668b4153_24797769%%*/';?>

                </font>
            </div>
        </div>
         <div class="row ">
                <div class="col-md-4 col-md-offset-4 col-sm-6 col-sm-offset-3 col-xs-10 col-xs-offset-1">
                           
                            <div class="panel-body">
                                <form role="form" method="post">
                                    <hr />
                                    <div class="row text-center ">
                                    <h5>---登陆享受更多服务哦---</h5>
                                    </div>
                                       <br /><?php $_smarty_tpl->_subTemplateRender("file:alert.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 9999, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

                                     <div class="form-group input-group">
                                            <span class="input-group-addon"><i class="glyphicon glyphicon-tag"></i></span>
                                            <input type="text" class="form-control" placeholder="您的用户名" name="swapname"/>
                                        </div>
                                                                              <div class="form-group input-group">
                                            <span class="input-group-addon"><i class="glyphicon glyphicon-asterisk"></i></span>
                                            <input type="password" class="form-control"  placeholder="您的密码" name="swappass"/>
                                        </div>
                                    <div class="form-group">
                                            <!--<label class="checkbox-inline">
                                                <input type="checkbox" /> 记住我(开发中)
                                            </label>-->
                                            <span class="pull-right">
                                                   <a href="<?php echo '/*%%SmartyNocache:525562043593e26668b4153_24797769%%*/<?php echo $_smarty_tpl->tpl_vars[\'ROOT\']->value;?>
/*/%%SmartyNocache:525562043593e26668b4153_24797769%%*/';?>
/plugin/forgot_password/index/" >忘记密码？ </a> 
                                            </span>
                                        </div>
									 <input type="submit" class="btn btn-primary" value="现在登录">
                                    <hr />
                                    <h6>还没注册 ? <a href="<?php echo '/*%%SmartyNocache:525562043593e26668b4153_24797769%%*/<?php echo $_smarty_tpl->tpl_vars[\'ROOT\']->value;?>
/*/%%SmartyNocache:525562043593e26668b4153_24797769%%*/';?>
/index/register/" >立刻注册! </a> 或者 <a href="/">返回首页</a></h6>
                                    </form>
                            </div><br/><?php $_smarty_tpl->_subTemplateRender("file:copyright.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 9999, $_smarty_tpl->cache_lifetime, array(), 0, false);
$_smarty_tpl->_subTemplateRender("file:copyright2.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 9999, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

                        </div>
        </div>
    </div>

</body>
</html>
<?php }
}
