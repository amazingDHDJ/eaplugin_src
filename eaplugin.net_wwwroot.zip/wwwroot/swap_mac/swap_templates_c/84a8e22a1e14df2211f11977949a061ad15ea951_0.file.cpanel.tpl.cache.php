<?php
/* Smarty version 3.1.30, created on 2017-06-12 12:15:54
  from "/home/ftp/s/s7234915/wwwroot/templates/goule_bootstrap/cpanel.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_593e157ad9c2b4_87496723',
  'has_nocache_code' => true,
  'file_dependency' => 
  array (
    '84a8e22a1e14df2211f11977949a061ad15ea951' => 
    array (
      0 => '/home/ftp/s/s7234915/wwwroot/templates/goule_bootstrap/cpanel.tpl',
      1 => 1497237650,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:top.tpl' => 1,
    'file:left.tpl' => 1,
    'file:copyright.tpl' => 1,
    'file:alert.tpl' => 1,
    'file:copyright2.tpl' => 1,
  ),
),false)) {
function content_593e157ad9c2b4_87496723 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->compiled->nocache_hash = '1491850122593e157ad06591_52745482';
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?php echo '/*%%SmartyNocache:1491850122593e157ad06591_52745482%%*/<?php echo $_smarty_tpl->tpl_vars[\'c\']->value[\'网站名称\'];?>
/*/%%SmartyNocache:1491850122593e157ad06591_52745482%%*/';?>
 - <?php echo '/*%%SmartyNocache:1491850122593e157ad06591_52745482%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'控制面板\'];?>
/*/%%SmartyNocache:1491850122593e157ad06591_52745482%%*/';?>
</title>
<link href="<?php echo '/*%%SmartyNocache:1491850122593e157ad06591_52745482%%*/<?php echo $_smarty_tpl->tpl_vars[\'templatedir\']->value;?>
/*/%%SmartyNocache:1491850122593e157ad06591_52745482%%*/';?>
/css/bootstrap.min.css" rel="stylesheet">
<link href="<?php echo '/*%%SmartyNocache:1491850122593e157ad06591_52745482%%*/<?php echo $_smarty_tpl->tpl_vars[\'templatedir\']->value;?>
/*/%%SmartyNocache:1491850122593e157ad06591_52745482%%*/';?>
/css/datepicker3.css" rel="stylesheet">
<link href="<?php echo '/*%%SmartyNocache:1491850122593e157ad06591_52745482%%*/<?php echo $_smarty_tpl->tpl_vars[\'templatedir\']->value;?>
/*/%%SmartyNocache:1491850122593e157ad06591_52745482%%*/';?>
/css/styles.css" rel="stylesheet">

<!--[if lt IE 9]>
<?php echo '<script'; ?>
 src="<?php echo '/*%%SmartyNocache:1491850122593e157ad06591_52745482%%*/<?php echo $_smarty_tpl->tpl_vars[\'templatedir\']->value;?>
/*/%%SmartyNocache:1491850122593e157ad06591_52745482%%*/';?>
/js/html5shiv.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="<?php echo '/*%%SmartyNocache:1491850122593e157ad06591_52745482%%*/<?php echo $_smarty_tpl->tpl_vars[\'templatedir\']->value;?>
/*/%%SmartyNocache:1491850122593e157ad06591_52745482%%*/';?>
/js/respond.min.js"><?php echo '</script'; ?>
>
<![endif]-->

</head>
<body>
  <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
    <div class="container-fluid">
      <div class="navbar-header">
        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#sidebar-collapse">
          <span class="sr-only">Toggle navigation</span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
        </button>
        <a class="navbar-brand" href="/"><span><?php echo '/*%%SmartyNocache:1491850122593e157ad06591_52745482%%*/<?php echo $_smarty_tpl->tpl_vars[\'c\']->value[\'头部LOGO\'];?>
/*/%%SmartyNocache:1491850122593e157ad06591_52745482%%*/';?>
</span> <?php echo '/*%%SmartyNocache:1491850122593e157ad06591_52745482%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'控制面板\'];?>
/*/%%SmartyNocache:1491850122593e157ad06591_52745482%%*/';?>
</a>
        <?php $_smarty_tpl->_subTemplateRender("file:top.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 9999, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

      </div>
    </div><!-- /.container-fluid -->
  </nav>
    
  <div id="sidebar-collapse" class="col-sm-3 col-lg-2 sidebar">
    <form role="search">
      <div class="form-group">
        <input type="text" class="form-control" placeholder="搜索 (不可用)">
      </div>
    </form>
    <ul class="nav menu">
      <li><a href="<?php echo '/*%%SmartyNocache:1491850122593e157ad06591_52745482%%*/<?php echo $_smarty_tpl->tpl_vars[\'ROOT\']->value;?>
/*/%%SmartyNocache:1491850122593e157ad06591_52745482%%*/';?>
/index/"><span class="glyphicon glyphicon-dashboard"></span> <?php echo '/*%%SmartyNocache:1491850122593e157ad06591_52745482%%*/<?php echo $_smarty_tpl->tpl_vars[\'mlang\']->value[\'仪表盘\'];?>
/*/%%SmartyNocache:1491850122593e157ad06591_52745482%%*/';?>
</a></li>
      <li class="parent">
        <a data-toggle="collapse" href="#sub-item-1">
          <span class="glyphicon glyphicon-hdd"></span> <?php echo '/*%%SmartyNocache:1491850122593e157ad06591_52745482%%*/<?php echo $_smarty_tpl->tpl_vars[\'mlang\']->value[\'客户中心\'];?>
/*/%%SmartyNocache:1491850122593e157ad06591_52745482%%*/';?>
 <span class="icon pull-right"><em class="glyphicon glyphicon-s glyphicon-plus"></em></span> 
        </a>
        <ul class="children collapse in" id="sub-item-1">
          <li>
            <a href="<?php echo '/*%%SmartyNocache:1491850122593e157ad06591_52745482%%*/<?php echo $_smarty_tpl->tpl_vars[\'ROOT\']->value;?>
/*/%%SmartyNocache:1491850122593e157ad06591_52745482%%*/';?>
/buy/">
              <span class="glyphicon glyphicon-shopping-cart"></span> <?php echo '/*%%SmartyNocache:1491850122593e157ad06591_52745482%%*/<?php echo $_smarty_tpl->tpl_vars[\'mlang\']->value[\'订购产品\'];?>
/*/%%SmartyNocache:1491850122593e157ad06591_52745482%%*/';?>

            </a>
          </li>
          <li>
            <a href="<?php echo '/*%%SmartyNocache:1491850122593e157ad06591_52745482%%*/<?php echo $_smarty_tpl->tpl_vars[\'ROOT\']->value;?>
/*/%%SmartyNocache:1491850122593e157ad06591_52745482%%*/';?>
/control/">
              <span class="glyphicon glyphicon-tasks"></span> <?php echo '/*%%SmartyNocache:1491850122593e157ad06591_52745482%%*/<?php echo $_smarty_tpl->tpl_vars[\'mlang\']->value[\'控制面板\'];?>
/*/%%SmartyNocache:1491850122593e157ad06591_52745482%%*/';?>
  
            </a>
          </li>
        </ul>
      </li>
      <li><a href="<?php echo '/*%%SmartyNocache:1491850122593e157ad06591_52745482%%*/<?php echo $_smarty_tpl->tpl_vars[\'ROOT\']->value;?>
/*/%%SmartyNocache:1491850122593e157ad06591_52745482%%*/';?>
/help/"><span class="glyphicon glyphicon-list-alt"></span> <?php echo '/*%%SmartyNocache:1491850122593e157ad06591_52745482%%*/<?php echo $_smarty_tpl->tpl_vars[\'mlang\']->value[\'帮助中心\'];?>
/*/%%SmartyNocache:1491850122593e157ad06591_52745482%%*/';?>
</a></li>
	  <li><a href="<?php echo '/*%%SmartyNocache:1491850122593e157ad06591_52745482%%*/<?php echo $_smarty_tpl->tpl_vars[\'ROOT\']->value;?>
/*/%%SmartyNocache:1491850122593e157ad06591_52745482%%*/';?>
/user/pay/"><span class="glyphicon glyphicon-jpy"></span><?php echo '/*%%SmartyNocache:1491850122593e157ad06591_52745482%%*/<?php echo $_smarty_tpl->tpl_vars[\'mlang\']->value[\'账户充值\'];?>
/*/%%SmartyNocache:1491850122593e157ad06591_52745482%%*/';?>
</a></li>
      <li role="presentation" class="divider"></li>
      <?php $_smarty_tpl->_subTemplateRender("file:left.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 9999, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    </ul>
<?php $_smarty_tpl->_subTemplateRender("file:copyright.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 9999, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

  </div><!--/.sidebar-->
    
  <div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">   
    <div class="row">
      <ol class="breadcrumb">
        <li><span class="glyphicon glyphicon-home"></span></li>
        <li><?php echo '/*%%SmartyNocache:1491850122593e157ad06591_52745482%%*/<?php echo $_smarty_tpl->tpl_vars[\'mlang\']->value[\'客户中心\'];?>
/*/%%SmartyNocache:1491850122593e157ad06591_52745482%%*/';?>
</li>
        <li class="active"><?php echo '/*%%SmartyNocache:1491850122593e157ad06591_52745482%%*/<?php echo $_smarty_tpl->tpl_vars[\'mlang\']->value[\'控制面板\'];?>
/*/%%SmartyNocache:1491850122593e157ad06591_52745482%%*/';?>
</li>
      </ol>
    </div><!--/.row-->
    <br/>
    <div class="row">
      <div class="col-md-12">
        <?php $_smarty_tpl->_subTemplateRender("file:alert.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 9999, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

        <div class="panel panel-default">
          <div class="panel-heading"><span class="glyphicon glyphicon-edit"></span> 控制面板</div>
          <div class="panel-body">
          	<table class="table table-hover">
          		<thead>
          			<tr>
          				<th>服务ID</th>
          				<th><?php echo '/*%%SmartyNocache:1491850122593e157ad06591_52745482%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'类型\'];?>
/*/%%SmartyNocache:1491850122593e157ad06591_52745482%%*/';?>
</th>
          				<th><?php echo '/*%%SmartyNocache:1491850122593e157ad06591_52745482%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'状态\'];?>
/*/%%SmartyNocache:1491850122593e157ad06591_52745482%%*/';?>
</th>
          				<th><?php echo '/*%%SmartyNocache:1491850122593e157ad06591_52745482%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'开通时间\'];?>
/*/%%SmartyNocache:1491850122593e157ad06591_52745482%%*/';?>
</th>
          				<th><?php echo '/*%%SmartyNocache:1491850122593e157ad06591_52745482%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'到期时间\'];?>
/*/%%SmartyNocache:1491850122593e157ad06591_52745482%%*/';?>
</th>
          				<th></th>
          			</tr>
          		</thead>
          		<tbody>
          		<!-- row -->
          		<?php echo '/*%%SmartyNocache:1491850122593e157ad06591_52745482%%*/<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars[\'servers\']->value, \'server\');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars[\'server\']->value) {
?>/*/%%SmartyNocache:1491850122593e157ad06591_52745482%%*/';?>

          		<tr>
          			<td><?php echo '/*%%SmartyNocache:1491850122593e157ad06591_52745482%%*/<?php echo $_smarty_tpl->tpl_vars[\'server\']->value[\'id\'];?>
/*/%%SmartyNocache:1491850122593e157ad06591_52745482%%*/';?>
</td>
          			<td><?php echo '/*%%SmartyNocache:1491850122593e157ad06591_52745482%%*/<?php echo $_smarty_tpl->tpl_vars[\'server\']->value[\'产品类型\'];?>
/*/%%SmartyNocache:1491850122593e157ad06591_52745482%%*/';?>
</td>
          			<td><?php echo '/*%%SmartyNocache:1491850122593e157ad06591_52745482%%*/<?php if ((isset($_smarty_tpl->tpl_vars[\'server\']->value[\'状态\'])?$_smarty_tpl->tpl_vars[\'server\']->value[\'状态\']:\'\') == \'激活\') {?>/*/%%SmartyNocache:1491850122593e157ad06591_52745482%%*/';?>
<span class="label label-success"><?php echo '/*%%SmartyNocache:1491850122593e157ad06591_52745482%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'激活\'];?>
/*/%%SmartyNocache:1491850122593e157ad06591_52745482%%*/';?>
</span><?php echo '/*%%SmartyNocache:1491850122593e157ad06591_52745482%%*/<?php } elseif ((isset($_smarty_tpl->tpl_vars[\'server\']->value[\'状态\'])?$_smarty_tpl->tpl_vars[\'server\']->value[\'状态\']:\'\') == \'等待审核\') {?>/*/%%SmartyNocache:1491850122593e157ad06591_52745482%%*/';?>
<span class="label label-info"><?php echo '/*%%SmartyNocache:1491850122593e157ad06591_52745482%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'等待审核\'];?>
/*/%%SmartyNocache:1491850122593e157ad06591_52745482%%*/';?>
</span><?php echo '/*%%SmartyNocache:1491850122593e157ad06591_52745482%%*/<?php } elseif ((isset($_smarty_tpl->tpl_vars[\'server\']->value[\'状态\'])?$_smarty_tpl->tpl_vars[\'server\']->value[\'状态\']:\'\') == \'暂停\') {?>/*/%%SmartyNocache:1491850122593e157ad06591_52745482%%*/';?>
<span class="label label-warning"><?php echo '/*%%SmartyNocache:1491850122593e157ad06591_52745482%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'暂停\'];?>
/*/%%SmartyNocache:1491850122593e157ad06591_52745482%%*/';?>
</span><?php echo '/*%%SmartyNocache:1491850122593e157ad06591_52745482%%*/<?php } elseif ((isset($_smarty_tpl->tpl_vars[\'server\']->value[\'状态\'])?$_smarty_tpl->tpl_vars[\'server\']->value[\'状态\']:\'\') == \'停止\') {?>/*/%%SmartyNocache:1491850122593e157ad06591_52745482%%*/';?>
<span class="label label-warning"><?php echo '/*%%SmartyNocache:1491850122593e157ad06591_52745482%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'停止\'];?>
/*/%%SmartyNocache:1491850122593e157ad06591_52745482%%*/';?>
</span><?php echo '/*%%SmartyNocache:1491850122593e157ad06591_52745482%%*/<?php } elseif ((isset($_smarty_tpl->tpl_vars[\'server\']->value[\'状态\'])?$_smarty_tpl->tpl_vars[\'server\']->value[\'状态\']:\'\') == \'驳回\') {?>/*/%%SmartyNocache:1491850122593e157ad06591_52745482%%*/';?>
<span class="label label-warning"><?php echo '/*%%SmartyNocache:1491850122593e157ad06591_52745482%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'驳回\'];?>
/*/%%SmartyNocache:1491850122593e157ad06591_52745482%%*/';?>
</span><?php echo '/*%%SmartyNocache:1491850122593e157ad06591_52745482%%*/<?php } elseif ((isset($_smarty_tpl->tpl_vars[\'server\']->value[\'状态\'])?$_smarty_tpl->tpl_vars[\'server\']->value[\'状态\']:\'\') == \'等待付款\') {?>/*/%%SmartyNocache:1491850122593e157ad06591_52745482%%*/';?>
<span class="label"><?php echo '/*%%SmartyNocache:1491850122593e157ad06591_52745482%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'等待付款\'];?>
/*/%%SmartyNocache:1491850122593e157ad06591_52745482%%*/';?>
</span><?php echo '/*%%SmartyNocache:1491850122593e157ad06591_52745482%%*/<?php } else { ?>/*/%%SmartyNocache:1491850122593e157ad06591_52745482%%*/';?>
<span class="label label-info"><?php echo '/*%%SmartyNocache:1491850122593e157ad06591_52745482%%*/<?php echo $_smarty_tpl->tpl_vars[\'server\']->value[\'状态\'];?>
/*/%%SmartyNocache:1491850122593e157ad06591_52745482%%*/';?>
</span><?php echo '/*%%SmartyNocache:1491850122593e157ad06591_52745482%%*/<?php }?>/*/%%SmartyNocache:1491850122593e157ad06591_52745482%%*/';?>

          			</td>
          			<td><?php echo '/*%%SmartyNocache:1491850122593e157ad06591_52745482%%*/<?php echo $_smarty_tpl->tpl_vars[\'server\']->value[\'开通时间\'];?>
/*/%%SmartyNocache:1491850122593e157ad06591_52745482%%*/';?>
</td>
          			<td><?php echo '/*%%SmartyNocache:1491850122593e157ad06591_52745482%%*/<?php echo $_smarty_tpl->tpl_vars[\'server\']->value[\'到期时间\'];?>
/*/%%SmartyNocache:1491850122593e157ad06591_52745482%%*/';?>
 0:00</td>
          			<td>
                  <?php echo '/*%%SmartyNocache:1491850122593e157ad06591_52745482%%*/<?php if ((isset($_smarty_tpl->tpl_vars[\'server\']->value[\'状态\'])?$_smarty_tpl->tpl_vars[\'server\']->value[\'状态\']:\'\') != \'等待付款\') {?>/*/%%SmartyNocache:1491850122593e157ad06591_52745482%%*/';
echo '/*%%SmartyNocache:1491850122593e157ad06591_52745482%%*/<?php } else { ?>/*/%%SmartyNocache:1491850122593e157ad06591_52745482%%*/';?>
<a href="<?php echo '/*%%SmartyNocache:1491850122593e157ad06591_52745482%%*/<?php echo $_smarty_tpl->tpl_vars[\'ROOT\']->value;?>
/*/%%SmartyNocache:1491850122593e157ad06591_52745482%%*/';?>
/control/invoice/<?php echo '/*%%SmartyNocache:1491850122593e157ad06591_52745482%%*/<?php echo $_smarty_tpl->tpl_vars[\'server\']->value[\'id\'];?>
/*/%%SmartyNocache:1491850122593e157ad06591_52745482%%*/';?>
/" class="btn btn-danger">付款</a><?php echo '/*%%SmartyNocache:1491850122593e157ad06591_52745482%%*/<?php }?>/*/%%SmartyNocache:1491850122593e157ad06591_52745482%%*/';?>

                  <?php echo '/*%%SmartyNocache:1491850122593e157ad06591_52745482%%*/<?php if ((isset($_smarty_tpl->tpl_vars[\'server\']->value[\'状态\'])?$_smarty_tpl->tpl_vars[\'server\']->value[\'状态\']:\'\') != \'激活\' && (isset($_smarty_tpl->tpl_vars[\'server\']->value[\'状态\'])?$_smarty_tpl->tpl_vars[\'server\']->value[\'状态\']:\'\') != \'暂停\') {?>/*/%%SmartyNocache:1491850122593e157ad06591_52745482%%*/';?>
<button type="button" class="btn btn-default" disabled="disabled">OFF</button><?php echo '/*%%SmartyNocache:1491850122593e157ad06591_52745482%%*/<?php } else { ?>/*/%%SmartyNocache:1491850122593e157ad06591_52745482%%*/';?>
<a href="<?php echo '/*%%SmartyNocache:1491850122593e157ad06591_52745482%%*/<?php echo $_smarty_tpl->tpl_vars[\'ROOT\']->value;?>
/*/%%SmartyNocache:1491850122593e157ad06591_52745482%%*/';?>
/control/detail/<?php echo '/*%%SmartyNocache:1491850122593e157ad06591_52745482%%*/<?php echo $_smarty_tpl->tpl_vars[\'server\']->value[\'id\'];?>
/*/%%SmartyNocache:1491850122593e157ad06591_52745482%%*/';?>
/" class="btn btn-primary"><?php echo '/*%%SmartyNocache:1491850122593e157ad06591_52745482%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'管理\'];?>
/*/%%SmartyNocache:1491850122593e157ad06591_52745482%%*/';?>
</a><?php echo '/*%%SmartyNocache:1491850122593e157ad06591_52745482%%*/<?php }?>/*/%%SmartyNocache:1491850122593e157ad06591_52745482%%*/';?>

          				 </td>
          			</tr>
          			<?php echo '/*%%SmartyNocache:1491850122593e157ad06591_52745482%%*/<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>
/*/%%SmartyNocache:1491850122593e157ad06591_52745482%%*/';?>

          		</tbody>
          	</table>
          </div>
        </div>
      </div><!--/.col-->
    </div><!--/.row-->
    <?php $_smarty_tpl->_subTemplateRender("file:copyright2.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 9999, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

  </div>  <!--/.main-->
      
  <?php echo '<script'; ?>
 src="<?php echo '/*%%SmartyNocache:1491850122593e157ad06591_52745482%%*/<?php echo $_smarty_tpl->tpl_vars[\'templatedir\']->value;?>
/*/%%SmartyNocache:1491850122593e157ad06591_52745482%%*/';?>
/js/jquery-1.11.1.min.js"><?php echo '</script'; ?>
>
  <?php echo '<script'; ?>
 src="<?php echo '/*%%SmartyNocache:1491850122593e157ad06591_52745482%%*/<?php echo $_smarty_tpl->tpl_vars[\'templatedir\']->value;?>
/*/%%SmartyNocache:1491850122593e157ad06591_52745482%%*/';?>
/js/bootstrap.min.js"><?php echo '</script'; ?>
>
  <?php echo '<script'; ?>
 src="<?php echo '/*%%SmartyNocache:1491850122593e157ad06591_52745482%%*/<?php echo $_smarty_tpl->tpl_vars[\'templatedir\']->value;?>
/*/%%SmartyNocache:1491850122593e157ad06591_52745482%%*/';?>
/js/chart.min.js"><?php echo '</script'; ?>
>
  <?php echo '<script'; ?>
 src="<?php echo '/*%%SmartyNocache:1491850122593e157ad06591_52745482%%*/<?php echo $_smarty_tpl->tpl_vars[\'templatedir\']->value;?>
/*/%%SmartyNocache:1491850122593e157ad06591_52745482%%*/';?>
/js/chart-data.js"><?php echo '</script'; ?>
>
  <?php echo '<script'; ?>
 src="<?php echo '/*%%SmartyNocache:1491850122593e157ad06591_52745482%%*/<?php echo $_smarty_tpl->tpl_vars[\'templatedir\']->value;?>
/*/%%SmartyNocache:1491850122593e157ad06591_52745482%%*/';?>
/js/easypiechart.js"><?php echo '</script'; ?>
>
  <?php echo '<script'; ?>
 src="<?php echo '/*%%SmartyNocache:1491850122593e157ad06591_52745482%%*/<?php echo $_smarty_tpl->tpl_vars[\'templatedir\']->value;?>
/*/%%SmartyNocache:1491850122593e157ad06591_52745482%%*/';?>
/js/easypiechart-data.js"><?php echo '</script'; ?>
>
  <?php echo '<script'; ?>
 src="<?php echo '/*%%SmartyNocache:1491850122593e157ad06591_52745482%%*/<?php echo $_smarty_tpl->tpl_vars[\'templatedir\']->value;?>
/*/%%SmartyNocache:1491850122593e157ad06591_52745482%%*/';?>
/js/bootstrap-datepicker.js"><?php echo '</script'; ?>
>
  <?php echo '<script'; ?>
>
    $('#calendar').datepicker({
    });

    !function ($) {
        $(document).on("click","ul.nav li.parent > a > span.icon", function(){          
            $(this).find('em:first').toggleClass("glyphicon-minus");      
        }); 
        $(".sidebar span.icon").find('em:first').addClass("glyphicon-plus");
    }(window.jQuery);

    $(window).on('resize', function () {
      if ($(window).width() > 768) $('#sidebar-collapse').collapse('show')
    })
    $(window).on('resize', function () {
      if ($(window).width() <= 767) $('#sidebar-collapse').collapse('hide')
    })
  <?php echo '</script'; ?>
> 
</body>

</html>
<?php }
}
