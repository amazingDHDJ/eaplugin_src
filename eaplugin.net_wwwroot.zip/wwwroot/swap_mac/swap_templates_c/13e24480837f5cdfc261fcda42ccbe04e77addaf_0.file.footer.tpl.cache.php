<?php
/* Smarty version 3.1.30, created on 2017-06-12 11:01:01
  from "/home/ftp/s/s7234915/wwwroot/templates/XCAPP_Bootstrap3/footer.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_593e03ed656ec2_86147985',
  'has_nocache_code' => true,
  'file_dependency' => 
  array (
    '13e24480837f5cdfc261fcda42ccbe04e77addaf' => 
    array (
      0 => '/home/ftp/s/s7234915/wwwroot/templates/XCAPP_Bootstrap3/footer.tpl',
      1 => 1497236294,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_593e03ed656ec2_86147985 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->compiled->nocache_hash = '1908963363593e03ed652a94_57705565';
?>
<div class="panel-footer">
<p class="pull-right">Theme by <a href="http://www.xubw.cn">Xcraft BootStrap3</a> | Powered by <a href="http://www.swapidc.com/">SWAPIDC</a> | Execution Time:<?php echo '/*%%SmartyNocache:1908963363593e03ed652a94_57705565%%*/<?php echo $_smarty_tpl->tpl_vars[\'runtime\']->value;?>
/*/%%SmartyNocache:1908963363593e03ed652a94_57705565%%*/';?>
 S</p>
<p><?php echo '/*%%SmartyNocache:1908963363593e03ed652a94_57705565%%*/<?php echo $_smarty_tpl->tpl_vars[\'c\']->value[\'底部版权\'];?>
/*/%%SmartyNocache:1908963363593e03ed652a94_57705565%%*/';?>
 <?php echo '/*%%SmartyNocache:1908963363593e03ed652a94_57705565%%*/<?php echo $_smarty_tpl->tpl_vars[\'c\']->value[\'网站名称\'];?>
/*/%%SmartyNocache:1908963363593e03ed652a94_57705565%%*/';?>
</p></div>
</div>
  </body>
</html><?php }
}
