<?php
/* Smarty version 3.1.30, created on 2017-06-12 23:06:12
  from "/home/ftp/s/s7234915/wwwroot/templates/plugin_pay.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_593eade4b3f154_33972937',
  'has_nocache_code' => true,
  'file_dependency' => 
  array (
    '4630b45afe543489f11ad940112c046add7b6820' => 
    array (
      0 => '/home/ftp/s/s7234915/wwwroot/templates/plugin_pay.tpl',
      1 => 1497278394,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_593eade4b3f154_33972937 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->compiled->nocache_hash = '1423738575593eade4aa9655_80977456';
?>
<style>
.payment {
    margin-bottom: 20px;
}
.payment .paytype {
    padding: 30px;
    background-position: top 30px right 30px;
    background-repeat: no-repeat;
}
.payment .paytype label {
	display: block;
	margin: 0;
	padding: 0;
}
.payment .paytype label:after {
	clear: both;
	content: '';
	display: table;
}
.payment .paytype:first-child {
    border-radius: 2px 2px 0 0;
    background-color: #EAF0F0;
}
.payment .paytype:last-child {
    border-radius: 0 0 4px 4px;
    background-color: #FFF;
}
.payment .paytype input {
	float: right;
	margin-top: 15px;
}
.payment .paytype button {
	float: right;
	margin-top: 15px !important;
	margin-left: 10px;
}
.payment .paytype .paytype-text {
	float: left;
}
.payment .paytype label h5 {
    font-size: 16px;
    font-weight: bold;
    margin-top: 0;
    letter-spacing: 2px;
}
.payment .paytype label h5 small {
    width: 45px;
    background-image: url('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAewAAADQCAMAAADyO6IwAAAAY1BMVEX////1piP1piP1piP1piP1piP1piP1piP1piP1piP1piP1piP1piP1piP1piP1piP605H4vFr847v96cn5zYT++vL////4wmj2sT/72J/+9OT73q3979b3t0z1piP2rDH5yHY8sg+LAAAAEHRSTlMA8BAw0OCAIMBAkHCwUKBgYCagPwAACJBJREFUeF7s2g1ugzAUBOFnbPOTQrjBpvc/ZS9QVYowqp2d7worjWR40U6e96p/h7LPW9wqP5O6gfQ84i5nUWdQ5+mWqas6hNR+7ryqU6hbNDWrY3g0bPlS1DWUJRrJSZ1DytHEqU/D2mzN2lljQJrioilpEChx0a5h4BGXfGkg2OKCJckFIV81FJw+EUc1ijhOn4ijGP3pQubT2d94axcNCNUo4lh8Io7DJ+KY410PDQprvGmTC8aeqkaFZBRxGEUc7hFnbC6RGPvQ0GB0TgqjiMMo4jCKOIwukWB0Tgqjc1IYRRyfF/HX90u/whAR/2HvznYdR4EADGc5+9IDxpTxVvD+TzmjbqXUQe2Q9tiGiuu/jnLziTrG4hANlwwmCwDVn72DDbhorbk0YrJgLoWisZ+QEXb364O1i2ScAYARl8zAJY3JFFxSJWO/ICPsQABDQAq9+onSecG+2Rk5YXdA9Ug13V1fINhPnLADUECD3FdAKcFODPGisdML21mAO1wE+4x8sOOFTTVAgfWCPdHpiRN2vLCpHiD5HYL9gZyw44VN+Q4oqAU7cZyUAXa8sOOvoEbBThwnZYAdgLJ+YmFN7bYF+wNZYXe3dlgDRMs+lVOpOvLrVTJD2EYlCjmw35EBdmJhUyP8VoPpNOTKZMA+PbPC9tHCjlM39l+C/YWssFXKcphcPIL9jaywvQUqIHXPIBfs05EXdgtUl/yIDSjY0RBnhO2Agib1V731KNjREOeEbYAyCb9BX6EK9uuRF7a+7wVZBWBVhCrYb8gAO/2iNM7ZykWm8lLlE3lh10DZm5pOTqpMDHE22N7CYql9Yecf4qO+qiaJQV91Wac9zEyw8w9x83cwGuYm2OcjM+wO5ibYT8gLW8HcBPsFeWE7mJtgn5EZtsmGHdQlxxT7iRl2DTmw43j+Y98L8sJ2FijozFQDYVoz0TwKNftAen7sMzLDNhH+rPcy8/M2GgmMsE/PzLBryIDNdGFj0VdMp6WczYgdL2xm2O/IDHuADNhcFzZGQ5wZtoI1sXWyxhJ2pRdrG+wP5IWtYVVsyNQm2O/IC9t3c7EF+3Rkhl3BXGzB/kJe2DXMxRbsb+SFPcJcbME+HXlh+242tmB/IS9sA3OxBfsf5IWtYC62YL8eeWEH+K1hJWxzqw6ozizb2thvyAp7tEBBpXK8Lh2AcsgkOk7KCrsCCjqfA7sGSiGXaIizwvYGqBEzYDtL1p3nhf2GfLDjW+xqzIFdARWQTTTEeWGTtsEc2A1QBvlEQ5wbNvY0Q9XWlx54C9TIC/sHssMm7RFzYEc3WjPCfkV22KRdYw7sAFTneWF/sMVGhTmwnQVKIy/sZ77YmAXbAFUhqxIHxQX77rv1nP6/jatjfzLGdm57bA0UNMvOF7M69g+u2LodQG2O7btoiLPCfuOI7UJlASADtomGOC/sIzvsph2ubsHa6g1aLNogO2xkhT3UJloLm2JriIb4KtiCTWXEdhYoUNtiC/awKbYfQLBXzoUKptoUuwLBXhe67+BGfkPsFm5ia/W32Qi7Wh37CUttJOjp9HbYYeG7V8YBrrIK167Q8+K6rizc0bgZtoZFsX0L1xmH62O/YHnVcE9DqxG3wh7totg6mlm2wQ0q8rIFBalsFRwiboBN1gti+wqua/1GhxeO7Fb2oEakNsH2AyyIHWw0ojRuU5GnkjRMZvvgkVodm6yXw3Zm6wczqsj7FsbEVnQzbLJeDlvZzR/MqDJPjWfHTluDWmS/1SBuiv0u2AnrpbB9m+XBjCrzfg1z/Ve6yYYdW9t2AnvOfqvTuG1lXrpgrh+8dTbs2HpUMfb8/ZbCrSvwOhXio710LuzYGjTOxzZ5Hsxi7PK2Xwq6tkEqG/Z4PXgDLoVtA2aozHss3fg3UmrB+8bbG+/NalwKu/eYo+nLDeXceHNt3eNC2J3GPE1eWyrYASLrpbAxV1MXEgt2H1s/CnY8yAXbm9h6Etupu+oIW+X/ld0XpAQbh9h6Gltz/P3sJ6QEu4msHw37jJRgYxtZPxB2PMgFG4fI+iGwGQzyLG/QRkvWD4l9FmyKDkfV+FjY1KdgxzvjgI+GTb0JNoXegtX4uNivR8GmsOlGpB7npQr1KdiT8X9dGve2H2zBfj3uBluwD//sB1uwD1/7wRbs03E32IJ9+N4PtmAfvvaDLdin426wBfvwvR9swT587AdbsE/Pu8EW7MP7frAF+/CxH2zBPj0zxO71VDUhDTqV2w029c4Ie9nUKti2OOzVDpsKNhSHXeZh0+YBsHXh2GcspJ4cKrbYfRHY5Q/yMXLgiK2BshmxSxzkTqn68lysW2CDrZqJZ/naAmUKxT4fMUseJmrKxh7gV4P5r1Zdur43vS0LO/9h027CYSwbu4c7asrCzn/Y1MAf6xIAvV4iNxtbQTqLxWK/Hku6cbxPAqxZGltDurY8bOqzpBvHXeHYHpJZnxO7yEGuE4uiUGyEZAFzYhc5yB38ocEXj20gUY/FYec/o5SwLhW7T1jXWCg29VXC3ssqj+VjK7hV5bB47NMx897Lmj54RAbYDUxlq5qo82GXOchH/bMRqTKwtbqk8Y68/tW/7dpBasMwFAbhkeXYjlPbi+4fuf8pu+rOFBwSkPrmu8IPg5AUTYALIW/U8/vXM/4guBDyDBybe6Th2KyRhmMPt+idwJA7doqQO7Yhd2xqpOHYTJGGYzNGzwSG3LHzhNyxDblj1xJZODaP6JVGrlqiU1q4ai7RJ62QJeR6QJaQq3LdUKJDKrxiiw5p5yVf0R9tgCG34v8s5JqAJCHXzAn/KHk86/qzqcrACT+benvWdci1AKQIucrMCV9EvE85t0cXdIBr+47tkdyD+LmjRNt08DZ1jIbpVnmnqUSrtA6817xHkzTeARLMrfHgM+bpFg1R2e98UJ2WaIKWdePMD9ow7aBJAJJAAAAAAElFTkSuQmCC');
    height: 19px;
    display: inline-block;
    background-size: 100%;
    background-repeat: no-repeat;
    vertical-align: middle;
    margin-left: 20px;
}
.payment .paytype label p {
    color: #788697;
    font-size: 14px;
    font-weight: 400;
    margin-bottom: 0;
}

.input-group {
  position: relative;
  display: table;
  border-collapse: separate;
  width: 1%;
  float: right;
}
.input-group .form-control {
  border-top-right-radius: 0;
  border-bottom-right-radius: 0;
  position: relative;
  z-index: 2;
  float: left;
  width: 100%;
  margin-bottom: 0;
  display: table-cell;
}
.input-group-btn {
  width: 1%;
  white-space: nowrap;
  vertical-align: middle;
}
.input-group-btn {
  position: relative;
  font-size: 0;
  width: 1%;
  vertical-align: middle;
  display: table-cell;
}
.input-group-btn > .btn {
  position: relative;
}
.input-group-btn > .btn + .btn {
  margin-left: -1px;
}
.input-group-btn > .btn:hover,
.input-group-btn > .btn:focus,
.input-group-btn > .btn:active {
  z-index: 2;
}
.input-group-btn:first-child > .btn,
.input-group-btn:first-child > .btn-group {
  margin-right: -1px;
}
.input-group-btn:last-child > .btn,
.input-group-btn:last-child > .btn-group {
  margin-left: -1px;
}
</style>
<?php echo '/*%%SmartyNocache:1423738575593eade4aa9655_80977456%%*/<?php echo $_smarty_tpl->tpl_vars[\'css\']->value;?>
/*/%%SmartyNocache:1423738575593eade4aa9655_80977456%%*/';?>

<div class="form-group">
	<p class="small text-muted hide">请选择您的首选付款方式。</p>
	<div class="payment">
<?php echo '/*%%SmartyNocache:1423738575593eade4aa9655_80977456%%*/<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars[\'payplug\']->value, \'row\', false, \'num\');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars[\'num\']->value => $_smarty_tpl->tpl_vars[\'row\']->value) {
?>/*/%%SmartyNocache:1423738575593eade4aa9655_80977456%%*/';?>

		<div class="paytype">
			<label for="<?php echo '/*%%SmartyNocache:1423738575593eade4aa9655_80977456%%*/<?php echo $_smarty_tpl->tpl_vars[\'row\']->value[\'plug\'];?>
/*/%%SmartyNocache:1423738575593eade4aa9655_80977456%%*/';?>
">
				<div class="<?php echo '/*%%SmartyNocache:1423738575593eade4aa9655_80977456%%*/<?php echo $_smarty_tpl->tpl_vars[\'row\']->value[\'icon\'];?>
/*/%%SmartyNocache:1423738575593eade4aa9655_80977456%%*/';?>
"></div>
				<div class="paytype-text">
					<h5><?php echo '/*%%SmartyNocache:1423738575593eade4aa9655_80977456%%*/<?php echo $_smarty_tpl->tpl_vars[\'row\']->value[\'name\'];?>
/*/%%SmartyNocache:1423738575593eade4aa9655_80977456%%*/';?>
 <?php echo '/*%%SmartyNocache:1423738575593eade4aa9655_80977456%%*/<?php if (!(isset($_smarty_tpl->tpl_vars[\'num\']->value)?$_smarty_tpl->tpl_vars[\'num\']->value:\'\')) {?>/*/%%SmartyNocache:1423738575593eade4aa9655_80977456%%*/';?>
<small></small><?php echo '/*%%SmartyNocache:1423738575593eade4aa9655_80977456%%*/<?php }?>/*/%%SmartyNocache:1423738575593eade4aa9655_80977456%%*/';?>
</h5>
					<p><?php echo '/*%%SmartyNocache:1423738575593eade4aa9655_80977456%%*/<?php echo $_smarty_tpl->tpl_vars[\'row\']->value[\'text\'];?>
/*/%%SmartyNocache:1423738575593eade4aa9655_80977456%%*/';?>
</p>
				</div>
				<input type="radio" name="paymentmethod" value="<?php echo '/*%%SmartyNocache:1423738575593eade4aa9655_80977456%%*/<?php echo $_smarty_tpl->tpl_vars[\'row\']->value[\'plug\'];?>
/*/%%SmartyNocache:1423738575593eade4aa9655_80977456%%*/';?>
" class="payment-methods"<?php echo '/*%%SmartyNocache:1423738575593eade4aa9655_80977456%%*/<?php if (!(isset($_smarty_tpl->tpl_vars[\'num\']->value)?$_smarty_tpl->tpl_vars[\'num\']->value:\'\')) {?>/*/%%SmartyNocache:1423738575593eade4aa9655_80977456%%*/';?>
 checked<?php echo '/*%%SmartyNocache:1423738575593eade4aa9655_80977456%%*/<?php }?>/*/%%SmartyNocache:1423738575593eade4aa9655_80977456%%*/';?>
 id="<?php echo '/*%%SmartyNocache:1423738575593eade4aa9655_80977456%%*/<?php echo $_smarty_tpl->tpl_vars[\'row\']->value[\'plug\'];?>
/*/%%SmartyNocache:1423738575593eade4aa9655_80977456%%*/';?>
" />
			</label>
		</div>
<?php echo '/*%%SmartyNocache:1423738575593eade4aa9655_80977456%%*/<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>
/*/%%SmartyNocache:1423738575593eade4aa9655_80977456%%*/';?>

		<div class="paytype">
			<label for="pay-text">
				<div class="paytype-text">
					<h5>充值金额:</h5>
					<p>请选择你要充值的金额</p>
				</div>
				<div class="input-group" style="margin-left: 10px;">
					<input type="text" name="paymoney" value="1" class="form-control" style="width: 70px;height: 34px;" />
					<span class="input-group-btn">
						<button class="btn btn-default" onclick="payexec($('input[name=paymoney]').val());" type="button">Go!</button>
					</span>
				</div>
				<button type="button" onclick="payexec(100);" class="btn btn-default">100元</button>
				<button type="button" onclick="payexec(10);" class="btn btn-default">10元</button>
				<button type="button" onclick="payexec(5);" class="btn btn-default">5元</button>
			</label>
		</div>
	</div>
</div>
<?php echo '<script'; ?>
>
function payexec(money){
	location.href='/index.php/pay/?paymentmethod='+$('input[name=paymentmethod]:checked').val()+'&money='+money;
}
<?php echo '</script'; ?>
><?php }
}
