<?php
/* Smarty version 3.1.30, created on 2017-06-12 11:25:34
  from "/home/ftp/s/s7234915/wwwroot/templates/goule_bootstrap/top.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_593e09ae2e52d5_98367097',
  'has_nocache_code' => true,
  'file_dependency' => 
  array (
    '0123bf82fee6becdff2e52e3b9724a66be4ce279' => 
    array (
      0 => '/home/ftp/s/s7234915/wwwroot/templates/goule_bootstrap/top.tpl',
      1 => 1497237650,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_593e09ae2e52d5_98367097 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->compiled->nocache_hash = '1901330601593e09ae2d9591_94869032';
echo '/*%%SmartyNocache:1901330601593e09ae2d9591_94869032%%*/<?php if ((isset($_smarty_tpl->tpl_vars[\'s\']->value[\'是否已经登陆\'])?$_smarty_tpl->tpl_vars[\'s\']->value[\'是否已经登陆\']:\'\') == \'是\') {?>/*/%%SmartyNocache:1901330601593e09ae2d9591_94869032%%*/';?>

<ul class="user-menu">
          <li class="dropdown pull-right">
            <a href="<?php echo '/*%%SmartyNocache:1901330601593e09ae2d9591_94869032%%*/<?php echo $_smarty_tpl->tpl_vars[\'ROOT\']->value;?>
/*/%%SmartyNocache:1901330601593e09ae2d9591_94869032%%*/';?>
/user/" class="dropdown-toggle" data-toggle="dropdown"><span class="glyphicon glyphicon-user"></span>
             <?php echo '/*%%SmartyNocache:1901330601593e09ae2d9591_94869032%%*/<?php echo $_smarty_tpl->tpl_vars[\'s\']->value[\'登陆用户名\'];?>
/*/%%SmartyNocache:1901330601593e09ae2d9591_94869032%%*/';?>

             <span class="caret"></span></a>
            <ul class="dropdown-menu" role="menu">
              <li><a href="<?php echo '/*%%SmartyNocache:1901330601593e09ae2d9591_94869032%%*/<?php echo $_smarty_tpl->tpl_vars[\'ROOT\']->value;?>
/*/%%SmartyNocache:1901330601593e09ae2d9591_94869032%%*/';?>
/user/"><span class="glyphicon glyphicon-user"></span> 账户信息</a></li>
              <li><a href="<?php echo '/*%%SmartyNocache:1901330601593e09ae2d9591_94869032%%*/<?php echo $_smarty_tpl->tpl_vars[\'ROOT\']->value;?>
/*/%%SmartyNocache:1901330601593e09ae2d9591_94869032%%*/';?>
/user/password/"><span class="glyphicon glyphicon-edit"></span> 密码修改</a></li>
              <li><a href="<?php echo '/*%%SmartyNocache:1901330601593e09ae2d9591_94869032%%*/<?php echo $_smarty_tpl->tpl_vars[\'ROOT\']->value;?>
/*/%%SmartyNocache:1901330601593e09ae2d9591_94869032%%*/';?>
/index/login/"><span class="glyphicon glyphicon-remove-sign"></span> 安全退出</a></li>
            </ul>
          </li>
        </ul>
             <?php echo '/*%%SmartyNocache:1901330601593e09ae2d9591_94869032%%*/<?php } else { ?>/*/%%SmartyNocache:1901330601593e09ae2d9591_94869032%%*/';?>

<ul class="user-menu">
          <li class="dropdown pull-right">
            <a href="<?php echo '/*%%SmartyNocache:1901330601593e09ae2d9591_94869032%%*/<?php echo $_smarty_tpl->tpl_vars[\'ROOT\']->value;?>
/*/%%SmartyNocache:1901330601593e09ae2d9591_94869032%%*/';?>
/index/login/" class="dropdown-toggle" data-toggle="dropdown"><span class="glyphicon glyphicon-user"></span>
             未登录
             <span class="caret"></span></a>
            <ul class="dropdown-menu" role="menu">
              <li><a href="<?php echo '/*%%SmartyNocache:1901330601593e09ae2d9591_94869032%%*/<?php echo $_smarty_tpl->tpl_vars[\'ROOT\']->value;?>
/*/%%SmartyNocache:1901330601593e09ae2d9591_94869032%%*/';?>
/index/login/"><span class="glyphicon glyphicon-user"></span> 登陆</a></li>
              <li><a href="<?php echo '/*%%SmartyNocache:1901330601593e09ae2d9591_94869032%%*/<?php echo $_smarty_tpl->tpl_vars[\'ROOT\']->value;?>
/*/%%SmartyNocache:1901330601593e09ae2d9591_94869032%%*/';?>
/index/register/"><span class="glyphicon glyphicon-cog"></span> 注册</a></li>
            </ul>
          </li>
        </ul>
             <?php echo '/*%%SmartyNocache:1901330601593e09ae2d9591_94869032%%*/<?php }?>/*/%%SmartyNocache:1901330601593e09ae2d9591_94869032%%*/';
}
}
