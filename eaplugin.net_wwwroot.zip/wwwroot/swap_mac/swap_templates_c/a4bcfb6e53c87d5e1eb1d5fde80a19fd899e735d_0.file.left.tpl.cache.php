<?php
/* Smarty version 3.1.30, created on 2017-06-12 11:25:34
  from "/home/ftp/s/s7234915/wwwroot/templates/goule_bootstrap/left.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_593e09ae2f5172_77214865',
  'has_nocache_code' => true,
  'file_dependency' => 
  array (
    'a4bcfb6e53c87d5e1eb1d5fde80a19fd899e735d' => 
    array (
      0 => '/home/ftp/s/s7234915/wwwroot/templates/goule_bootstrap/left.tpl',
      1 => 1497237650,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_593e09ae2f5172_77214865 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->compiled->nocache_hash = '1779834786593e09ae2e9337_06067482';
echo '/*%%SmartyNocache:1779834786593e09ae2e9337_06067482%%*/<?php if ((isset($_smarty_tpl->tpl_vars[\'s\']->value[\'是否已经登陆\'])?$_smarty_tpl->tpl_vars[\'s\']->value[\'是否已经登陆\']:\'\') == \'是\') {?>/*/%%SmartyNocache:1779834786593e09ae2e9337_06067482%%*/';?>

      <li><a href="<?php echo '/*%%SmartyNocache:1779834786593e09ae2e9337_06067482%%*/<?php echo $_smarty_tpl->tpl_vars[\'ROOT\']->value;?>
/*/%%SmartyNocache:1779834786593e09ae2e9337_06067482%%*/';?>
/ticket/"><span class="glyphicon glyphicon-edit"></span> <?php echo '/*%%SmartyNocache:1779834786593e09ae2e9337_06067482%%*/<?php echo $_smarty_tpl->tpl_vars[\'mlang\']->value[\'服务单\'];?>
/*/%%SmartyNocache:1779834786593e09ae2e9337_06067482%%*/';?>
</a></li>
      <?php echo '/*%%SmartyNocache:1779834786593e09ae2e9337_06067482%%*/<?php echo $_smarty_tpl->tpl_vars[\'plug\']->value[\'用户页面列表\'];?>
/*/%%SmartyNocache:1779834786593e09ae2e9337_06067482%%*/';?>

      <?php echo '/*%%SmartyNocache:1779834786593e09ae2e9337_06067482%%*/<?php } else { ?>/*/%%SmartyNocache:1779834786593e09ae2e9337_06067482%%*/';?>

      <li><a href="<?php echo '/*%%SmartyNocache:1779834786593e09ae2e9337_06067482%%*/<?php echo $_smarty_tpl->tpl_vars[\'ROOT\']->value;?>
/*/%%SmartyNocache:1779834786593e09ae2e9337_06067482%%*/';?>
/index/login/"><span class="glyphicon glyphicon-user"></span> 登陆</a></li>
      <li><a href="<?php echo '/*%%SmartyNocache:1779834786593e09ae2e9337_06067482%%*/<?php echo $_smarty_tpl->tpl_vars[\'ROOT\']->value;?>
/*/%%SmartyNocache:1779834786593e09ae2e9337_06067482%%*/';?>
/index/register/"><span class="glyphicon glyphicon-user"></span> 注册</a></li>
      <?php echo '/*%%SmartyNocache:1779834786593e09ae2e9337_06067482%%*/<?php }?>/*/%%SmartyNocache:1779834786593e09ae2e9337_06067482%%*/';
}
}
