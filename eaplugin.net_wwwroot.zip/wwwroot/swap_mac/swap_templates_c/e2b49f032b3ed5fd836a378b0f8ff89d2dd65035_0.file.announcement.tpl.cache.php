<?php
/* Smarty version 3.1.30, created on 2017-06-12 12:57:51
  from "/home/ftp/s/s7234915/wwwroot/templates/goule_bootstrap/announcement.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_593e1f4f1a5b35_00043461',
  'has_nocache_code' => true,
  'file_dependency' => 
  array (
    'e2b49f032b3ed5fd836a378b0f8ff89d2dd65035' => 
    array (
      0 => '/home/ftp/s/s7234915/wwwroot/templates/goule_bootstrap/announcement.tpl',
      1 => 1497237650,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:top.tpl' => 1,
    'file:left.tpl' => 1,
    'file:copyright.tpl' => 1,
    'file:alert.tpl' => 1,
    'file:copyright2.tpl' => 1,
  ),
),false)) {
function content_593e1f4f1a5b35_00043461 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->compiled->nocache_hash = '861260172593e1f4f0bd2b1_98705640';
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?php echo '/*%%SmartyNocache:861260172593e1f4f0bd2b1_98705640%%*/<?php echo $_smarty_tpl->tpl_vars[\'c\']->value[\'网站名称\'];?>
/*/%%SmartyNocache:861260172593e1f4f0bd2b1_98705640%%*/';?>
 - <?php echo '/*%%SmartyNocache:861260172593e1f4f0bd2b1_98705640%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'公告信息\'];?>
/*/%%SmartyNocache:861260172593e1f4f0bd2b1_98705640%%*/';?>
</title>
<link href="<?php echo '/*%%SmartyNocache:861260172593e1f4f0bd2b1_98705640%%*/<?php echo $_smarty_tpl->tpl_vars[\'templatedir\']->value;?>
/*/%%SmartyNocache:861260172593e1f4f0bd2b1_98705640%%*/';?>
/css/bootstrap.min.css" rel="stylesheet">
<link href="<?php echo '/*%%SmartyNocache:861260172593e1f4f0bd2b1_98705640%%*/<?php echo $_smarty_tpl->tpl_vars[\'templatedir\']->value;?>
/*/%%SmartyNocache:861260172593e1f4f0bd2b1_98705640%%*/';?>
/css/datepicker3.css" rel="stylesheet">
<link href="<?php echo '/*%%SmartyNocache:861260172593e1f4f0bd2b1_98705640%%*/<?php echo $_smarty_tpl->tpl_vars[\'templatedir\']->value;?>
/*/%%SmartyNocache:861260172593e1f4f0bd2b1_98705640%%*/';?>
/css/styles.css" rel="stylesheet">

<!--[if lt IE 9]>
<?php echo '<script'; ?>
 src="<?php echo '/*%%SmartyNocache:861260172593e1f4f0bd2b1_98705640%%*/<?php echo $_smarty_tpl->tpl_vars[\'templatedir\']->value;?>
/*/%%SmartyNocache:861260172593e1f4f0bd2b1_98705640%%*/';?>
/js/html5shiv.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="<?php echo '/*%%SmartyNocache:861260172593e1f4f0bd2b1_98705640%%*/<?php echo $_smarty_tpl->tpl_vars[\'templatedir\']->value;?>
/*/%%SmartyNocache:861260172593e1f4f0bd2b1_98705640%%*/';?>
/js/respond.min.js"><?php echo '</script'; ?>
>
<![endif]-->

</head>
<body>
  <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
    <div class="container-fluid">
      <div class="navbar-header">
        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#sidebar-collapse">
          <span class="sr-only">Toggle navigation</span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
        </button>
        <a class="navbar-brand" href="/"><span><?php echo '/*%%SmartyNocache:861260172593e1f4f0bd2b1_98705640%%*/<?php echo $_smarty_tpl->tpl_vars[\'c\']->value[\'头部LOGO\'];?>
/*/%%SmartyNocache:861260172593e1f4f0bd2b1_98705640%%*/';?>
</span> <?php echo '/*%%SmartyNocache:861260172593e1f4f0bd2b1_98705640%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'公告信息\'];?>
/*/%%SmartyNocache:861260172593e1f4f0bd2b1_98705640%%*/';?>
</a>
        <?php $_smarty_tpl->_subTemplateRender("file:top.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 9999, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

      </div>
    </div><!-- /.container-fluid -->
  </nav>
    
  <div id="sidebar-collapse" class="col-sm-3 col-lg-2 sidebar">
    <form role="search">
      <div class="form-group">
        <input type="text" class="form-control" placeholder="搜索 (不可用)">
      </div>
    </form>
    <ul class="nav menu">
      <li><a href="<?php echo '/*%%SmartyNocache:861260172593e1f4f0bd2b1_98705640%%*/<?php echo $_smarty_tpl->tpl_vars[\'ROOT\']->value;?>
/*/%%SmartyNocache:861260172593e1f4f0bd2b1_98705640%%*/';?>
/index/"><span class="glyphicon glyphicon-dashboard"></span> <?php echo '/*%%SmartyNocache:861260172593e1f4f0bd2b1_98705640%%*/<?php echo $_smarty_tpl->tpl_vars[\'mlang\']->value[\'仪表盘\'];?>
/*/%%SmartyNocache:861260172593e1f4f0bd2b1_98705640%%*/';?>
</a></li>
      <li class="parent">
        <a data-toggle="collapse" href="#sub-item-1">
          <span class="glyphicon glyphicon-hdd"></span> <?php echo '/*%%SmartyNocache:861260172593e1f4f0bd2b1_98705640%%*/<?php echo $_smarty_tpl->tpl_vars[\'mlang\']->value[\'客户中心\'];?>
/*/%%SmartyNocache:861260172593e1f4f0bd2b1_98705640%%*/';?>
 <span class="icon pull-right"><em class="glyphicon glyphicon-s glyphicon-plus"></em></span> 
        </a>
        <ul class="children collapse" id="sub-item-1">
          <li>
            <a class="" href="<?php echo '/*%%SmartyNocache:861260172593e1f4f0bd2b1_98705640%%*/<?php echo $_smarty_tpl->tpl_vars[\'ROOT\']->value;?>
/*/%%SmartyNocache:861260172593e1f4f0bd2b1_98705640%%*/';?>
/buy/">
              <span class="glyphicon glyphicon-shopping-cart"></span> <?php echo '/*%%SmartyNocache:861260172593e1f4f0bd2b1_98705640%%*/<?php echo $_smarty_tpl->tpl_vars[\'mlang\']->value[\'订购产品\'];?>
/*/%%SmartyNocache:861260172593e1f4f0bd2b1_98705640%%*/';?>

            </a>
          </li>
          <li>
            <a class="" href="<?php echo '/*%%SmartyNocache:861260172593e1f4f0bd2b1_98705640%%*/<?php echo $_smarty_tpl->tpl_vars[\'ROOT\']->value;?>
/*/%%SmartyNocache:861260172593e1f4f0bd2b1_98705640%%*/';?>
/control/">
              <span class="glyphicon glyphicon-tasks"></span> <?php echo '/*%%SmartyNocache:861260172593e1f4f0bd2b1_98705640%%*/<?php echo $_smarty_tpl->tpl_vars[\'mlang\']->value[\'控制面板\'];?>
/*/%%SmartyNocache:861260172593e1f4f0bd2b1_98705640%%*/';?>
  
            </a>
          </li>
        </ul>
      </li>
      <li><a href="<?php echo '/*%%SmartyNocache:861260172593e1f4f0bd2b1_98705640%%*/<?php echo $_smarty_tpl->tpl_vars[\'ROOT\']->value;?>
/*/%%SmartyNocache:861260172593e1f4f0bd2b1_98705640%%*/';?>
/help/"><span class="glyphicon glyphicon-list-alt"></span> <?php echo '/*%%SmartyNocache:861260172593e1f4f0bd2b1_98705640%%*/<?php echo $_smarty_tpl->tpl_vars[\'mlang\']->value[\'帮助中心\'];?>
/*/%%SmartyNocache:861260172593e1f4f0bd2b1_98705640%%*/';?>
</a></li>
	  <li><a href="<?php echo '/*%%SmartyNocache:861260172593e1f4f0bd2b1_98705640%%*/<?php echo $_smarty_tpl->tpl_vars[\'ROOT\']->value;?>
/*/%%SmartyNocache:861260172593e1f4f0bd2b1_98705640%%*/';?>
/user/pay/"><span class="glyphicon glyphicon-jpy"></span><?php echo '/*%%SmartyNocache:861260172593e1f4f0bd2b1_98705640%%*/<?php echo $_smarty_tpl->tpl_vars[\'mlang\']->value[\'账户充值\'];?>
/*/%%SmartyNocache:861260172593e1f4f0bd2b1_98705640%%*/';?>
</a></li>
      <li role="presentation" class="divider"></li>
      <?php $_smarty_tpl->_subTemplateRender("file:left.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 9999, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    </ul>
<?php $_smarty_tpl->_subTemplateRender("file:copyright.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 9999, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

  </div><!--/.sidebar-->
  <div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">     
    <div class="row">
      <ol class="breadcrumb">
        <li><span class="glyphicon glyphicon-home"></span></li>
        <li>网站公告</li>
        <li class="active">内容</li>
      </ol>
    </div><!--/.row-->
    <br/>
    <div class="row">
      <div class="col-lg-12">
        <?php $_smarty_tpl->_subTemplateRender("file:alert.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 9999, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

        <div class="panel panel-default">
          <div class="panel-heading"><?php echo '/*%%SmartyNocache:861260172593e1f4f0bd2b1_98705640%%*/<?php echo $_smarty_tpl->tpl_vars[\'e\']->value[\'公告标题\'];?>
/*/%%SmartyNocache:861260172593e1f4f0bd2b1_98705640%%*/';?>
</div>
          <div class="panel-body">
            <?php echo '/*%%SmartyNocache:861260172593e1f4f0bd2b1_98705640%%*/<?php echo $_smarty_tpl->tpl_vars[\'e\']->value[\'公告内容\'];?>
/*/%%SmartyNocache:861260172593e1f4f0bd2b1_98705640%%*/';?>
<br/><br/><?php echo '/*%%SmartyNocache:861260172593e1f4f0bd2b1_98705640%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'作者\'];?>
/*/%%SmartyNocache:861260172593e1f4f0bd2b1_98705640%%*/';?>
: <?php echo '/*%%SmartyNocache:861260172593e1f4f0bd2b1_98705640%%*/<?php echo $_smarty_tpl->tpl_vars[\'e\']->value[\'公告作者\'];?>
/*/%%SmartyNocache:861260172593e1f4f0bd2b1_98705640%%*/';?>
<br/>发布<?php echo '/*%%SmartyNocache:861260172593e1f4f0bd2b1_98705640%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'时间\'];?>
/*/%%SmartyNocache:861260172593e1f4f0bd2b1_98705640%%*/';?>
: <?php echo '/*%%SmartyNocache:861260172593e1f4f0bd2b1_98705640%%*/<?php echo $_smarty_tpl->tpl_vars[\'e\']->value[\'公告时间\'];?>
/*/%%SmartyNocache:861260172593e1f4f0bd2b1_98705640%%*/';?>

          </div>
        </div>
      </div><!-- /.col-->
    </div><!-- /.row --><?php $_smarty_tpl->_subTemplateRender("file:copyright2.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 9999, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

  </div><!--/.main-->

  <?php echo '<script'; ?>
 src="<?php echo '/*%%SmartyNocache:861260172593e1f4f0bd2b1_98705640%%*/<?php echo $_smarty_tpl->tpl_vars[\'templatedir\']->value;?>
/*/%%SmartyNocache:861260172593e1f4f0bd2b1_98705640%%*/';?>
/js/jquery-1.11.1.min.js"><?php echo '</script'; ?>
>
  <?php echo '<script'; ?>
 src="<?php echo '/*%%SmartyNocache:861260172593e1f4f0bd2b1_98705640%%*/<?php echo $_smarty_tpl->tpl_vars[\'templatedir\']->value;?>
/*/%%SmartyNocache:861260172593e1f4f0bd2b1_98705640%%*/';?>
/js/bootstrap.min.js"><?php echo '</script'; ?>
>
  <?php echo '<script'; ?>
 src="<?php echo '/*%%SmartyNocache:861260172593e1f4f0bd2b1_98705640%%*/<?php echo $_smarty_tpl->tpl_vars[\'templatedir\']->value;?>
/*/%%SmartyNocache:861260172593e1f4f0bd2b1_98705640%%*/';?>
/js/chart.min.js"><?php echo '</script'; ?>
>
  <?php echo '<script'; ?>
 src="<?php echo '/*%%SmartyNocache:861260172593e1f4f0bd2b1_98705640%%*/<?php echo $_smarty_tpl->tpl_vars[\'templatedir\']->value;?>
/*/%%SmartyNocache:861260172593e1f4f0bd2b1_98705640%%*/';?>
/js/chart-data.js"><?php echo '</script'; ?>
>
  <?php echo '<script'; ?>
 src="<?php echo '/*%%SmartyNocache:861260172593e1f4f0bd2b1_98705640%%*/<?php echo $_smarty_tpl->tpl_vars[\'templatedir\']->value;?>
/*/%%SmartyNocache:861260172593e1f4f0bd2b1_98705640%%*/';?>
/js/easypiechart.js"><?php echo '</script'; ?>
>
  <?php echo '<script'; ?>
 src="<?php echo '/*%%SmartyNocache:861260172593e1f4f0bd2b1_98705640%%*/<?php echo $_smarty_tpl->tpl_vars[\'templatedir\']->value;?>
/*/%%SmartyNocache:861260172593e1f4f0bd2b1_98705640%%*/';?>
/js/easypiechart-data.js"><?php echo '</script'; ?>
>
  <?php echo '<script'; ?>
 src="<?php echo '/*%%SmartyNocache:861260172593e1f4f0bd2b1_98705640%%*/<?php echo $_smarty_tpl->tpl_vars[\'templatedir\']->value;?>
/*/%%SmartyNocache:861260172593e1f4f0bd2b1_98705640%%*/';?>
/js/bootstrap-datepicker.js"><?php echo '</script'; ?>
>
  <?php echo '<script'; ?>
>
    $('#calendar').datepicker({
    });

    !function ($) {
        $(document).on("click","ul.nav li.parent > a > span.icon", function(){          
            $(this).find('em:first').toggleClass("glyphicon-minus");      
        }); 
        $(".sidebar span.icon").find('em:first').addClass("glyphicon-plus");
    }(window.jQuery);

    $(window).on('resize', function () {
      if ($(window).width() > 768) $('#sidebar-collapse').collapse('show')
    })
    $(window).on('resize', function () {
      if ($(window).width() <= 767) $('#sidebar-collapse').collapse('hide')
    })
  <?php echo '</script'; ?>
> 
</body>

</html><?php }
}
