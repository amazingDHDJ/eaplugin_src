<?php
/* Smarty version 3.1.30, created on 2017-06-12 11:25:34
  from "/home/ftp/s/s7234915/wwwroot/templates/goule_bootstrap/copyright2.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_593e09ae32f144_74160933',
  'has_nocache_code' => true,
  'file_dependency' => 
  array (
    'a60af8d0e373165ed3304b4ae98751d8f14c4569' => 
    array (
      0 => '/home/ftp/s/s7234915/wwwroot/templates/goule_bootstrap/copyright2.tpl',
      1 => 1497237650,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_593e09ae32f144_74160933 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->compiled->nocache_hash = '974371561593e09ae32b259_58082450';
?>
<br/><br/><div class="col-lg-12">
<footer class="app-footer" role="footer">
        <div class="wrapper b-t bg-light">
    	<?php echo '/*%%SmartyNocache:974371561593e09ae32b259_58082450%%*/<?php echo $_smarty_tpl->tpl_vars[\'c\']->value[\'底部版权\'];?>
/*/%%SmartyNocache:974371561593e09ae32b259_58082450%%*/';?>
 <?php echo '/*%%SmartyNocache:974371561593e09ae32b259_58082450%%*/<?php echo $_smarty_tpl->tpl_vars[\'c\']->value[\'网站名称\'];?>
/*/%%SmartyNocache:974371561593e09ae32b259_58082450%%*/';?>
    <div class="attribution">Powered by <a href="http://www.swapidc.com/">SWAPIDC</a></div>
    </div>
  </footer>
</div><?php }
}
