<?php
/* Smarty version 3.1.30, created on 2017-06-12 11:55:46
  from "/home/ftp/s/s7234915/wwwroot/templates/goule_bootstrap/help.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_593e10c2a91d33_28452569',
  'has_nocache_code' => true,
  'file_dependency' => 
  array (
    '593df25f6d4eedc6f05f05170486e43bfb121e18' => 
    array (
      0 => '/home/ftp/s/s7234915/wwwroot/templates/goule_bootstrap/help.tpl',
      1 => 1497237650,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:top.tpl' => 1,
    'file:left.tpl' => 1,
    'file:copyright.tpl' => 1,
    'file:alert.tpl' => 1,
    'file:copyright2.tpl' => 1,
  ),
),false)) {
function content_593e10c2a91d33_28452569 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->compiled->nocache_hash = '1022144669593e10c2a1e7b2_08061596';
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?php echo '/*%%SmartyNocache:1022144669593e10c2a1e7b2_08061596%%*/<?php echo $_smarty_tpl->tpl_vars[\'c\']->value[\'网站名称\'];?>
/*/%%SmartyNocache:1022144669593e10c2a1e7b2_08061596%%*/';?>
 - <?php echo '/*%%SmartyNocache:1022144669593e10c2a1e7b2_08061596%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'帮助中心\'];?>
/*/%%SmartyNocache:1022144669593e10c2a1e7b2_08061596%%*/';?>
</title>
<link href="<?php echo '/*%%SmartyNocache:1022144669593e10c2a1e7b2_08061596%%*/<?php echo $_smarty_tpl->tpl_vars[\'templatedir\']->value;?>
/*/%%SmartyNocache:1022144669593e10c2a1e7b2_08061596%%*/';?>
/css/bootstrap.min.css" rel="stylesheet">
<link href="<?php echo '/*%%SmartyNocache:1022144669593e10c2a1e7b2_08061596%%*/<?php echo $_smarty_tpl->tpl_vars[\'templatedir\']->value;?>
/*/%%SmartyNocache:1022144669593e10c2a1e7b2_08061596%%*/';?>
/css/datepicker3.css" rel="stylesheet">
<link href="<?php echo '/*%%SmartyNocache:1022144669593e10c2a1e7b2_08061596%%*/<?php echo $_smarty_tpl->tpl_vars[\'templatedir\']->value;?>
/*/%%SmartyNocache:1022144669593e10c2a1e7b2_08061596%%*/';?>
/css/styles.css" rel="stylesheet">
<link href="<?php echo '/*%%SmartyNocache:1022144669593e10c2a1e7b2_08061596%%*/<?php echo $_smarty_tpl->tpl_vars[\'templatedir\']->value;?>
/*/%%SmartyNocache:1022144669593e10c2a1e7b2_08061596%%*/';?>
/css/main.css" rel="stylesheet">

<!--[if lt IE 9]>
<?php echo '<script'; ?>
 src="<?php echo '/*%%SmartyNocache:1022144669593e10c2a1e7b2_08061596%%*/<?php echo $_smarty_tpl->tpl_vars[\'templatedir\']->value;?>
/*/%%SmartyNocache:1022144669593e10c2a1e7b2_08061596%%*/';?>
/js/html5shiv.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="<?php echo '/*%%SmartyNocache:1022144669593e10c2a1e7b2_08061596%%*/<?php echo $_smarty_tpl->tpl_vars[\'templatedir\']->value;?>
/*/%%SmartyNocache:1022144669593e10c2a1e7b2_08061596%%*/';?>
/js/respond.min.js"><?php echo '</script'; ?>
>
<![endif]-->

</head>
<body>
  <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
    <div class="container-fluid">
      <div class="navbar-header">
        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#sidebar-collapse">
          <span class="sr-only">Toggle navigation</span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
        </button>
        <a class="navbar-brand" href="/"><span><?php echo '/*%%SmartyNocache:1022144669593e10c2a1e7b2_08061596%%*/<?php echo $_smarty_tpl->tpl_vars[\'c\']->value[\'头部LOGO\'];?>
/*/%%SmartyNocache:1022144669593e10c2a1e7b2_08061596%%*/';?>
</span> <?php echo '/*%%SmartyNocache:1022144669593e10c2a1e7b2_08061596%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'帮助中心\'];?>
/*/%%SmartyNocache:1022144669593e10c2a1e7b2_08061596%%*/';?>
</a>
        <?php $_smarty_tpl->_subTemplateRender("file:top.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 9999, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

      </div>
    </div><!-- /.container-fluid -->
  </nav>
    
  <div id="sidebar-collapse" class="col-sm-3 col-lg-2 sidebar">
    <form role="search">
      <div class="form-group">
        <input type="text" class="form-control" placeholder="搜索 (不可用)">
      </div>
    </form>
    <ul class="nav menu">
      <li><a href="<?php echo '/*%%SmartyNocache:1022144669593e10c2a1e7b2_08061596%%*/<?php echo $_smarty_tpl->tpl_vars[\'ROOT\']->value;?>
/*/%%SmartyNocache:1022144669593e10c2a1e7b2_08061596%%*/';?>
/index/"><span class="glyphicon glyphicon-dashboard"></span> <?php echo '/*%%SmartyNocache:1022144669593e10c2a1e7b2_08061596%%*/<?php echo $_smarty_tpl->tpl_vars[\'mlang\']->value[\'仪表盘\'];?>
/*/%%SmartyNocache:1022144669593e10c2a1e7b2_08061596%%*/';?>
</a></li>
      <li class="parent">
        <a data-toggle="collapse" href="#sub-item-1">
          <span class="glyphicon glyphicon-hdd"></span> <?php echo '/*%%SmartyNocache:1022144669593e10c2a1e7b2_08061596%%*/<?php echo $_smarty_tpl->tpl_vars[\'mlang\']->value[\'客户中心\'];?>
/*/%%SmartyNocache:1022144669593e10c2a1e7b2_08061596%%*/';?>
 <span class="icon pull-right"><em class="glyphicon glyphicon-s glyphicon-plus"></em></span> 
        </a>
        <ul class="children collapse" id="sub-item-1">
          <li>
            <a href="<?php echo '/*%%SmartyNocache:1022144669593e10c2a1e7b2_08061596%%*/<?php echo $_smarty_tpl->tpl_vars[\'ROOT\']->value;?>
/*/%%SmartyNocache:1022144669593e10c2a1e7b2_08061596%%*/';?>
/buy/">
              <span class="glyphicon glyphicon-shopping-cart"></span> <?php echo '/*%%SmartyNocache:1022144669593e10c2a1e7b2_08061596%%*/<?php echo $_smarty_tpl->tpl_vars[\'mlang\']->value[\'订购产品\'];?>
/*/%%SmartyNocache:1022144669593e10c2a1e7b2_08061596%%*/';?>

            </a>
          </li>
          <li>
            <a href="<?php echo '/*%%SmartyNocache:1022144669593e10c2a1e7b2_08061596%%*/<?php echo $_smarty_tpl->tpl_vars[\'ROOT\']->value;?>
/*/%%SmartyNocache:1022144669593e10c2a1e7b2_08061596%%*/';?>
/control/">
              <span class="glyphicon glyphicon-tasks"></span> <?php echo '/*%%SmartyNocache:1022144669593e10c2a1e7b2_08061596%%*/<?php echo $_smarty_tpl->tpl_vars[\'mlang\']->value[\'控制面板\'];?>
/*/%%SmartyNocache:1022144669593e10c2a1e7b2_08061596%%*/';?>
  
            </a>
          </li>
        </ul>
      </li>
      <li class="active"><a href="<?php echo '/*%%SmartyNocache:1022144669593e10c2a1e7b2_08061596%%*/<?php echo $_smarty_tpl->tpl_vars[\'ROOT\']->value;?>
/*/%%SmartyNocache:1022144669593e10c2a1e7b2_08061596%%*/';?>
/help/"><span class="glyphicon glyphicon-list-alt"></span> <?php echo '/*%%SmartyNocache:1022144669593e10c2a1e7b2_08061596%%*/<?php echo $_smarty_tpl->tpl_vars[\'mlang\']->value[\'帮助中心\'];?>
/*/%%SmartyNocache:1022144669593e10c2a1e7b2_08061596%%*/';?>
</a></li>
      <li><a href="<?php echo '/*%%SmartyNocache:1022144669593e10c2a1e7b2_08061596%%*/<?php echo $_smarty_tpl->tpl_vars[\'ROOT\']->value;?>
/*/%%SmartyNocache:1022144669593e10c2a1e7b2_08061596%%*/';?>
/user/pay/"><span class="glyphicon glyphicon-jpy"></span><?php echo '/*%%SmartyNocache:1022144669593e10c2a1e7b2_08061596%%*/<?php echo $_smarty_tpl->tpl_vars[\'mlang\']->value[\'账户充值\'];?>
/*/%%SmartyNocache:1022144669593e10c2a1e7b2_08061596%%*/';?>
</a></li>
      <li role="presentation" class="divider"></li>
      <?php $_smarty_tpl->_subTemplateRender("file:left.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 9999, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    </ul>
<?php $_smarty_tpl->_subTemplateRender("file:copyright.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 9999, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

  </div><!--/.sidebar-->
    
  <div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">     
    <div class="row">
      <ol class="breadcrumb">
        <li><span class="glyphicon glyphicon-home"></span></li>
        <li class="active"><?php echo '/*%%SmartyNocache:1022144669593e10c2a1e7b2_08061596%%*/<?php echo $_smarty_tpl->tpl_vars[\'mlang\']->value[\'帮助中心\'];?>
/*/%%SmartyNocache:1022144669593e10c2a1e7b2_08061596%%*/';?>
</li>
      </ol>
    </div><!--/.row-->
    <br/>
    <div class="row">
      <div class="col-md-12">
        <?php $_smarty_tpl->_subTemplateRender("file:alert.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 9999, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

        <?php echo '/*%%SmartyNocache:1022144669593e10c2a1e7b2_08061596%%*/<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars[\'helps\']->value, \'help\');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars[\'help\']->value) {
?>/*/%%SmartyNocache:1022144669593e10c2a1e7b2_08061596%%*/';?>

        <div class="panel panel-default">
          <div class="panel-heading"><?php echo '/*%%SmartyNocache:1022144669593e10c2a1e7b2_08061596%%*/<?php echo $_smarty_tpl->tpl_vars[\'help\']->value[\'标题\'];?>
/*/%%SmartyNocache:1022144669593e10c2a1e7b2_08061596%%*/';?>
</div>
          <div class="panel-body">
            <p><?php echo '/*%%SmartyNocache:1022144669593e10c2a1e7b2_08061596%%*/<?php echo $_smarty_tpl->tpl_vars[\'help\']->value[\'内容\'];?>
/*/%%SmartyNocache:1022144669593e10c2a1e7b2_08061596%%*/';?>
</p>
          </div>
        </div>
        <?php echo '/*%%SmartyNocache:1022144669593e10c2a1e7b2_08061596%%*/<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>
/*/%%SmartyNocache:1022144669593e10c2a1e7b2_08061596%%*/';?>

        <center>
              <?php echo '/*%%SmartyNocache:1022144669593e10c2a1e7b2_08061596%%*/<?php if ((isset($_smarty_tpl->tpl_vars[\'t\']->value[\'当前页数\'])?$_smarty_tpl->tpl_vars[\'t\']->value[\'当前页数\']:\'\') == \'1\') {?>/*/%%SmartyNocache:1022144669593e10c2a1e7b2_08061596%%*/';?>
<a class="btn btn-link" href="<?php echo '/*%%SmartyNocache:1022144669593e10c2a1e7b2_08061596%%*/<?php echo $_smarty_tpl->tpl_vars[\'t\']->value[\'上一页连接\'];?>
/*/%%SmartyNocache:1022144669593e10c2a1e7b2_08061596%%*/';?>
" disabled="disabled"><?php echo '/*%%SmartyNocache:1022144669593e10c2a1e7b2_08061596%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'上一页\'];?>
/*/%%SmartyNocache:1022144669593e10c2a1e7b2_08061596%%*/';?>
</a><?php echo '/*%%SmartyNocache:1022144669593e10c2a1e7b2_08061596%%*/<?php } else { ?>/*/%%SmartyNocache:1022144669593e10c2a1e7b2_08061596%%*/';?>
<a class="btn btn-link" href="<?php echo '/*%%SmartyNocache:1022144669593e10c2a1e7b2_08061596%%*/<?php echo $_smarty_tpl->tpl_vars[\'t\']->value[\'上一页连接\'];?>
/*/%%SmartyNocache:1022144669593e10c2a1e7b2_08061596%%*/';?>
"><?php echo '/*%%SmartyNocache:1022144669593e10c2a1e7b2_08061596%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'上一页\'];?>
/*/%%SmartyNocache:1022144669593e10c2a1e7b2_08061596%%*/';?>
</a><?php echo '/*%%SmartyNocache:1022144669593e10c2a1e7b2_08061596%%*/<?php }?>/*/%%SmartyNocache:1022144669593e10c2a1e7b2_08061596%%*/';?>

              <?php echo '/*%%SmartyNocache:1022144669593e10c2a1e7b2_08061596%%*/<?php echo $_smarty_tpl->tpl_vars[\'t\']->value[\'当前页数\'];?>
/*/%%SmartyNocache:1022144669593e10c2a1e7b2_08061596%%*/';?>
/<?php echo '/*%%SmartyNocache:1022144669593e10c2a1e7b2_08061596%%*/<?php echo $_smarty_tpl->tpl_vars[\'t\']->value[\'总页数\'];?>
/*/%%SmartyNocache:1022144669593e10c2a1e7b2_08061596%%*/';?>

              <?php echo '/*%%SmartyNocache:1022144669593e10c2a1e7b2_08061596%%*/<?php if ((isset($_smarty_tpl->tpl_vars[\'t\']->value[\'当前页数\'])?$_smarty_tpl->tpl_vars[\'t\']->value[\'当前页数\']:\'\') == (isset($_smarty_tpl->tpl_vars[\'t\']->value[\'总页数\'])?$_smarty_tpl->tpl_vars[\'t\']->value[\'总页数\']:\'\')) {?>/*/%%SmartyNocache:1022144669593e10c2a1e7b2_08061596%%*/';?>
<a class="btn btn-link" href="<?php echo '/*%%SmartyNocache:1022144669593e10c2a1e7b2_08061596%%*/<?php echo $_smarty_tpl->tpl_vars[\'t\']->value[\'下一页连接\'];?>
/*/%%SmartyNocache:1022144669593e10c2a1e7b2_08061596%%*/';?>
" disabled="disabled"><?php echo '/*%%SmartyNocache:1022144669593e10c2a1e7b2_08061596%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'下一页\'];?>
/*/%%SmartyNocache:1022144669593e10c2a1e7b2_08061596%%*/';?>
</a><?php echo '/*%%SmartyNocache:1022144669593e10c2a1e7b2_08061596%%*/<?php } else { ?>/*/%%SmartyNocache:1022144669593e10c2a1e7b2_08061596%%*/';?>
<a class="btn btn-link" href="<?php echo '/*%%SmartyNocache:1022144669593e10c2a1e7b2_08061596%%*/<?php echo $_smarty_tpl->tpl_vars[\'t\']->value[\'下一页连接\'];?>
/*/%%SmartyNocache:1022144669593e10c2a1e7b2_08061596%%*/';?>
"><?php echo '/*%%SmartyNocache:1022144669593e10c2a1e7b2_08061596%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'下一页\'];?>
/*/%%SmartyNocache:1022144669593e10c2a1e7b2_08061596%%*/';?>
</a><?php echo '/*%%SmartyNocache:1022144669593e10c2a1e7b2_08061596%%*/<?php }?>/*/%%SmartyNocache:1022144669593e10c2a1e7b2_08061596%%*/';?>
</center>
      </div><!--/.col-->

    </div><!--/.row-->  
    <?php $_smarty_tpl->_subTemplateRender("file:copyright2.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 9999, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

  </div><!--/.main-->

  <?php echo '<script'; ?>
 src="<?php echo '/*%%SmartyNocache:1022144669593e10c2a1e7b2_08061596%%*/<?php echo $_smarty_tpl->tpl_vars[\'templatedir\']->value;?>
/*/%%SmartyNocache:1022144669593e10c2a1e7b2_08061596%%*/';?>
/js/jquery-1.11.1.min.js"><?php echo '</script'; ?>
>
  <?php echo '<script'; ?>
 src="<?php echo '/*%%SmartyNocache:1022144669593e10c2a1e7b2_08061596%%*/<?php echo $_smarty_tpl->tpl_vars[\'templatedir\']->value;?>
/*/%%SmartyNocache:1022144669593e10c2a1e7b2_08061596%%*/';?>
/js/bootstrap.min.js"><?php echo '</script'; ?>
>
  <?php echo '<script'; ?>
 src="<?php echo '/*%%SmartyNocache:1022144669593e10c2a1e7b2_08061596%%*/<?php echo $_smarty_tpl->tpl_vars[\'templatedir\']->value;?>
/*/%%SmartyNocache:1022144669593e10c2a1e7b2_08061596%%*/';?>
/js/chart.min.js"><?php echo '</script'; ?>
>
  <?php echo '<script'; ?>
 src="<?php echo '/*%%SmartyNocache:1022144669593e10c2a1e7b2_08061596%%*/<?php echo $_smarty_tpl->tpl_vars[\'templatedir\']->value;?>
/*/%%SmartyNocache:1022144669593e10c2a1e7b2_08061596%%*/';?>
/js/chart-data.js"><?php echo '</script'; ?>
>
  <?php echo '<script'; ?>
 src="<?php echo '/*%%SmartyNocache:1022144669593e10c2a1e7b2_08061596%%*/<?php echo $_smarty_tpl->tpl_vars[\'templatedir\']->value;?>
/*/%%SmartyNocache:1022144669593e10c2a1e7b2_08061596%%*/';?>
/js/easypiechart.js"><?php echo '</script'; ?>
>
  <?php echo '<script'; ?>
 src="<?php echo '/*%%SmartyNocache:1022144669593e10c2a1e7b2_08061596%%*/<?php echo $_smarty_tpl->tpl_vars[\'templatedir\']->value;?>
/*/%%SmartyNocache:1022144669593e10c2a1e7b2_08061596%%*/';?>
/js/easypiechart-data.js"><?php echo '</script'; ?>
>
  <?php echo '<script'; ?>
 src="<?php echo '/*%%SmartyNocache:1022144669593e10c2a1e7b2_08061596%%*/<?php echo $_smarty_tpl->tpl_vars[\'templatedir\']->value;?>
/*/%%SmartyNocache:1022144669593e10c2a1e7b2_08061596%%*/';?>
/js/bootstrap-datepicker.js"><?php echo '</script'; ?>
>
  <?php echo '<script'; ?>
>
    !function ($) {
      $(document).on("click","ul.nav li.parent > a > span.icon", function(){      
        $(this).find('em:first').toggleClass("glyphicon-minus");    
      }); 
      $(".sidebar span.icon").find('em:first').addClass("glyphicon-plus");
    }(window.jQuery);

    $(window).on('resize', function () {
      if ($(window).width() > 768) $('#sidebar-collapse').collapse('show')
    })
    $(window).on('resize', function () {
      if ($(window).width() <= 767) $('#sidebar-collapse').collapse('hide')
    })
  <?php echo '</script'; ?>
> 
</body>

</html>
<?php }
}
