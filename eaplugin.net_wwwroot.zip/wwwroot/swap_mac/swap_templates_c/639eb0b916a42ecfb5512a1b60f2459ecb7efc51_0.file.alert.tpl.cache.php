<?php
/* Smarty version 3.1.30, created on 2017-06-12 10:51:40
  from "/home/ftp/s/s7234915/wwwroot/templates/default/alert.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_593e01bc8acff6_51195021',
  'has_nocache_code' => true,
  'file_dependency' => 
  array (
    '639eb0b916a42ecfb5512a1b60f2459ecb7efc51' => 
    array (
      0 => '/home/ftp/s/s7234915/wwwroot/templates/default/alert.tpl',
      1 => 1497278394,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_593e01bc8acff6_51195021 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->compiled->nocache_hash = '346473232593e01bc8973f1_52644779';
echo '/*%%SmartyNocache:346473232593e01bc8973f1_52644779%%*/<?php if ((isset($_smarty_tpl->tpl_vars[\'alert\']->value[\'warning\'])?$_smarty_tpl->tpl_vars[\'alert\']->value[\'warning\']:\'\') != \'\') {?>/*/%%SmartyNocache:346473232593e01bc8973f1_52644779%%*/';?>

<div class="alert alert-warning">
  <button type="button" data-dismiss="alert" class="close">&times;</button><strong><?php echo '/*%%SmartyNocache:346473232593e01bc8973f1_52644779%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'警告\'];?>
/*/%%SmartyNocache:346473232593e01bc8973f1_52644779%%*/';?>
: </strong><?php echo '/*%%SmartyNocache:346473232593e01bc8973f1_52644779%%*/<?php echo $_smarty_tpl->tpl_vars[\'alert\']->value[\'warning\'];?>
/*/%%SmartyNocache:346473232593e01bc8973f1_52644779%%*/';?>

</div>
<?php echo '/*%%SmartyNocache:346473232593e01bc8973f1_52644779%%*/<?php }?>/*/%%SmartyNocache:346473232593e01bc8973f1_52644779%%*/';?>

<?php echo '/*%%SmartyNocache:346473232593e01bc8973f1_52644779%%*/<?php if ((isset($_smarty_tpl->tpl_vars[\'alert\']->value[\'error\'])?$_smarty_tpl->tpl_vars[\'alert\']->value[\'error\']:\'\') != \'\') {?>/*/%%SmartyNocache:346473232593e01bc8973f1_52644779%%*/';?>

<div class="alert alert-error">
  <button type="button" data-dismiss="alert" class="close">&times;</button><strong><?php echo '/*%%SmartyNocache:346473232593e01bc8973f1_52644779%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'错误\'];?>
/*/%%SmartyNocache:346473232593e01bc8973f1_52644779%%*/';?>
: </strong><?php echo '/*%%SmartyNocache:346473232593e01bc8973f1_52644779%%*/<?php echo $_smarty_tpl->tpl_vars[\'alert\']->value[\'error\'];?>
/*/%%SmartyNocache:346473232593e01bc8973f1_52644779%%*/';?>

</div>
<?php echo '/*%%SmartyNocache:346473232593e01bc8973f1_52644779%%*/<?php }?>/*/%%SmartyNocache:346473232593e01bc8973f1_52644779%%*/';?>

<?php echo '/*%%SmartyNocache:346473232593e01bc8973f1_52644779%%*/<?php if ((isset($_smarty_tpl->tpl_vars[\'alert\']->value[\'success\'])?$_smarty_tpl->tpl_vars[\'alert\']->value[\'success\']:\'\') != \'\') {?>/*/%%SmartyNocache:346473232593e01bc8973f1_52644779%%*/';?>

<div class="alert alert-success">
  <button type="button" data-dismiss="alert" class="close">&times;</button><strong><?php echo '/*%%SmartyNocache:346473232593e01bc8973f1_52644779%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'成功\'];?>
/*/%%SmartyNocache:346473232593e01bc8973f1_52644779%%*/';?>
: </strong><?php echo '/*%%SmartyNocache:346473232593e01bc8973f1_52644779%%*/<?php echo $_smarty_tpl->tpl_vars[\'alert\']->value[\'success\'];?>
/*/%%SmartyNocache:346473232593e01bc8973f1_52644779%%*/';?>

</div>
<?php echo '/*%%SmartyNocache:346473232593e01bc8973f1_52644779%%*/<?php }?>/*/%%SmartyNocache:346473232593e01bc8973f1_52644779%%*/';?>

<?php echo '/*%%SmartyNocache:346473232593e01bc8973f1_52644779%%*/<?php if ((isset($_smarty_tpl->tpl_vars[\'alert\']->value[\'info\'])?$_smarty_tpl->tpl_vars[\'alert\']->value[\'info\']:\'\') != \'\') {?>/*/%%SmartyNocache:346473232593e01bc8973f1_52644779%%*/';?>

<div class="alert alert-info">
  <button type="button" data-dismiss="alert" class="close">&times;</button><strong><?php echo '/*%%SmartyNocache:346473232593e01bc8973f1_52644779%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'信息\'];?>
/*/%%SmartyNocache:346473232593e01bc8973f1_52644779%%*/';?>
: </strong><?php echo '/*%%SmartyNocache:346473232593e01bc8973f1_52644779%%*/<?php echo $_smarty_tpl->tpl_vars[\'alert\']->value[\'info\'];?>
/*/%%SmartyNocache:346473232593e01bc8973f1_52644779%%*/';?>

</div>
<?php echo '/*%%SmartyNocache:346473232593e01bc8973f1_52644779%%*/<?php }?>/*/%%SmartyNocache:346473232593e01bc8973f1_52644779%%*/';
}
}
