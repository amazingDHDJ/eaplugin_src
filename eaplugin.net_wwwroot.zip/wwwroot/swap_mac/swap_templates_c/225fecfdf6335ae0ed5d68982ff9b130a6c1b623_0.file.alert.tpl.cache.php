<?php
/* Smarty version 3.1.30, created on 2017-06-12 11:01:01
  from "/home/ftp/s/s7234915/wwwroot/templates/XCAPP_Bootstrap3/alert.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_593e03ed64e765_42461334',
  'has_nocache_code' => true,
  'file_dependency' => 
  array (
    '225fecfdf6335ae0ed5d68982ff9b130a6c1b623' => 
    array (
      0 => '/home/ftp/s/s7234915/wwwroot/templates/XCAPP_Bootstrap3/alert.tpl',
      1 => 1497236294,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_593e03ed64e765_42461334 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->compiled->nocache_hash = '639083986593e03ed638fc1_23321092';
echo '/*%%SmartyNocache:639083986593e03ed638fc1_23321092%%*/<?php if ((isset($_smarty_tpl->tpl_vars[\'alert\']->value[\'warning\'])?$_smarty_tpl->tpl_vars[\'alert\']->value[\'warning\']:\'\') != \'\') {?>/*/%%SmartyNocache:639083986593e03ed638fc1_23321092%%*/';?>

<div class="alert alert-warning" role="alert">
  <button type="button" data-dismiss="alert" class="close">&times;</button><strong><?php echo '/*%%SmartyNocache:639083986593e03ed638fc1_23321092%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'警告\'];?>
/*/%%SmartyNocache:639083986593e03ed638fc1_23321092%%*/';?>
: </strong><?php echo '/*%%SmartyNocache:639083986593e03ed638fc1_23321092%%*/<?php echo $_smarty_tpl->tpl_vars[\'alert\']->value[\'warning\'];?>
/*/%%SmartyNocache:639083986593e03ed638fc1_23321092%%*/';?>

</div>
<?php echo '/*%%SmartyNocache:639083986593e03ed638fc1_23321092%%*/<?php }?>/*/%%SmartyNocache:639083986593e03ed638fc1_23321092%%*/';?>

<?php echo '/*%%SmartyNocache:639083986593e03ed638fc1_23321092%%*/<?php if ((isset($_smarty_tpl->tpl_vars[\'alert\']->value[\'error\'])?$_smarty_tpl->tpl_vars[\'alert\']->value[\'error\']:\'\') != \'\') {?>/*/%%SmartyNocache:639083986593e03ed638fc1_23321092%%*/';?>

<div class="alert alert-error" role="alert">
  <button type="button" data-dismiss="alert" class="close">&times;</button><strong><?php echo '/*%%SmartyNocache:639083986593e03ed638fc1_23321092%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'错误\'];?>
/*/%%SmartyNocache:639083986593e03ed638fc1_23321092%%*/';?>
: </strong><?php echo '/*%%SmartyNocache:639083986593e03ed638fc1_23321092%%*/<?php echo $_smarty_tpl->tpl_vars[\'alert\']->value[\'error\'];?>
/*/%%SmartyNocache:639083986593e03ed638fc1_23321092%%*/';?>

</div>
<?php echo '/*%%SmartyNocache:639083986593e03ed638fc1_23321092%%*/<?php }?>/*/%%SmartyNocache:639083986593e03ed638fc1_23321092%%*/';?>

<?php echo '/*%%SmartyNocache:639083986593e03ed638fc1_23321092%%*/<?php if ((isset($_smarty_tpl->tpl_vars[\'alert\']->value[\'success\'])?$_smarty_tpl->tpl_vars[\'alert\']->value[\'success\']:\'\') != \'\') {?>/*/%%SmartyNocache:639083986593e03ed638fc1_23321092%%*/';?>

<div class="alert alert-success" role="alert">
  <button type="button" data-dismiss="alert" class="close">&times;</button><strong><?php echo '/*%%SmartyNocache:639083986593e03ed638fc1_23321092%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'成功\'];?>
/*/%%SmartyNocache:639083986593e03ed638fc1_23321092%%*/';?>
: </strong><?php echo '/*%%SmartyNocache:639083986593e03ed638fc1_23321092%%*/<?php echo $_smarty_tpl->tpl_vars[\'alert\']->value[\'success\'];?>
/*/%%SmartyNocache:639083986593e03ed638fc1_23321092%%*/';?>

</div>
<?php echo '/*%%SmartyNocache:639083986593e03ed638fc1_23321092%%*/<?php }?>/*/%%SmartyNocache:639083986593e03ed638fc1_23321092%%*/';?>

<?php echo '/*%%SmartyNocache:639083986593e03ed638fc1_23321092%%*/<?php if ((isset($_smarty_tpl->tpl_vars[\'alert\']->value[\'info\'])?$_smarty_tpl->tpl_vars[\'alert\']->value[\'info\']:\'\') != \'\') {?>/*/%%SmartyNocache:639083986593e03ed638fc1_23321092%%*/';?>

<div class="alert alert-info" role="alert">
  <button type="button" data-dismiss="alert" class="close">&times;</button><strong><?php echo '/*%%SmartyNocache:639083986593e03ed638fc1_23321092%%*/<?php echo $_smarty_tpl->tpl_vars[\'lang\']->value[\'信息\'];?>
/*/%%SmartyNocache:639083986593e03ed638fc1_23321092%%*/';?>
: </strong><?php echo '/*%%SmartyNocache:639083986593e03ed638fc1_23321092%%*/<?php echo $_smarty_tpl->tpl_vars[\'alert\']->value[\'info\'];?>
/*/%%SmartyNocache:639083986593e03ed638fc1_23321092%%*/';?>

</div>
<?php echo '/*%%SmartyNocache:639083986593e03ed638fc1_23321092%%*/<?php }?>/*/%%SmartyNocache:639083986593e03ed638fc1_23321092%%*/';
}
}
