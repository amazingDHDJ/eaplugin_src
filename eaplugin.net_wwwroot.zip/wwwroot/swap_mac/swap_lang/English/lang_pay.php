<?php
defined('SWAP_ROOT') or die('非法操作');
$lang['login']['需要登陆提示']='Please login to view other service!';
$lang['error']['您的账户已经被禁止登入']='Your account has been banned Login';
$lang['error']['没有指定支付模块']='No payment module specified';
$lang['error']['充值金额错误']='Incorrect recharge amount';
$lang['error']['支付模块不存在']='The payment module does not exist';
$lang['index']['返回用户中心']='Return to the User Center';
?>