<?php
/* Smarty version 3.1.30, created on 2017-06-03 15:38:30
  from "/home/ftp/s/s2644661/wwwroot/templates/servereast/cart.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_59326776120ef8_92102972',
  'has_nocache_code' => true,
  'file_dependency' => 
  array (
    'fefc747124715eb82ccb2df193ad6832588dd079' => 
    array (
      0 => '/home/ftp/s/s2644661/wwwroot/templates/servereast/cart.tpl',
      1 => 1492673322,
      2 => 'file',
    ),
    'f7867801f9ff470333487eb8267a51a976b8319c' => 
    array (
      0 => '/home/ftp/s/s2644661/wwwroot/templates/servereast/alert.tpl',
      1 => 1492673322,
      2 => 'file',
    ),
    '163c6ae1971be814db3119f5b2170a0ff1adc282' => 
    array (
      0 => '/home/ftp/s/s2644661/wwwroot/templates/servereast/footer.tpl',
      1 => 1492673322,
      2 => 'file',
    ),
  ),
  'cache_lifetime' => 120,
),true)) {
function content_59326776120ef8_92102972 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender("file:header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array('navxz'=>'2','title'=>$_smarty_tpl->tpl_vars['lang']->value['购物车'],'hostname'=>$_smarty_tpl->tpl_vars['c']->value['网站名称']), 0, false);
?>
<style type="text/css">
/*tip message start*/
.tip_message,.tip_message .tip_ico_succ,.tip_message .tip_ico_fail,.tip_message .tip_ico_hits,.tip_message .tip_content,.tip_message .tip_end{ background-image:url(<?php echo $_smarty_tpl->tpl_vars['templatedir']->value;?>
/js/tip_message.png);_background-image:url(<?php echo $_smarty_tpl->tpl_vars['templatedir']->value;?>
/js/tip_message_ie6.png);color:#606060;float:left;font-size:14px;font-weight:bold;height:54px;line-height:54px;}
.tip_message{ display:none;background:none;position:absolute;font-family:Arial,Simsun,"Arial Unicode MS",Mingliu,Helvetica;font-size:14px;}
.tip_message .tip_ico_succ
{ background-position:-6px 0;background-repeat:no-repeat;width:45px;}
.tip_message .tip_ico_fail{ background-position:-6px -108px;background-repeat:no-repeat;width:45px;}
.tip_message .tip_ico_hits{ background-position:-6px -54px;background-repeat:no-repeat;width:45px;}
.tip_message .tip_end{ background-position:0 0;background-repeat:no-repeat;width:6px;}
.tip_content{ background-position:0 -161px;background-repeat:repeat-x;padding:0 20px 0 8px; word-break:keep-all;white-space:nowrap;}
.tip_message .tip_message_content{ position:absolute; left:0; top:0; width:100%;height:100%;z-index:65530;}
.ie6_mask{ position:absolute; left:0; top:0; width:100%;height:100%;background-color:transparent;z-index:-1;filter:alpha(opacity=0);}
/* tip message end */
</style>
<?php if ((isset($_smarty_tpl->tpl_vars['alert']->value['warning'])?$_smarty_tpl->tpl_vars['alert']->value['warning']:'') != '') {?>
<script type="text/javascript">
$.tipMessage('<strong><?php echo $_smarty_tpl->tpl_vars['lang']->value["警告"];?>
: </strong><?php echo $_smarty_tpl->tpl_vars['alert']->value["warning"];?>
',2 , 5000);
</script>
<?php }
if ((isset($_smarty_tpl->tpl_vars['alert']->value['error'])?$_smarty_tpl->tpl_vars['alert']->value['error']:'') != '') {?>
<script type="text/javascript">
$.tipMessage('<strong><?php echo $_smarty_tpl->tpl_vars['lang']->value["错误"];?>
: </strong><?php echo $_smarty_tpl->tpl_vars['alert']->value["error"];?>
', 2, 5000);
</script>
<?php }
if ((isset($_smarty_tpl->tpl_vars['alert']->value['success'])?$_smarty_tpl->tpl_vars['alert']->value['success']:'') != '') {?>
<script type="text/javascript">
$.tipMessage('<strong><?php echo $_smarty_tpl->tpl_vars['lang']->value["成功"];?>
: </strong><?php echo $_smarty_tpl->tpl_vars['alert']->value["success"];?>
',3 , 5000);
</script>
<?php }
if ((isset($_smarty_tpl->tpl_vars['alert']->value['info'])?$_smarty_tpl->tpl_vars['alert']->value['info']:'') != '') {?>
<script type="text/javascript">
$.tipMessage(' <strong><?php echo $_smarty_tpl->tpl_vars['lang']->value["信息"];?>
: </strong><?php echo $_smarty_tpl->tpl_vars['alert']->value["info"];?>
', 1, 5000);
</script>
<?php }?>
  <!-- Breadcrumps -->
  <div class="breadcrumbs">
    <div class="row">
      <div class="col-sm-6">
        <h1><?php echo $_smarty_tpl->tpl_vars['lang']->value['购物车'];?>
</h1>
      </div>
    </div>
  </div>

<style type="text/css">
ul.display-list {
padding: 0;
margin: 0;
list-style: none;
}
ul.display-list li {
font-size: 16px;
font-weight: 300;
padding: 7px 0;
border-bottom: 1px solid #F0F1F5;
margin-bottom: 2px;
}
</style>
  <!-- End of Breadcrumps -->
	

	<section class="elements">
<div class="servers-table" >
    <div class="row">
      <div class="col-sm-12">

<form method="post" action="submit/">

	  <br>
	  <br>
        <table  class="products-table responsive wow fadeInUp tablesaw tablesaw-stack">

		
			 <thead>
	   <tr><th style="width:160px;border: 1px solid #dddddd;"><?php echo $_smarty_tpl->tpl_vars['mlang']->value['产品名称'];?>
:</th><td><?php echo $_smarty_tpl->tpl_vars['cart']->value['名称'];?>
</td></tr>
<tr><th style="border: 1px solid #dddddd;"><?php echo $_smarty_tpl->tpl_vars['mlang']->value['产品库存'];?>
:</th><td><?php echo $_smarty_tpl->tpl_vars['lang']->value['剩余'];?>
 <?php echo $_smarty_tpl->tpl_vars['cart']->value['库存'];?>
 <?php echo $_smarty_tpl->tpl_vars['lang']->value['个'];?>
</td></tr>
<tr><th style="border: 1px solid #dddddd;"><?php echo $_smarty_tpl->tpl_vars['mlang']->value['产品价格'];?>
:</th><td><?php if ((isset($_smarty_tpl->tpl_vars['cart']->value['价格'])?$_smarty_tpl->tpl_vars['cart']->value['价格']:'') == '免费') {
echo $_smarty_tpl->tpl_vars['lang']->value[$_smarty_tpl->tpl_vars['cart']->value['价格']];
} else {
echo $_smarty_tpl->tpl_vars['cart']->value['价格'];?>
 <?php echo $_smarty_tpl->tpl_vars['c']->value['交易币名称'];
}?></td></tr>
<tr><th style="border: 1px solid #dddddd;"><?php echo $_smarty_tpl->tpl_vars['mlang']->value['开通方式'];?>
:</th><td><?php echo $_smarty_tpl->tpl_vars['lang']->value[$_smarty_tpl->tpl_vars['cart']->value['开通方式']];?>
</td></tr>
<tr><th style="border: 1px solid #dddddd;"><?php echo $_smarty_tpl->tpl_vars['mlang']->value['产品描述'];?>
:</th><td><ul style="list-style-type:none;color:#000000;"><?php echo $_smarty_tpl->tpl_vars['cart']->value['描述'];?>
</ul></td></tr>
	  
	  </thead>
        </table>
		<br>
		<br>
 <?php if ((isset($_smarty_tpl->tpl_vars['cart']->value['隐藏域名配置'])?$_smarty_tpl->tpl_vars['cart']->value['隐藏域名配置']:'') != '1') {?> 
 
<?php if ((isset($_smarty_tpl->tpl_vars['cart']->value['关闭自主域名'])?$_smarty_tpl->tpl_vars['cart']->value['关闭自主域名']:'') == 'yes') {?>
<input type="hidden" name="domainoption" value="freedomain" id="seldomain" />
 <div class="accordion-example"><div id="example-tabs">
<div id="tab1" style="display:block;"><p><div id="freedomain" align="center">www. <input type="text" name="freedomain" size="40" value=""/> .<select name="freedomainhz" style="width:150px;"><?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['freedomains']->value, 'freedomain');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['freedomain']->value) {
?><option value="<?php echo $_smarty_tpl->tpl_vars['freedomain']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['freedomain']->value;?>
</option><?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>
</select></div> </p></div>
                    </div>
                </div>

<?php } else { ?><input type="hidden" name="domainoption" value="domain" id="seldomain" /> 
 
                <div class="accordion-example">
                    <div id="example-tabs">
                        <ul>
							<li><a href="#tab1"  onclick="document.getElementById('seldomain').value='domain';"><?php echo $_smarty_tpl->tpl_vars['lang']->value['我已经有一个域名,我将把已有域名解析到此空间'];?>
 </a>
                            </li><?php if ((isset($_smarty_tpl->tpl_vars['cart']->value['显示域名选项'])?$_smarty_tpl->tpl_vars['cart']->value['显示域名选项']:'') == '开') {?>
                            <li><a href="#tab2"  onclick="document.getElementById('seldomain').value='freedomain';"><?php echo $_smarty_tpl->tpl_vars['lang']->value['您选择的产品/服务需要域名，请将域名填写在下面'];?>
</a>
                            </li><?php }?>
                           
                        
                        </ul>

                        <!-- 1st tab  -->
                        <div id="tab1">

                            <p><div id="domain" align="center">www.
				<input type="text" name="domain" size="40" value="" style="width:276px;"  onclick="document.getElementById('seldomain').value='domain';"/>
				.
				<input type="text" name="domainhz" size="7" value="" style="width:80px;"  onclick="document.getElementById('seldomain').value='domain';"/>
				</div> </p>

                        </div>
<?php if ((isset($_smarty_tpl->tpl_vars['cart']->value['显示域名选项'])?$_smarty_tpl->tpl_vars['cart']->value['显示域名选项']:'') == '开') {?><div id="tab2"><p><div id="freedomain" align="center">www. <input type="text" name="freedomain" size="40" value=""   onclick="document.getElementById('seldomain').value='freedomain';"/> .<select name="freedomainhz" style="width:150px;"><?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['freedomains']->value, 'freedomain');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['freedomain']->value) {
?><option value="<?php echo $_smarty_tpl->tpl_vars['freedomain']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['freedomain']->value;?>
</option><?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>
</select></div> </p></div><?php }?>
                    </div>
                </div>
				<?php }
}?>




<div class="spacing-20"></div>

<div class="row">
<div class="col-sm-7 center-block">
<ul class="display-list">
<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['buyoptions']->value, 'option');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['option']->value) {
?>
	<?php if ((isset($_smarty_tpl->tpl_vars['option']->value['Type'])?$_smarty_tpl->tpl_vars['option']->value['Type']:'') == 'yesno') {?>
		<li><?php echo $_smarty_tpl->tpl_vars['option']->value['Name'];?>
 : <input name="buyoptions[<?php echo $_smarty_tpl->tpl_vars['option']->value['Name'];?>
]" type="radio" value="on" /><?php echo $_smarty_tpl->tpl_vars['mlang']->value['开'];?>
 <input name="buyoptions[<?php echo $_smarty_tpl->tpl_vars['option']->value['Name'];?>
]" type="radio" value="0" checked /><?php echo $_smarty_tpl->tpl_vars['mlang']->value['关'];?>
</li>
	<?php } elseif ((isset($_smarty_tpl->tpl_vars['option']->value['Type'])?$_smarty_tpl->tpl_vars['option']->value['Type']:'') == 'text') {?>
		<li><?php echo $_smarty_tpl->tpl_vars['option']->value['Name'];?>
 : <input type="text" name="buyoptions[<?php echo $_smarty_tpl->tpl_vars['option']->value['Name'];?>
]" size="<?php echo $_smarty_tpl->tpl_vars['option']->value['Size'];?>
"></li>
	<?php } elseif ((isset($_smarty_tpl->tpl_vars['option']->value['Type'])?$_smarty_tpl->tpl_vars['option']->value['Type']:'') == 'dropdown') {?>
		<li><?php echo $_smarty_tpl->tpl_vars['option']->value['Name'];?>
 :<select name="buyoptions[<?php echo $_smarty_tpl->tpl_vars['option']->value['Name'];?>
]"><?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['option']->value['Options'], 'optsub');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['optsub']->value) {
?><option value="<?php echo $_smarty_tpl->tpl_vars['optsub']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['optsub']->value;?>
</option><?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>

				</select> </li>
	<?php }
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>

<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['options']->value, 'option');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['option']->value) {
?>
	<li><?php echo $_smarty_tpl->tpl_vars['option']->value['名称'];?>
 :<select name="config[<?php echo $_smarty_tpl->tpl_vars['option']->value['id'];?>
]"><?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['option']->value['选项'], 'optsub');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['optsub']->value) {
?><option value="<?php echo $_smarty_tpl->tpl_vars['optsub']->value['id'];?>
"><?php echo $_smarty_tpl->tpl_vars['optsub']->value['名称'];?>
</option><?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>
</select></li>
<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>

</ul>
</div>
</div>

<div class="spacing-20"></div>

<div class="row">
<div class="col-sm-7 center-block">
<ul class="display-list">
<li><?php echo $_smarty_tpl->tpl_vars['lang']->value['优惠码'];?>
: <input class="choosecat" type="text" name="promocode"  id="promocode" /><a class="btn btn-primary" id="validatepromo"><?php echo $_smarty_tpl->tpl_vars['lang']->value['验证 >>'];?>
</a></li>

<li><?php echo $_smarty_tpl->tpl_vars['lang']->value['购买时间'];?>
: <?php if (is_array((isset($_smarty_tpl->tpl_vars['cart']->value['周期'])?$_smarty_tpl->tpl_vars['cart']->value['周期']:''))) {?>
					<select name="cycleid" class="choosecat">
						<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['cart']->value['周期'], 'row', false, 'num');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['num']->value => $_smarty_tpl->tpl_vars['row']->value) {
?>
							<option value="<?php echo $_smarty_tpl->tpl_vars['num']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['row']->value['名称'];?>
 <?php echo $_smarty_tpl->tpl_vars['row']->value['价格'];
echo $_smarty_tpl->tpl_vars['c']->value['交易币名称'];?>
/<?php echo $_smarty_tpl->tpl_vars['row']->value['时间'];?>
天 <?php if ((isset($_smarty_tpl->tpl_vars['row']->value['自动'])?$_smarty_tpl->tpl_vars['row']->value['自动']:'')) {
echo $_smarty_tpl->tpl_vars['lang']->value['自动开通'];
} else {
echo $_smarty_tpl->tpl_vars['lang']->value['审核开通'];
}?></option>
						<?php
}
} else {
?>

							无法购买
						<?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>

					</select>
<?php } else { ?>
					<?php if ((isset($_smarty_tpl->tpl_vars['cart']->value['周期'])?$_smarty_tpl->tpl_vars['cart']->value['周期']:'') != '一次性') {?><input type="text" name="days" id="days" value="1" /> /<?php }
if ((isset($_smarty_tpl->tpl_vars['cart']->value['价格'])?$_smarty_tpl->tpl_vars['cart']->value['价格']:'') == '免费') {
echo $_smarty_tpl->tpl_vars['lang']->value['免费'];
} else {
echo $_smarty_tpl->tpl_vars['cart']->value['价格'];?>
 <?php echo $_smarty_tpl->tpl_vars['c']->value['交易币名称'];
}
echo $_smarty_tpl->tpl_vars['lang']->value[$_smarty_tpl->tpl_vars['cart']->value['周期']];?>
 <?php echo $_smarty_tpl->tpl_vars['lang']->value[$_smarty_tpl->tpl_vars['cart']->value['开通方式']];?>

<?php }?></li>


<li><?php echo $_smarty_tpl->tpl_vars['lang']->value['预存款'];?>
: <b><?php echo $_smarty_tpl->tpl_vars['s']->value['登陆预存款'];?>
 <?php echo $_smarty_tpl->tpl_vars['c']->value['交易币名称'];?>
</b></li>
<li><?php echo $_smarty_tpl->tpl_vars['lang']->value['总计'];?>
: <b><a id="payall"><?php if ((isset($_smarty_tpl->tpl_vars['cart']->value['价格'])?$_smarty_tpl->tpl_vars['cart']->value['价格']:'') == '免费') {?>0<?php } else {
echo $_smarty_tpl->tpl_vars['cart']->value['价格'];
}?></a> <?php echo $_smarty_tpl->tpl_vars['c']->value['交易币名称'];?>
</b></li>
<li><?php echo $_smarty_tpl->tpl_vars['lang']->value['备注/额外信息'];?>
: <textarea name="notes" rows="2" style="width:100%;height:100px" onFocus="if(this.value=='<?php echo $_smarty_tpl->tpl_vars['lang']->value['您可以输入任何您想包含在订单中的额外注释或信息……'];?>
'){ this.value=''; }" onBlur="if (this.value==''){ this.value='<?php echo $_smarty_tpl->tpl_vars['lang']->value['您可以输入任何您想包含在订单中的额外注释或信息……'];?>
'; }"><?php echo $_smarty_tpl->tpl_vars['lang']->value['您可以输入任何您想包含在订单中的额外注释或信息……'];?>
</textarea></a></li>
</ul>
</div>
</div>
<script language="javascript" type="text/javascript">

$("#validatepromo").click(function () {
$("#validatepromo").attr('class','btn  btn-default');
$("#validatepromo").html('<?php echo $_smarty_tpl->tpl_vars['lang']->value['请稍后……'];?>
');
$.ajax({
type:　"post",
url:　"/index.php/buy/promo/",
data:　"swap="+$("#promocode").val(),
success:　function (msg){
if(msg==='ok'){
$("#validatepromo").html('<?php echo $_smarty_tpl->tpl_vars['lang']->value['优惠码有效'];?>
');
$("#validatepromo").attr('class','btn  btn-default');
}else{
$("#validatepromo").html(msg);
$("#validatepromo").attr('class','btn  btn-primary');
}
},
error:　function (mag){
$("#validatepromo").html('<?php echo $_smarty_tpl->tpl_vars['lang']->value['网络错误,重试'];?>
');
$("#validatepromo").attr('class','btn  btn-primary');
},
});
});
</script>
<div class="spacing-20"></div>
<p align="center"><input type="submit" class="btn btn-success" value="<?php echo $_smarty_tpl->tpl_vars['lang']->value['确认订单并且完成订购'];?>
" onclick="this.value='<?php echo $_smarty_tpl->tpl_vars['lang']->value['请稍后……'];?>
'"></p>

</div>
		</div>	
</form>    
  </div>
</section>

 <script src="<?php echo $_smarty_tpl->tpl_vars['templatedir']->value;?>
/js/jquery.responsiveTabs.js"></script>
<script>
    // ______________ TABS
    $('#example-tabs').responsiveTabs({
        startCollapsed: 'accordion'
    });


    </script>
    <!--  Footer -->

    <section class="footer">
        <div class="row">
            <div class="col-sm-3">
                <h4><?php echo $_smarty_tpl->tpl_vars['mlang']->value['快速导航'];?>
</h4>
                <ul>
                    <li><a href="<?php echo $_smarty_tpl->tpl_vars['ROOT']->value;?>
/control/index/"> <?php echo $_smarty_tpl->tpl_vars['mlang']->value['我的订单'];?>
</a></li>
                    <li><a href="<?php echo $_smarty_tpl->tpl_vars['ROOT']->value;?>
/ticket/submit/"> <?php echo $_smarty_tpl->tpl_vars['mlang']->value['提交服务单'];?>
</a></li>
                    <li><a href="<?php echo $_smarty_tpl->tpl_vars['ROOT']->value;?>
/networkissues/serverstatus/"><?php echo $_smarty_tpl->tpl_vars['mlang']->value['服务器状态'];?>
</a></li>
                    <li><a href="<?php echo $_smarty_tpl->tpl_vars['ROOT']->value;?>
/networkissues/index/"> <?php echo $_smarty_tpl->tpl_vars['mlang']->value['网络故障'];?>
</a></li>
                </ul>
            </div>
            <div class="col-sm-3">
               <?php echo $_smarty_tpl->tpl_vars['tempsz']->value['底部第2列'];?>

            </div>
            <div class="col-sm-3">
			<?php echo $_smarty_tpl->tpl_vars['tempsz']->value['底部第3列'];?>

                
            </div>
            <div class="col-sm-3">
                <h4><?php echo $_smarty_tpl->tpl_vars['mlang']->value['联系我们'];?>
</h4>
                <ul class="questions">
			
                   
                    <li><i class="fa fa-phone"></i> <?php echo $_smarty_tpl->tpl_vars['tempsz']->value['联系电话'];?>
</li>
                    <li><i class="fa fa-envelope"></i> <?php echo $_smarty_tpl->tpl_vars['tempsz']->value['邮箱'];?>
</li> <li>
					<i class="fa fa-comment"></i> <?php echo $_smarty_tpl->tpl_vars['tempsz']->value['QQ'];?>
</li>
                   <!--  <li>	
                    </li> -->
                </ul>
            </div>
        </div>

    </section>
	  <div class="social">
        <div class="row">

            <span style="float:left;">
            <?php echo $_smarty_tpl->tpl_vars['c']->value['底部版权'];?>
 <?php echo $_smarty_tpl->tpl_vars['c']->value['网站名称'];?>
  Theme by XH ServerEast | Powered by <a href="http://www.swapidc.cn/">SWAPIDC</a>


			 
             
            </span>
            <span style="float:right;">
			<form method="post" name="languagefrm" id="languagefrom"><select name="language" onchange="languagefrom.submit()">
			  <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['l']->value, 'langs');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['langs']->value) {
?>
			  <option value="<?php echo $_smarty_tpl->tpl_vars['langs']->value;?>
"<?php if ((isset($_smarty_tpl->tpl_vars['langs']->value)?$_smarty_tpl->tpl_vars['langs']->value:'') == (isset($_smarty_tpl->tpl_vars['language']->value)?$_smarty_tpl->tpl_vars['language']->value:'')) {?> selected="selected"<?php }?>><?php echo $_smarty_tpl->tpl_vars['langs']->value;?>
</option>
			  <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>

			</select>
		</form>
            </span>
        </div>
    </div>
    <!--  End of Footer -->
<a href="#top" id="back-to-top"><i class="fa fa-angle-up"></i></a>


    <script src="<?php echo $_smarty_tpl->tpl_vars['templatedir']->value;?>
/js/hoverIntent.js"></script>
    <script src="<?php echo $_smarty_tpl->tpl_vars['templatedir']->value;?>
/js/superfish.min.js"></script>
    <script src="<?php echo $_smarty_tpl->tpl_vars['templatedir']->value;?>
/js/owl.carousel.js"></script>
    <script src="<?php echo $_smarty_tpl->tpl_vars['templatedir']->value;?>
/js/wow.min.js"></script>
    <script src="<?php echo $_smarty_tpl->tpl_vars['templatedir']->value;?>
/js/jquery.circliful.min.js"></script>
    <script src="<?php echo $_smarty_tpl->tpl_vars['templatedir']->value;?>
/js/waypoints.min.js"></script>
    <script src="<?php echo $_smarty_tpl->tpl_vars['templatedir']->value;?>
/js/jquery.slicknav.min.js"></script>
    <script src="<?php echo $_smarty_tpl->tpl_vars['templatedir']->value;?>
/js/retina.min.js"></script>
    <script src="<?php echo $_smarty_tpl->tpl_vars['templatedir']->value;?>
/js/custom.js"></script>

    <script>
    /* Home Page Slider
   ========================================================================== */
    $(document).ready(function() {


    var sync1 = $("#mainslider");
    var sync2 = $("#mainslider-nav");

    sync1.owlCarousel({
    singleItem : true,
    slideSpeed : 1000,
    paginationSpeed: 800,
    navigation: false,
    pagination:false,
    autoPlay:7500,
    afterAction : syncPosition,
    responsiveRefreshRate : 200,
    });

    sync2.owlCarousel({
    items : 4,
    itemsDesktop : [1199,4],
    itemsDesktopSmall : [979,4],
    itemsTablet : [768,4],
    itemsMobile : [479,2],
    pagination:false,
    responsiveRefreshRate : 100,
    afterInit : function(el){
    el.find(".owl-item").eq(0).addClass("synced");
    }
    });

    function syncPosition(el){
    var current = this.currentItem;
    $("#mainslider-nav")
    .find(".owl-item")
    .removeClass("synced")
    .eq(current)
    .addClass("synced")
    if($("#mainslider-nav").data("owlCarousel") !== undefined){
    center(current)
    }
    }

    $("#mainslider-nav").on("click", ".owl-item", function(e){
    e.preventDefault();
    var number = $(this).data("owlItem");
    sync1.trigger("owl.goTo",number);
    });

    function center(number){
    var sync2visible = sync2.data("owlCarousel").owl.visibleItems;
    var num = number;
    var found = false;
    for(var i in sync2visible){
    if(num === sync2visible[i]){
    var found = true;
    }
    }

    if(found===false){
    if(num>sync2visible[sync2visible.length-1]){
    sync2.trigger("owl.goTo", num - sync2visible.length+2)
    }else{
    if(num - 1 === -1){
    num = 0;
    }
    sync2.trigger("owl.goTo", num);
    }
    } else if(num === sync2visible[sync2visible.length-1]){
    sync2.trigger("owl.goTo", sync2visible[1])
    } else if(num === sync2visible[0]){
    sync2.trigger("owl.goTo", num-1)
    }
    }

    });

/* Τestimonials
   ========================================================================== */
 $(document).ready(function() {
        $("#testimonials-carousel").owlCarousel({
            items: 1,
            autoPlay: 5000,
            itemsDesktop: [1199, 1],
            itemsDesktopSmall: [979, 1],
            itemsTablet: [768, 1]
        });
    });

    // ______________ STATS
jQuery(document).ready(function() {
$('.statistics').waypoint(function() {

 $('#myStat1').circliful();
 $('#myStat2').circliful();
 $('#myStat3').circliful();
 $('#myStat4').circliful();

}, { offset: 800, triggerOnce: true });
});

    </script>
</body>

</html><?php }
}
