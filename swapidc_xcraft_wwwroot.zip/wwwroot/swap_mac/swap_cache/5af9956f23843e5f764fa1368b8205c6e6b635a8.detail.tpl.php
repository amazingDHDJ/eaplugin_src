<?php
/* Smarty version 3.1.30, created on 2017-05-22 21:21:20
  from "/home/ftp/s/s2644661/wwwroot/templates/servereast/detail.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_5922e5d0758e54_70875153',
  'has_nocache_code' => true,
  'file_dependency' => 
  array (
    '41121968c1e5eed1612de9d5daa7f2b1963f06dc' => 
    array (
      0 => '/home/ftp/s/s2644661/wwwroot/templates/servereast/detail.tpl',
      1 => 1492673322,
      2 => 'file',
    ),
    'f7867801f9ff470333487eb8267a51a976b8319c' => 
    array (
      0 => '/home/ftp/s/s2644661/wwwroot/templates/servereast/alert.tpl',
      1 => 1492673322,
      2 => 'file',
    ),
    '163c6ae1971be814db3119f5b2170a0ff1adc282' => 
    array (
      0 => '/home/ftp/s/s2644661/wwwroot/templates/servereast/footer.tpl',
      1 => 1492673322,
      2 => 'file',
    ),
  ),
  'cache_lifetime' => 120,
),true)) {
function content_5922e5d0758e54_70875153 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender("file:header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array('navxz'=>'5','title'=>$_smarty_tpl->tpl_vars['lang']->value['详细管理'],'hostname'=>$_smarty_tpl->tpl_vars['c']->value['网站名称']), 0, false);
?>
<style type="text/css">
/*tip message start*/
.tip_message,.tip_message .tip_ico_succ,.tip_message .tip_ico_fail,.tip_message .tip_ico_hits,.tip_message .tip_content,.tip_message .tip_end{ background-image:url(<?php echo $_smarty_tpl->tpl_vars['templatedir']->value;?>
/js/tip_message.png);_background-image:url(<?php echo $_smarty_tpl->tpl_vars['templatedir']->value;?>
/js/tip_message_ie6.png);color:#606060;float:left;font-size:14px;font-weight:bold;height:54px;line-height:54px;}
.tip_message{ display:none;background:none;position:absolute;font-family:Arial,Simsun,"Arial Unicode MS",Mingliu,Helvetica;font-size:14px;}
.tip_message .tip_ico_succ
{ background-position:-6px 0;background-repeat:no-repeat;width:45px;}
.tip_message .tip_ico_fail{ background-position:-6px -108px;background-repeat:no-repeat;width:45px;}
.tip_message .tip_ico_hits{ background-position:-6px -54px;background-repeat:no-repeat;width:45px;}
.tip_message .tip_end{ background-position:0 0;background-repeat:no-repeat;width:6px;}
.tip_content{ background-position:0 -161px;background-repeat:repeat-x;padding:0 20px 0 8px; word-break:keep-all;white-space:nowrap;}
.tip_message .tip_message_content{ position:absolute; left:0; top:0; width:100%;height:100%;z-index:65530;}
.ie6_mask{ position:absolute; left:0; top:0; width:100%;height:100%;background-color:transparent;z-index:-1;filter:alpha(opacity=0);}
/* tip message end */
</style>
<?php if ((isset($_smarty_tpl->tpl_vars['alert']->value['warning'])?$_smarty_tpl->tpl_vars['alert']->value['warning']:'') != '') {?>
<script type="text/javascript">
$.tipMessage('<strong><?php echo $_smarty_tpl->tpl_vars['lang']->value["警告"];?>
: </strong><?php echo $_smarty_tpl->tpl_vars['alert']->value["warning"];?>
',2 , 5000);
</script>
<?php }
if ((isset($_smarty_tpl->tpl_vars['alert']->value['error'])?$_smarty_tpl->tpl_vars['alert']->value['error']:'') != '') {?>
<script type="text/javascript">
$.tipMessage('<strong><?php echo $_smarty_tpl->tpl_vars['lang']->value["错误"];?>
: </strong><?php echo $_smarty_tpl->tpl_vars['alert']->value["error"];?>
', 2, 5000);
</script>
<?php }
if ((isset($_smarty_tpl->tpl_vars['alert']->value['success'])?$_smarty_tpl->tpl_vars['alert']->value['success']:'') != '') {?>
<script type="text/javascript">
$.tipMessage('<strong><?php echo $_smarty_tpl->tpl_vars['lang']->value["成功"];?>
: </strong><?php echo $_smarty_tpl->tpl_vars['alert']->value["success"];?>
',3 , 5000);
</script>
<?php }
if ((isset($_smarty_tpl->tpl_vars['alert']->value['info'])?$_smarty_tpl->tpl_vars['alert']->value['info']:'') != '') {?>
<script type="text/javascript">
$.tipMessage(' <strong><?php echo $_smarty_tpl->tpl_vars['lang']->value["信息"];?>
: </strong><?php echo $_smarty_tpl->tpl_vars['alert']->value["info"];?>
', 1, 5000);
</script>
<?php }?>
  <!-- Breadcrumps -->
  <div class="breadcrumbs">
    <div class="row">
      <div class="col-sm-6">
        <h1><?php echo $_smarty_tpl->tpl_vars['lang']->value['详细管理'];?>
</h1>
      </div>
    </div>
  </div>
  <!-- End of Breadcrumps -->
	<section class="elements">
<!-- <div class="servers-table"> -->
    <div class="row">
      <div class="col-sm-12">
<style type="text/css">	
cpkzmbxq h1, cpkzmbxq h2, cpkzmbxq h3, cpkzmbxq h4, cpkzmbxq h5, cpkzmbxq h6{ color:#FFF} .stats{  text-align:center}.stats .stat{  background-color:#eee;color:#555;padding:10px;border-radius:6px;margin-bottom:20px;text-align:center}.stats .stat h2{ font-weight:600}.stats .stat h6{ margin-top:-10px}.stats .warning{ background-color:#ffa93c;color:#FFF}.stats .success{ background-color:#4cb158;color:#FFF}.stats .danger{ background-color:#ea494a;color:#FFF}.stats .info{ background-color:#14b8d4;color:#FFF}.stats .primary{ background-color:#007ccd;color:#FFF}.stats .purple{ background-color:#7932ea;color:#FFF}.stats .inverse{ background-color:#333;color:#FFF} 
</style>	  

<script language="javascript" type="text/javascript">
    ;(function($) {
        $(function() {
            $('#anpass').bind('click', function(e) {
                if(confirm("<?php echo $_smarty_tpl->tpl_vars['mlang']->value['重置密码提示'];?>
")){
				$('#formrepass').submit();
				}
            });
        });
		/**<?php if ((isset($_smarty_tpl->tpl_vars['goods']->value['允许用户自己停止'])?$_smarty_tpl->tpl_vars['goods']->value['允许用户自己停止']:'')) {?>**/
        $(function() {
            $('#anstop').bind('click', function(e) {
                if(confirm("<?php echo $_smarty_tpl->tpl_vars['lang']->value['如果您的产品出现问题,或者不想使用服务了,可以选择停止产品并取消服务,但是这个操作不能逆转,并且将不返还任何预存款!!'];?>
")){
				$('#formrestop').submit();
				}
            });
        });/**<?php }?>**/

	})(jQuery);
	
	

</script>

<form action="repass/" id="formrepass" method="post"></form>  		  
<?php if ((isset($_smarty_tpl->tpl_vars['goods']->value['允许用户自己停止'])?$_smarty_tpl->tpl_vars['goods']->value['允许用户自己停止']:'')) {?><form action="stop/" id="formrestop" method="post"></form><?php }?>
 
 
<?php if ((isset($_smarty_tpl->tpl_vars['goods']->value['开启升级选项'])?$_smarty_tpl->tpl_vars['goods']->value['开启升级选项']:'') && (isset($_smarty_tpl->tpl_vars['server']->value['周期'])?$_smarty_tpl->tpl_vars['server']->value['周期']:'') != '一次性') {?><a href="<?php echo $_smarty_tpl->tpl_vars['ROOT']->value;?>
/control/package/<?php echo $_smarty_tpl->tpl_vars['server']->value['id'];?>
/" class="btn btn-primary"><?php echo $_smarty_tpl->tpl_vars['lang']->value['升级/降级产品'];?>
</a>
<?php }?>


<?php if ((isset($_smarty_tpl->tpl_vars['goods']->value['允许用户自己停止'])?$_smarty_tpl->tpl_vars['goods']->value['允许用户自己停止']:'')) {?><input type="submit"  class="btn btn-primary" id="anstop" value="<?php echo $_smarty_tpl->tpl_vars['lang']->value['停止/取消服务'];?>
"><?php }?>

<input type="submit"  class="btn btn-primary" value="<?php echo $_smarty_tpl->tpl_vars['lang']->value['重置产品密码'];?>
"  id="anpass">

	<div class="btn-group">
	  <button data-toggle="dropdown" class="btn dropdown-toggle" style="background: #4B77BE;color: #FFF;"><?php echo $_smarty_tpl->tpl_vars['lang']->value['前往控制面板'];?>
  <a class="caret"></a></button>
	  <ul class="dropdown-menu">
<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['logins']->value, 'login');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['login']->value) {
?>
	    <li style=""><?php echo $_smarty_tpl->tpl_vars['login']->value;?>
</li>
<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>

	  </ul>
	</div>
<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['barray']->value, 'bfunction', false, 'bname');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['bname']->value => $_smarty_tpl->tpl_vars['bfunction']->value) {
?>
	<a href="action/<?php echo $_smarty_tpl->tpl_vars['bfunction']->value;?>
/" class="btn"><?php echo $_smarty_tpl->tpl_vars['bname']->value;?>
</a>
<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>

	  <br><cpkzmbxq>
	  <?php echo $_smarty_tpl->tpl_vars['plug']->value['产品控制面板详情'];?>
</cpkzmbxq>
        <table  class="products-table responsive wow fadeInUp tablesaw tablesaw-stack" data-mode="stack">

		
			 <thead>
<?php if ((isset($_smarty_tpl->tpl_vars['goods']->value['隐藏域名配置'])?$_smarty_tpl->tpl_vars['goods']->value['隐藏域名配置']:'') != '1') {?>
	    <tr>
	      <th width="250"><?php echo $_smarty_tpl->tpl_vars['lang']->value['主域名(服务名)'];?>
</th>
	      <td><?php echo $_smarty_tpl->tpl_vars['server']->value['域名'];?>
</td>
	    </tr>
<?php }
if ((isset($_smarty_tpl->tpl_vars['server']->value['密码'])?$_smarty_tpl->tpl_vars['server']->value['密码']:'') != '') {?>
	    <tr>
	      <th><?php echo $_smarty_tpl->tpl_vars['lang']->value['产品登录信息'];?>
<br>
	      </th>
	      <td>
	      	<?php echo $_smarty_tpl->tpl_vars['lang']->value['用户名'];?>
：<?php echo $_smarty_tpl->tpl_vars['server']->value['用户名'];?>
<br>
	      	<?php echo $_smarty_tpl->tpl_vars['lang']->value['密码'];?>
：<?php echo $_smarty_tpl->tpl_vars['server']->value['密码'];?>

	      </td>
	    </tr>
<?php }?>
	    <tr>
	      <th><?php echo $_smarty_tpl->tpl_vars['lang']->value['产品名称'];?>
</th>
	      <td>
	      	<?php echo $_smarty_tpl->tpl_vars['goods']->value['名称'];?>

	      </td>
	    </tr>
<?php if ((isset($_smarty_tpl->tpl_vars['server']->value['ip地址'])?$_smarty_tpl->tpl_vars['server']->value['ip地址']:'') != '') {?>
		<tr>
	      <th><?php echo $_smarty_tpl->tpl_vars['lang']->value['IP解析'];?>
</th>
	      <td><?php echo $_smarty_tpl->tpl_vars['server']->value['ip地址'];?>
</td>
	    </tr>
<?php }
if ((isset($_smarty_tpl->tpl_vars['server']->value['专用IP'])?$_smarty_tpl->tpl_vars['server']->value['专用IP']:'') != '') {?>
		<tr>
	      <th><?php echo $_smarty_tpl->tpl_vars['lang']->value['专用IP'];?>
</th>
	      <td><?php echo $_smarty_tpl->tpl_vars['server']->value['专用IP'];?>
</td>
	    </tr>
<?php }
if ((isset($_smarty_tpl->tpl_vars['server']->value['指定IP'])?$_smarty_tpl->tpl_vars['server']->value['指定IP']:'') != '') {?>
		<tr>
	      <th><?php echo $_smarty_tpl->tpl_vars['lang']->value['指定IP'];?>
</th>
	      <td><?php echo $_smarty_tpl->tpl_vars['server']->value['指定IP'];?>
</td>
	    </tr>
<?php }
if ((isset($_smarty_tpl->tpl_vars['server']->value['主机名'])?$_smarty_tpl->tpl_vars['server']->value['主机名']:'') != '') {?>
	    <tr>
	      <th><?php echo $_smarty_tpl->tpl_vars['lang']->value['CNAME解析'];?>
</th>
	      <td><?php echo $_smarty_tpl->tpl_vars['server']->value['主机名'];?>
</td>
	    </tr>
<?php }
if ((isset($_smarty_tpl->tpl_vars['server']->value['DNS服务器1'])?$_smarty_tpl->tpl_vars['server']->value['DNS服务器1']:'') != '' || (isset($_smarty_tpl->tpl_vars['server']->value['DNS服务器2'])?$_smarty_tpl->tpl_vars['server']->value['DNS服务器2']:'') != '' || (isset($_smarty_tpl->tpl_vars['server']->value['DNS服务器3'])?$_smarty_tpl->tpl_vars['server']->value['DNS服务器3']:'') != '' || (isset($_smarty_tpl->tpl_vars['server']->value['DNS服务器4'])?$_smarty_tpl->tpl_vars['server']->value['DNS服务器4']:'') != '' || (isset($_smarty_tpl->tpl_vars['server']->value['DNS服务器5'])?$_smarty_tpl->tpl_vars['server']->value['DNS服务器5']:'') != '') {?>
		<tr>
	      <th><?php echo $_smarty_tpl->tpl_vars['lang']->value['DNS解析(NS)'];?>
</th>
	      <td>
	      	<?php if ((isset($_smarty_tpl->tpl_vars['server']->value['DNS服务器1'])?$_smarty_tpl->tpl_vars['server']->value['DNS服务器1']:'') != '') {
echo $_smarty_tpl->tpl_vars['server']->value['DNS服务器1'];
}?>
			<?php if ((isset($_smarty_tpl->tpl_vars['server']->value['DNS服务器2'])?$_smarty_tpl->tpl_vars['server']->value['DNS服务器2']:'') != '') {?><br><?php echo $_smarty_tpl->tpl_vars['server']->value['DNS服务器2'];
}?>
			<?php if ((isset($_smarty_tpl->tpl_vars['server']->value['DNS服务器3'])?$_smarty_tpl->tpl_vars['server']->value['DNS服务器3']:'') != '') {?><br><?php echo $_smarty_tpl->tpl_vars['server']->value['DNS服务器3'];
}?>
			<?php if ((isset($_smarty_tpl->tpl_vars['server']->value['DNS服务器4'])?$_smarty_tpl->tpl_vars['server']->value['DNS服务器4']:'') != '') {?><br><?php echo $_smarty_tpl->tpl_vars['server']->value['DNS服务器4'];
}?>
			<?php if ((isset($_smarty_tpl->tpl_vars['server']->value['DNS服务器5'])?$_smarty_tpl->tpl_vars['server']->value['DNS服务器5']:'') != '') {?><br><?php echo $_smarty_tpl->tpl_vars['server']->value['DNS服务器5'];
}?>
	      </td>
	    </tr>
<?php }?>
	    <tr>
	      <th><?php echo $_smarty_tpl->tpl_vars['lang']->value['价格 / 周期'];?>
</th>
	      <td><?php if (is_array((isset($_smarty_tpl->tpl_vars['server']->value['周期'])?$_smarty_tpl->tpl_vars['server']->value['周期']:''))) {?>
				<?php echo $_smarty_tpl->tpl_vars['server']->value['周期']['名称'];?>
 <?php echo $_smarty_tpl->tpl_vars['server']->value['周期']['价格'];
echo $_smarty_tpl->tpl_vars['c']->value['交易币名称'];?>
/<?php echo $_smarty_tpl->tpl_vars['server']->value['周期']['时间'];?>
天
			<?php } else { ?>
				<?php echo $_smarty_tpl->tpl_vars['goods']->value['价格'];
if ((isset($_smarty_tpl->tpl_vars['goods']->value['价格'])?$_smarty_tpl->tpl_vars['goods']->value['价格']:'') != '免费') {?> <?php echo $_smarty_tpl->tpl_vars['c']->value['交易币名称'];
}?> / <?php echo $_smarty_tpl->tpl_vars['server']->value['周期'];?>

			<?php }?></td>
	    </tr>
<?php if ((isset($_smarty_tpl->tpl_vars['server']->value['开通时间'])?$_smarty_tpl->tpl_vars['server']->value['开通时间']:'') != '') {?>
	    <tr>
	      <th><?php echo $_smarty_tpl->tpl_vars['lang']->value['开通时间'];?>
</th>
	      <td><?php echo $_smarty_tpl->tpl_vars['server']->value['开通时间'];?>
</td>
	    </tr>

<?php }
if ((isset($_smarty_tpl->tpl_vars['server']->value['到期时间'])?$_smarty_tpl->tpl_vars['server']->value['到期时间']:'') != '') {?>
	    <tr>
	      <th><?php echo $_smarty_tpl->tpl_vars['lang']->value['到期时间'];?>
</th>
	      <td><?php echo $_smarty_tpl->tpl_vars['server']->value['到期时间'];?>
</td>
	    </tr>
<?php }
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['options']->value, 'option');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['option']->value) {
?>
		<tr>
	      <th><?php echo $_smarty_tpl->tpl_vars['option']->value['名称'];?>
</th>
	      <td><?php echo $_smarty_tpl->tpl_vars['option']->value['值'];?>
</td>
	    </tr>
<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>

<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['configs']->value, 'config');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['config']->value) {
?>
		<tr>
	      <th><?php echo $_smarty_tpl->tpl_vars['config']->value['名字'];?>
</th>
	      <td><?php echo $_smarty_tpl->tpl_vars['config']->value['内容'];?>
</td>
	    </tr>
<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>

	    <tr>
	      <th width="250"><?php echo $_smarty_tpl->tpl_vars['lang']->value['续期产品'];?>
</th>
	      <td>
		<?php if (!(isset($_smarty_tpl->tpl_vars['goods']->value['禁止续费'])?$_smarty_tpl->tpl_vars['goods']->value['禁止续费']:'') && (isset($_smarty_tpl->tpl_vars['server']->value['周期'])?$_smarty_tpl->tpl_vars['server']->value['周期']:'') != '一次性') {?>
	  		<form action="pay/" method="post"><p>
	        
			<?php if (is_array((isset($_smarty_tpl->tpl_vars['goods']->value['周期'])?$_smarty_tpl->tpl_vars['goods']->value['周期']:''))) {?>
				<select name="cycleid">
				<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['goods']->value['可续期周期'], 'row', false, 'num');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['num']->value => $_smarty_tpl->tpl_vars['row']->value) {
?>
					<option value="<?php echo $_smarty_tpl->tpl_vars['num']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['row']->value['名称'];?>
 <?php echo $_smarty_tpl->tpl_vars['row']->value['价格'];
echo $_smarty_tpl->tpl_vars['c']->value['交易币名称'];?>
/<?php echo $_smarty_tpl->tpl_vars['row']->value['时间'];?>
天</option>
				<?php
}
} else {
?>

					无法续费
				<?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>

				</select>
<?php } else { ?>
			
			<?php if ((isset($_smarty_tpl->tpl_vars['goods']->value['价格'])?$_smarty_tpl->tpl_vars['goods']->value['价格']:'') != '免费') {?>
	          <?php echo $_smarty_tpl->tpl_vars['mlang']->value['续费时长'];?>
:<input name="day" value="1" type="text"  id="inputDay" onkeyup="this.value=this.value.replace(/\D|^0/g,'')" />
			  <?php if ((isset($_smarty_tpl->tpl_vars['goods']->value['周期'])?$_smarty_tpl->tpl_vars['goods']->value['周期']:'') == '日付') {?>/<?php echo $_smarty_tpl->tpl_vars['mlang']->value['日'];?>

				<?php } elseif ((isset($_smarty_tpl->tpl_vars['goods']->value['周期'])?$_smarty_tpl->tpl_vars['goods']->value['周期']:'') == '月付') {?>/<?php echo $_smarty_tpl->tpl_vars['mlang']->value['月'];?>

				<?php } elseif ((isset($_smarty_tpl->tpl_vars['goods']->value['周期'])?$_smarty_tpl->tpl_vars['goods']->value['周期']:'') == '年付') {?>/<?php echo $_smarty_tpl->tpl_vars['mlang']->value['年'];
}?>
			<?php }?>
			
			<?php }?>
			<input type="submit"  class="btn btn-primary"  value="<?php echo $_smarty_tpl->tpl_vars['lang']->value['续期'];?>
"><br>
			<?php if (!is_array((isset($_smarty_tpl->tpl_vars['goods']->value['周期'])?$_smarty_tpl->tpl_vars['goods']->value['周期']:''))) {
if ((isset($_smarty_tpl->tpl_vars['goods']->value['价格'])?$_smarty_tpl->tpl_vars['goods']->value['价格']:'') != '免费') {
echo $_smarty_tpl->tpl_vars['lang']->value['您目前拥有预存款'];?>
 <?php echo $_smarty_tpl->tpl_vars['s']->value['登陆预存款'];?>
 <?php echo $_smarty_tpl->tpl_vars['c']->value['交易币名称'];
echo $_smarty_tpl->tpl_vars['lang']->value['，最多可以激活该产品'];?>
 <?php echo $_smarty_tpl->tpl_vars['payday']->value;?>
 /<?php echo $_smarty_tpl->tpl_vars['goods']->value['周期'];
} else {
echo $_smarty_tpl->tpl_vars['lang']->value['免费产品会自动帮你续期到目前最大的时间!!'];
if ((isset($_smarty_tpl->tpl_vars['goods']->value['周期'])?$_smarty_tpl->tpl_vars['goods']->value['周期']:'') == '日付') {
echo $_smarty_tpl->tpl_vars['lang']->value['30日'];
} elseif ((isset($_smarty_tpl->tpl_vars['goods']->value['周期'])?$_smarty_tpl->tpl_vars['goods']->value['周期']:'') == '月付') {
echo $_smarty_tpl->tpl_vars['lang']->value['1月'];
} elseif ((isset($_smarty_tpl->tpl_vars['goods']->value['周期'])?$_smarty_tpl->tpl_vars['goods']->value['周期']:'') == '年付') {
echo $_smarty_tpl->tpl_vars['lang']->value['1年'];
}
}
} else {
echo $_smarty_tpl->tpl_vars['lang']->value['您目前拥有预存款'];?>
 <?php echo $_smarty_tpl->tpl_vars['s']->value['登陆预存款'];?>
 <?php echo $_smarty_tpl->tpl_vars['c']->value['交易币名称'];
}?>
			
			</form>
		<?php } else { ?>
			<?php echo $_smarty_tpl->tpl_vars['mlang']->value['该产品禁止续费'];?>

		<?php }?>
	      </td>
	    </tr>	    <tr>
	      <th width="250"><?php echo $_smarty_tpl->tpl_vars['lang']->value['状态'];?>
</th>
	      <td>
	  		<!-- <?php if ((isset($_smarty_tpl->tpl_vars['server']->value['状态'])?$_smarty_tpl->tpl_vars['server']->value['状态']:'') == '激活') {?> -->
					<a class="btn btn-success"><?php echo $_smarty_tpl->tpl_vars['lang']->value['激活'];?>
</a>
					<!-- <?php } elseif ((isset($_smarty_tpl->tpl_vars['server']->value['状态'])?$_smarty_tpl->tpl_vars['server']->value['状态']:'') == '等待审核') {?> -->
					<a class="btn btn-info"><?php echo $_smarty_tpl->tpl_vars['lang']->value['等待审核'];?>
</a>
					<!-- <?php } elseif ((isset($_smarty_tpl->tpl_vars['server']->value['状态'])?$_smarty_tpl->tpl_vars['server']->value['状态']:'') == '暂停') {?> -->
					<a class="btn btn-warning"><?php echo $_smarty_tpl->tpl_vars['lang']->value['暂停'];?>
</a>
					<!-- <?php } elseif ((isset($_smarty_tpl->tpl_vars['server']->value['状态'])?$_smarty_tpl->tpl_vars['server']->value['状态']:'') == '停止') {?> -->
					<a class="btn btn-info" style="background-color: #b94a48;"><?php echo $_smarty_tpl->tpl_vars['lang']->value['停止'];?>
</a>
					<!-- <?php } elseif ((isset($_smarty_tpl->tpl_vars['server']->value['状态'])?$_smarty_tpl->tpl_vars['server']->value['状态']:'') == '驳回') {?> -->
					<a class="btn btn-info" style="background-color: #333333;"><?php echo $_smarty_tpl->tpl_vars['lang']->value['驳回'];?>
</a>
					<!-- <?php } elseif ((isset($_smarty_tpl->tpl_vars['server']->value['状态'])?$_smarty_tpl->tpl_vars['server']->value['状态']:'') == '等待付款') {?> -->
					<a class="btn btn-default"><?php echo $_smarty_tpl->tpl_vars['lang']->value['等待付款'];?>
</a>
					<!-- <?php } else { ?> -->
					<a class="btn btn-info"><?php echo $_smarty_tpl->tpl_vars['server']->value['状态'];?>
</a>
					<!-- <?php }?> -->
	      </td>
	    </tr>
	  
	  </thead>
        </table>
      </div>
			


	
	
    </div>
  <!-- </div> --></section>




    <!--  Footer -->

    <section class="footer">
        <div class="row">
            <div class="col-sm-3">
                <h4><?php echo $_smarty_tpl->tpl_vars['mlang']->value['快速导航'];?>
</h4>
                <ul>
                    <li><a href="<?php echo $_smarty_tpl->tpl_vars['ROOT']->value;?>
/control/index/"> <?php echo $_smarty_tpl->tpl_vars['mlang']->value['我的订单'];?>
</a></li>
                    <li><a href="<?php echo $_smarty_tpl->tpl_vars['ROOT']->value;?>
/ticket/submit/"> <?php echo $_smarty_tpl->tpl_vars['mlang']->value['提交服务单'];?>
</a></li>
                    <li><a href="<?php echo $_smarty_tpl->tpl_vars['ROOT']->value;?>
/networkissues/serverstatus/"><?php echo $_smarty_tpl->tpl_vars['mlang']->value['服务器状态'];?>
</a></li>
                    <li><a href="<?php echo $_smarty_tpl->tpl_vars['ROOT']->value;?>
/networkissues/index/"> <?php echo $_smarty_tpl->tpl_vars['mlang']->value['网络故障'];?>
</a></li>
                </ul>
            </div>
            <div class="col-sm-3">
               <?php echo $_smarty_tpl->tpl_vars['tempsz']->value['底部第2列'];?>

            </div>
            <div class="col-sm-3">
			<?php echo $_smarty_tpl->tpl_vars['tempsz']->value['底部第3列'];?>

                
            </div>
            <div class="col-sm-3">
                <h4><?php echo $_smarty_tpl->tpl_vars['mlang']->value['联系我们'];?>
</h4>
                <ul class="questions">
			
                   
                    <li><i class="fa fa-phone"></i> <?php echo $_smarty_tpl->tpl_vars['tempsz']->value['联系电话'];?>
</li>
                    <li><i class="fa fa-envelope"></i> <?php echo $_smarty_tpl->tpl_vars['tempsz']->value['邮箱'];?>
</li> <li>
					<i class="fa fa-comment"></i> <?php echo $_smarty_tpl->tpl_vars['tempsz']->value['QQ'];?>
</li>
                   <!--  <li>	
                    </li> -->
                </ul>
            </div>
        </div>

    </section>
	  <div class="social">
        <div class="row">

            <span style="float:left;">
            <?php echo $_smarty_tpl->tpl_vars['c']->value['底部版权'];?>
 <?php echo $_smarty_tpl->tpl_vars['c']->value['网站名称'];?>
  Theme by XH ServerEast | Powered by <a href="http://www.swapidc.cn/">SWAPIDC</a>


			 
             
            </span>
            <span style="float:right;">
			<form method="post" name="languagefrm" id="languagefrom"><select name="language" onchange="languagefrom.submit()">
			  <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['l']->value, 'langs');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['langs']->value) {
?>
			  <option value="<?php echo $_smarty_tpl->tpl_vars['langs']->value;?>
"<?php if ((isset($_smarty_tpl->tpl_vars['langs']->value)?$_smarty_tpl->tpl_vars['langs']->value:'') == (isset($_smarty_tpl->tpl_vars['language']->value)?$_smarty_tpl->tpl_vars['language']->value:'')) {?> selected="selected"<?php }?>><?php echo $_smarty_tpl->tpl_vars['langs']->value;?>
</option>
			  <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>

			</select>
		</form>
            </span>
        </div>
    </div>
    <!--  End of Footer -->
<a href="#top" id="back-to-top"><i class="fa fa-angle-up"></i></a>


    <script src="<?php echo $_smarty_tpl->tpl_vars['templatedir']->value;?>
/js/hoverIntent.js"></script>
    <script src="<?php echo $_smarty_tpl->tpl_vars['templatedir']->value;?>
/js/superfish.min.js"></script>
    <script src="<?php echo $_smarty_tpl->tpl_vars['templatedir']->value;?>
/js/owl.carousel.js"></script>
    <script src="<?php echo $_smarty_tpl->tpl_vars['templatedir']->value;?>
/js/wow.min.js"></script>
    <script src="<?php echo $_smarty_tpl->tpl_vars['templatedir']->value;?>
/js/jquery.circliful.min.js"></script>
    <script src="<?php echo $_smarty_tpl->tpl_vars['templatedir']->value;?>
/js/waypoints.min.js"></script>
    <script src="<?php echo $_smarty_tpl->tpl_vars['templatedir']->value;?>
/js/jquery.slicknav.min.js"></script>
    <script src="<?php echo $_smarty_tpl->tpl_vars['templatedir']->value;?>
/js/retina.min.js"></script>
    <script src="<?php echo $_smarty_tpl->tpl_vars['templatedir']->value;?>
/js/custom.js"></script>

    <script>
    /* Home Page Slider
   ========================================================================== */
    $(document).ready(function() {


    var sync1 = $("#mainslider");
    var sync2 = $("#mainslider-nav");

    sync1.owlCarousel({
    singleItem : true,
    slideSpeed : 1000,
    paginationSpeed: 800,
    navigation: false,
    pagination:false,
    autoPlay:7500,
    afterAction : syncPosition,
    responsiveRefreshRate : 200,
    });

    sync2.owlCarousel({
    items : 4,
    itemsDesktop : [1199,4],
    itemsDesktopSmall : [979,4],
    itemsTablet : [768,4],
    itemsMobile : [479,2],
    pagination:false,
    responsiveRefreshRate : 100,
    afterInit : function(el){
    el.find(".owl-item").eq(0).addClass("synced");
    }
    });

    function syncPosition(el){
    var current = this.currentItem;
    $("#mainslider-nav")
    .find(".owl-item")
    .removeClass("synced")
    .eq(current)
    .addClass("synced")
    if($("#mainslider-nav").data("owlCarousel") !== undefined){
    center(current)
    }
    }

    $("#mainslider-nav").on("click", ".owl-item", function(e){
    e.preventDefault();
    var number = $(this).data("owlItem");
    sync1.trigger("owl.goTo",number);
    });

    function center(number){
    var sync2visible = sync2.data("owlCarousel").owl.visibleItems;
    var num = number;
    var found = false;
    for(var i in sync2visible){
    if(num === sync2visible[i]){
    var found = true;
    }
    }

    if(found===false){
    if(num>sync2visible[sync2visible.length-1]){
    sync2.trigger("owl.goTo", num - sync2visible.length+2)
    }else{
    if(num - 1 === -1){
    num = 0;
    }
    sync2.trigger("owl.goTo", num);
    }
    } else if(num === sync2visible[sync2visible.length-1]){
    sync2.trigger("owl.goTo", sync2visible[1])
    } else if(num === sync2visible[0]){
    sync2.trigger("owl.goTo", num-1)
    }
    }

    });

/* Τestimonials
   ========================================================================== */
 $(document).ready(function() {
        $("#testimonials-carousel").owlCarousel({
            items: 1,
            autoPlay: 5000,
            itemsDesktop: [1199, 1],
            itemsDesktopSmall: [979, 1],
            itemsTablet: [768, 1]
        });
    });

    // ______________ STATS
jQuery(document).ready(function() {
$('.statistics').waypoint(function() {

 $('#myStat1').circliful();
 $('#myStat2').circliful();
 $('#myStat3').circliful();
 $('#myStat4').circliful();

}, { offset: 800, triggerOnce: true });
});

    </script>
</body>

</html><?php }
}
