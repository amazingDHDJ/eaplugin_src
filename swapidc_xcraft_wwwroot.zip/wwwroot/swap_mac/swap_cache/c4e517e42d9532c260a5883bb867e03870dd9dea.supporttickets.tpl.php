<?php
/* Smarty version 3.1.30, created on 2017-05-21 16:03:48
  from "/home/ftp/s/s2644661/wwwroot/templates/servereast/supporttickets.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_592149e4bda840_31652920',
  'has_nocache_code' => true,
  'file_dependency' => 
  array (
    '1805f03b19a08868bc078df917e33802f748ff88' => 
    array (
      0 => '/home/ftp/s/s2644661/wwwroot/templates/servereast/supporttickets.tpl',
      1 => 1492673322,
      2 => 'file',
    ),
    'f7867801f9ff470333487eb8267a51a976b8319c' => 
    array (
      0 => '/home/ftp/s/s2644661/wwwroot/templates/servereast/alert.tpl',
      1 => 1492673322,
      2 => 'file',
    ),
    '163c6ae1971be814db3119f5b2170a0ff1adc282' => 
    array (
      0 => '/home/ftp/s/s2644661/wwwroot/templates/servereast/footer.tpl',
      1 => 1492673322,
      2 => 'file',
    ),
  ),
  'cache_lifetime' => 120,
),true)) {
function content_592149e4bda840_31652920 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender("file:header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array('navxz'=>'','title'=>$_smarty_tpl->tpl_vars['lang']->value['查看服务单'],'hostname'=>$_smarty_tpl->tpl_vars['c']->value['网站名称']), 0, false);
?>
<style type="text/css">
/*tip message start*/
.tip_message,.tip_message .tip_ico_succ,.tip_message .tip_ico_fail,.tip_message .tip_ico_hits,.tip_message .tip_content,.tip_message .tip_end{ background-image:url(<?php echo $_smarty_tpl->tpl_vars['templatedir']->value;?>
/js/tip_message.png);_background-image:url(<?php echo $_smarty_tpl->tpl_vars['templatedir']->value;?>
/js/tip_message_ie6.png);color:#606060;float:left;font-size:14px;font-weight:bold;height:54px;line-height:54px;}
.tip_message{ display:none;background:none;position:absolute;font-family:Arial,Simsun,"Arial Unicode MS",Mingliu,Helvetica;font-size:14px;}
.tip_message .tip_ico_succ
{ background-position:-6px 0;background-repeat:no-repeat;width:45px;}
.tip_message .tip_ico_fail{ background-position:-6px -108px;background-repeat:no-repeat;width:45px;}
.tip_message .tip_ico_hits{ background-position:-6px -54px;background-repeat:no-repeat;width:45px;}
.tip_message .tip_end{ background-position:0 0;background-repeat:no-repeat;width:6px;}
.tip_content{ background-position:0 -161px;background-repeat:repeat-x;padding:0 20px 0 8px; word-break:keep-all;white-space:nowrap;}
.tip_message .tip_message_content{ position:absolute; left:0; top:0; width:100%;height:100%;z-index:65530;}
.ie6_mask{ position:absolute; left:0; top:0; width:100%;height:100%;background-color:transparent;z-index:-1;filter:alpha(opacity=0);}
/* tip message end */
</style>
<?php if ((isset($_smarty_tpl->tpl_vars['alert']->value['warning'])?$_smarty_tpl->tpl_vars['alert']->value['warning']:'') != '') {?>
<script type="text/javascript">
$.tipMessage('<strong><?php echo $_smarty_tpl->tpl_vars['lang']->value["警告"];?>
: </strong><?php echo $_smarty_tpl->tpl_vars['alert']->value["warning"];?>
',2 , 5000);
</script>
<?php }
if ((isset($_smarty_tpl->tpl_vars['alert']->value['error'])?$_smarty_tpl->tpl_vars['alert']->value['error']:'') != '') {?>
<script type="text/javascript">
$.tipMessage('<strong><?php echo $_smarty_tpl->tpl_vars['lang']->value["错误"];?>
: </strong><?php echo $_smarty_tpl->tpl_vars['alert']->value["error"];?>
', 2, 5000);
</script>
<?php }
if ((isset($_smarty_tpl->tpl_vars['alert']->value['success'])?$_smarty_tpl->tpl_vars['alert']->value['success']:'') != '') {?>
<script type="text/javascript">
$.tipMessage('<strong><?php echo $_smarty_tpl->tpl_vars['lang']->value["成功"];?>
: </strong><?php echo $_smarty_tpl->tpl_vars['alert']->value["success"];?>
',3 , 5000);
</script>
<?php }
if ((isset($_smarty_tpl->tpl_vars['alert']->value['info'])?$_smarty_tpl->tpl_vars['alert']->value['info']:'') != '') {?>
<script type="text/javascript">
$.tipMessage(' <strong><?php echo $_smarty_tpl->tpl_vars['lang']->value["信息"];?>
: </strong><?php echo $_smarty_tpl->tpl_vars['alert']->value["info"];?>
', 1, 5000);
</script>
<?php }?>
  <!-- Breadcrumps -->
  <div class="breadcrumbs">
    <div class="row">
      <div class="col-sm-6">
        <h1><?php echo $_smarty_tpl->tpl_vars['lang']->value['查看服务单'];?>
[<a href="<?php echo $_smarty_tpl->tpl_vars['ROOT']->value;?>
/ticket/submit/"style="color:#F7F7F7;"><?php echo $_smarty_tpl->tpl_vars['lang']->value['提交新的服务单'];?>
</a>]</h1>
      </div>
    </div>
  </div>

  <!-- End of Breadcrumps -->
	
<div class="servers-table">
    <div class="row">
      <div class="col-sm-12">
        <table data-wow-delay="0.3s" class="products-table responsive wow fadeInUp tablesaw tablesaw-stack" data-mode="stack">
         <thead>
			    <tr>
			        <th><?php echo $_smarty_tpl->tpl_vars['lang']->value['日期'];?>
</th>
			        <th><?php echo $_smarty_tpl->tpl_vars['lang']->value['主题'];?>
</th>
			        <th><?php echo $_smarty_tpl->tpl_vars['lang']->value['状态'];?>
</th>
			        <th><?php echo $_smarty_tpl->tpl_vars['lang']->value['最近更新'];?>
</th>
			    </tr>
			</thead>
              <tbody>
                <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['tickets']->value, 'ticket');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['ticket']->value) {
?>
				<tr>
                  <td><a href="<?php echo $_smarty_tpl->tpl_vars['ROOT']->value;?>
/ticket/detailed/<?php echo $_smarty_tpl->tpl_vars['ticket']->value['id'];?>
/"><?php echo $_smarty_tpl->tpl_vars['ticket']->value['提交时间'];?>
</a></td>
                  <td><a href="<?php echo $_smarty_tpl->tpl_vars['ROOT']->value;?>
/ticket/detailed/<?php echo $_smarty_tpl->tpl_vars['ticket']->value['id'];?>
/"><?php echo $_smarty_tpl->tpl_vars['ticket']->value['主题'];?>
</a></td>
                  <td><a href="<?php echo $_smarty_tpl->tpl_vars['ROOT']->value;?>
/ticket/detailed/<?php echo $_smarty_tpl->tpl_vars['ticket']->value['id'];?>
/"><?php echo $_smarty_tpl->tpl_vars['lang']->value[$_smarty_tpl->tpl_vars['ticket']->value['状态']];?>
</a></td>
                  <td><a href="<?php echo $_smarty_tpl->tpl_vars['ROOT']->value;?>
/ticket/detailed/<?php echo $_smarty_tpl->tpl_vars['ticket']->value['id'];?>
/"><?php echo $_smarty_tpl->tpl_vars['ticket']->value['最后时间'];?>
</a></td>
                </tr>
				<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>

              </tbody>
        </table>
      </div>
			


<div class="col-sm-12 wow fadeInRight r-tabs">
<br><br><br>				
          <ul class="r-tabs-nav">

<li class="r-tabs-tab r-tabs-state-<?php if ((isset($_smarty_tpl->tpl_vars['t']->value['当前页数'])?$_smarty_tpl->tpl_vars['t']->value['当前页数']:'') == '1') {?>default<?php } else { ?>active<?php }?>" style="padding: 0 0 0 0;"><a href="<?php echo $_smarty_tpl->tpl_vars['t']->value['上一页连接'];?>
" class="r-tabs-anchor"><?php echo $_smarty_tpl->tpl_vars['lang']->value['上一页'];?>
</a></li>
<li class="r-tabs-tab r-tabs-state-default" style="padding: 0 0 0 0;"><a  class="r-tabs-anchor"><?php echo $_smarty_tpl->tpl_vars['lang']->value['总共'];?>
:<?php echo $_smarty_tpl->tpl_vars['t']->value['总页数'];
echo $_smarty_tpl->tpl_vars['lang']->value['页'];?>
 <?php echo $_smarty_tpl->tpl_vars['lang']->value['当前'];?>
:<?php echo $_smarty_tpl->tpl_vars['t']->value['当前页数'];
echo $_smarty_tpl->tpl_vars['lang']->value['页'];?>
</a></li>
<li class="r-tabs-tab r-tabs-state-<?php if ((isset($_smarty_tpl->tpl_vars['t']->value['当前页数'])?$_smarty_tpl->tpl_vars['t']->value['当前页数']:'') == (isset($_smarty_tpl->tpl_vars['t']->value['总页数'])?$_smarty_tpl->tpl_vars['t']->value['总页数']:'')) {?>default<?php } else { ?>active<?php }?>" style="padding: 0 0 0 0;"><a href="<?php echo $_smarty_tpl->tpl_vars['t']->value['下一页连接'];?>
" class="r-tabs-anchor"><?php echo $_smarty_tpl->tpl_vars['lang']->value['下一页'];?>
</a></li>
          </ul>
    </div>
	
	
    </div>
  </div>


 
    <!--  Footer -->

    <section class="footer">
        <div class="row">
            <div class="col-sm-3">
                <h4><?php echo $_smarty_tpl->tpl_vars['mlang']->value['快速导航'];?>
</h4>
                <ul>
                    <li><a href="<?php echo $_smarty_tpl->tpl_vars['ROOT']->value;?>
/control/index/"> <?php echo $_smarty_tpl->tpl_vars['mlang']->value['我的订单'];?>
</a></li>
                    <li><a href="<?php echo $_smarty_tpl->tpl_vars['ROOT']->value;?>
/ticket/submit/"> <?php echo $_smarty_tpl->tpl_vars['mlang']->value['提交服务单'];?>
</a></li>
                    <li><a href="<?php echo $_smarty_tpl->tpl_vars['ROOT']->value;?>
/networkissues/serverstatus/"><?php echo $_smarty_tpl->tpl_vars['mlang']->value['服务器状态'];?>
</a></li>
                    <li><a href="<?php echo $_smarty_tpl->tpl_vars['ROOT']->value;?>
/networkissues/index/"> <?php echo $_smarty_tpl->tpl_vars['mlang']->value['网络故障'];?>
</a></li>
                </ul>
            </div>
            <div class="col-sm-3">
               <?php echo $_smarty_tpl->tpl_vars['tempsz']->value['底部第2列'];?>

            </div>
            <div class="col-sm-3">
			<?php echo $_smarty_tpl->tpl_vars['tempsz']->value['底部第3列'];?>

                
            </div>
            <div class="col-sm-3">
                <h4><?php echo $_smarty_tpl->tpl_vars['mlang']->value['联系我们'];?>
</h4>
                <ul class="questions">
			
                   
                    <li><i class="fa fa-phone"></i> <?php echo $_smarty_tpl->tpl_vars['tempsz']->value['联系电话'];?>
</li>
                    <li><i class="fa fa-envelope"></i> <?php echo $_smarty_tpl->tpl_vars['tempsz']->value['邮箱'];?>
</li> <li>
					<i class="fa fa-comment"></i> <?php echo $_smarty_tpl->tpl_vars['tempsz']->value['QQ'];?>
</li>
                   <!--  <li>	
                    </li> -->
                </ul>
            </div>
        </div>

    </section>
	  <div class="social">
        <div class="row">

            <span style="float:left;">
            <?php echo $_smarty_tpl->tpl_vars['c']->value['底部版权'];?>
 <?php echo $_smarty_tpl->tpl_vars['c']->value['网站名称'];?>
  Theme by XH ServerEast | Powered by <a href="http://www.swapidc.cn/">SWAPIDC</a>


			 
             
            </span>
            <span style="float:right;">
			<form method="post" name="languagefrm" id="languagefrom"><select name="language" onchange="languagefrom.submit()">
			  <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['l']->value, 'langs');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['langs']->value) {
?>
			  <option value="<?php echo $_smarty_tpl->tpl_vars['langs']->value;?>
"<?php if ((isset($_smarty_tpl->tpl_vars['langs']->value)?$_smarty_tpl->tpl_vars['langs']->value:'') == (isset($_smarty_tpl->tpl_vars['language']->value)?$_smarty_tpl->tpl_vars['language']->value:'')) {?> selected="selected"<?php }?>><?php echo $_smarty_tpl->tpl_vars['langs']->value;?>
</option>
			  <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>

			</select>
		</form>
            </span>
        </div>
    </div>
    <!--  End of Footer -->
<a href="#top" id="back-to-top"><i class="fa fa-angle-up"></i></a>


    <script src="<?php echo $_smarty_tpl->tpl_vars['templatedir']->value;?>
/js/hoverIntent.js"></script>
    <script src="<?php echo $_smarty_tpl->tpl_vars['templatedir']->value;?>
/js/superfish.min.js"></script>
    <script src="<?php echo $_smarty_tpl->tpl_vars['templatedir']->value;?>
/js/owl.carousel.js"></script>
    <script src="<?php echo $_smarty_tpl->tpl_vars['templatedir']->value;?>
/js/wow.min.js"></script>
    <script src="<?php echo $_smarty_tpl->tpl_vars['templatedir']->value;?>
/js/jquery.circliful.min.js"></script>
    <script src="<?php echo $_smarty_tpl->tpl_vars['templatedir']->value;?>
/js/waypoints.min.js"></script>
    <script src="<?php echo $_smarty_tpl->tpl_vars['templatedir']->value;?>
/js/jquery.slicknav.min.js"></script>
    <script src="<?php echo $_smarty_tpl->tpl_vars['templatedir']->value;?>
/js/retina.min.js"></script>
    <script src="<?php echo $_smarty_tpl->tpl_vars['templatedir']->value;?>
/js/custom.js"></script>

    <script>
    /* Home Page Slider
   ========================================================================== */
    $(document).ready(function() {


    var sync1 = $("#mainslider");
    var sync2 = $("#mainslider-nav");

    sync1.owlCarousel({
    singleItem : true,
    slideSpeed : 1000,
    paginationSpeed: 800,
    navigation: false,
    pagination:false,
    autoPlay:7500,
    afterAction : syncPosition,
    responsiveRefreshRate : 200,
    });

    sync2.owlCarousel({
    items : 4,
    itemsDesktop : [1199,4],
    itemsDesktopSmall : [979,4],
    itemsTablet : [768,4],
    itemsMobile : [479,2],
    pagination:false,
    responsiveRefreshRate : 100,
    afterInit : function(el){
    el.find(".owl-item").eq(0).addClass("synced");
    }
    });

    function syncPosition(el){
    var current = this.currentItem;
    $("#mainslider-nav")
    .find(".owl-item")
    .removeClass("synced")
    .eq(current)
    .addClass("synced")
    if($("#mainslider-nav").data("owlCarousel") !== undefined){
    center(current)
    }
    }

    $("#mainslider-nav").on("click", ".owl-item", function(e){
    e.preventDefault();
    var number = $(this).data("owlItem");
    sync1.trigger("owl.goTo",number);
    });

    function center(number){
    var sync2visible = sync2.data("owlCarousel").owl.visibleItems;
    var num = number;
    var found = false;
    for(var i in sync2visible){
    if(num === sync2visible[i]){
    var found = true;
    }
    }

    if(found===false){
    if(num>sync2visible[sync2visible.length-1]){
    sync2.trigger("owl.goTo", num - sync2visible.length+2)
    }else{
    if(num - 1 === -1){
    num = 0;
    }
    sync2.trigger("owl.goTo", num);
    }
    } else if(num === sync2visible[sync2visible.length-1]){
    sync2.trigger("owl.goTo", sync2visible[1])
    } else if(num === sync2visible[0]){
    sync2.trigger("owl.goTo", num-1)
    }
    }

    });

/* Τestimonials
   ========================================================================== */
 $(document).ready(function() {
        $("#testimonials-carousel").owlCarousel({
            items: 1,
            autoPlay: 5000,
            itemsDesktop: [1199, 1],
            itemsDesktopSmall: [979, 1],
            itemsTablet: [768, 1]
        });
    });

    // ______________ STATS
jQuery(document).ready(function() {
$('.statistics').waypoint(function() {

 $('#myStat1').circliful();
 $('#myStat2').circliful();
 $('#myStat3').circliful();
 $('#myStat4').circliful();

}, { offset: 800, triggerOnce: true });
});

    </script>
</body>

</html><?php }
}
