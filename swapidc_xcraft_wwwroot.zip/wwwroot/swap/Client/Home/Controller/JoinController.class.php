<?php
namespace Home\Controller;
use Think\Controller;
class JoinController extends HomeController {
    public function index(){
		$this->display();

       }

}