<?php
namespace Home\Controller;
use Think\Controller;
class AwsController extends LoginController {
	
	
    public function index(){

		$res=$this->ApiReturn();
		
		if(IS_AJAX){
			$this->ajaxreturn($res);die;
		}
		
		$this->assign('res',$res);
		$this->display();
		
       }

    public function add(){
		
		$res=$this->ApiReturn();
		
		
		if(IS_AJAX){
			$this->ajaxreturn($res);die;
		}		
		
		$this->assign('res',$res);
		$this->display();
		
       }

}