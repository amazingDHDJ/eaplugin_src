<?php
namespace Home\Controller;
use Think\Controller;

class CloudController extends HomeController {
    public function index(){
		$resAPI=$this->Api();
	
		$servers_where["servertype"]="cloud";
		$servers_where["state"]=0;
		$servers=M("servers")->where($servers_where)->order("ord asc,id asc")->select();		
		$productshow=array("list"=>$product,"mode"=>$product[0]["pid"]);
		$this->assign('servers',$servers);
		$this->assign('resAPI',$resAPI);
		$this->assign('product',$productshow);
		$this->display();
		
       }

}