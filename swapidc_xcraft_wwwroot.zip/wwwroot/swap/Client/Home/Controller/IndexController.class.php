<?php
namespace Home\Controller;
use Think\Controller;
class IndexController extends HomeController {
    public function index(){
		
		$notice=M("News")->where(array("type"=>"网站公告"))->field("id,title,tim")->limit("0,3")->order("id desc")->select();
		$this->assign('notice',$notice);
		$this->display();
	
       }

}