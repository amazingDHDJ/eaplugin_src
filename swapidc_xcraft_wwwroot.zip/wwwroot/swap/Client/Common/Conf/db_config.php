<?php
return array (
  'DB_TYPE' => 'mysql',
  'DB_HOST' => 'localhost',
  'DB_NAME' => '',
  'DB_USER' => '',
  'DB_PWD' => '',
  'DB_PORT' => '3306',
  'DB_PREFIX' => 'hlapi_',
  'DB_CHARSET' => 'utf8',
  'DB_DEBUG' => false,
);