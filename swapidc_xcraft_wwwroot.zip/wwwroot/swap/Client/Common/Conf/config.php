<?php

$session_path=dirname(__FILE__) . "/session/";
if(!is_dir($session_path)){
	@mkdir($session_path,0755);
}

return array(
    'ADMIN_PWD_KEY'			=>	'fdkshfdskihh', //加密秘钥
	
	'PAGE_SIZE' => 10, //分页大小
	'LOAD_EXT_CONFIG'=>'db_config,version',	
	'URL_MODEL'=>2,
	'DEFAULT_MODULE'=>'Home',

	'MODULE_ALLOW_LIST'    =>    array('Home'),
    'VAR_PAGE'=>'page',
	'SESSION_OPTIONS'=> array(
			'expire'=>'65536',
			"path"=>$session_path,
	),
	'SERVERTYPE'=>array(
	'vps'=>'VPS',
	'domain'=>'域名',
	'adsl'=>'ADSL',
	'host'=>'虚拟主机',
	'server'=>'服务器',
	'cloud'=>'弹性云主机',
	'mssql'=>'MSSQL',
	'mysql'=>'MYSQL',
	
	),
	'producttype'=>array(
	'static'=>'普通',
	'rate'=>'费率',
	),
	'buymode'=>array(
	'day'=>"日",
	"week"=>"周",
	"month"=>"月",
	"quarter"=>"季",
	"half"=>"半年",
	"year"=>"年",
	"twoyear"=>"两年",
	"threeyear"=>"三年",
	"fouryear"=>"四年",
	"fiveyear"=>"五年",
	),
	'Dictionary'=>array(
	'address'=>'地区',
	'system'=>'系统',
	'cpu'=>'CPU核心',
	'ram'=>'内存',
	
	),
	'state'=>array(
	'0'=>'等待付款',
	'1'=>'已付款',
	'2'=>'已过期',
	'999'=>'正常',
	'998'=>'已取消',
	'996'=>'增值待处理',
	'888'=>'处理中',
	'997'=>'退款申请中',
	),
    'paymode'=>array(
		'static'=>'固定金额',
		'rate'=>'官方折扣',
	),

);