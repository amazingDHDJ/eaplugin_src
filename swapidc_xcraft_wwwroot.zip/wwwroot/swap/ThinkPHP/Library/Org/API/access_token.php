<?php return array (
  'access_token' => 'LJ8PLTJEP2O0d6uMQxCbFHdQky_QIVPfTxa8BsA9sqON6qEpvlG7dmvWQjGGraMM14r4kH3rAma7A4fHe7Qi3LK_wDyTVkfWE7EcViSK6aWWFpoFd5PU7iJdX4BmGlbwKMIaABAFHD',
  'expires_in' => 7200,
  'time' => 1453976250,
)?>